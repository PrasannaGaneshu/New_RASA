## intent:greetings.bye
- bye for now
- bye
- cya
- see you