## intent:greetings.hello
- hi
- hello
- hi there
- hello
- Hello