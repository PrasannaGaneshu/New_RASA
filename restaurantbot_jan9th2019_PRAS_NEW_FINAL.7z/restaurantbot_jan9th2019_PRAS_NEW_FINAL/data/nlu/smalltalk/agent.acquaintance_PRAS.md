## intent:agent.acquaintance
- who are you
- what are you?
- tell me something about yourself
- tell me abt urself
- introduce yourself













