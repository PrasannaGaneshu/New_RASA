## Generated Story 001
    * greetings.hello
        - utter_greetings.hello

## Generated Story 002
    * greetings.hello
        - utter_greetings.hello
    * greetings.hello
        - utter_greetings.hello
    * greetings.hello
        - utter_greetings.hello                     

## Generated Story 003
    * greetings.hello
      - utter_greetings.hello
    * geteodbal{"location": "bal"}
      - slot{"location": "bal"}
      - action_accntbal

## Generated Story 004
    * greetings.hello
        - utter_greetings.hello

        
## Generated Story 006
    * greetings.bye
        - utter_greetings.bye

## Generated Story 007
    * greetings.bye
        - utter_greetings.bye

## Generated Story 008
    * greetings.bye
        - utter_greetings.bye
        
## Generated Story 009
    * greetings.bye
        - utter_greetings.bye
                
## Generated Story 010
    * greetings.hello
        - utter_greetings.hello
    * greetings.bye
        - utter_greetings.bye
        
## Generated Story 012
    * greetings.hello
        - utter_greetings.hello
    * greetings.bye
        - utter_greetings.bye

## Generated Story 013
    * greetings.hello
        - utter_greetings.hello
    * greetings.bye
        - utter_greetings.bye

##Generated Story 014
* agent.acquaintance
    - utter_agent.acquaintance

##Generated Story 015
* greetings.hello
    - utter_greetings.hello
* agent.acquaintance
    - utter_agent.acquaintance

    
##Generated Story 016
* greetings.hello
    - utter_greetings.hello
* agent.acquaintance
    - utter_agent.acquaintance
* greetings.bye
    - utter_greetings.bye
    
##Generated Story 017
* greetings.hello
    - utter_greetings.hello
* agent.acquaintance
    - utter_agent.acquaintance
* geteodbal{"location": "bal"}
    - slot{"location": "bal"}
    - action_accntbal
* greetings.hello
    - utter_greetings.hello
* agent.acquaintance
    - utter_agent.acquaintance
* greetings.bye
    - utter_greetings.bye  

##Generated Story 018
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* geteodbal
    - action_accntbal
* greetings.bye{"location": "bal"}
    - slot{"location": "bal"}
    - utter_greetings.bye
* getweather
    - action_weather
    - slot{"location": "bal"}
    - slot{"pickup_location": "bal"}
* agent.acquaintance
    - utter_agent.acquaintance
* greetings.hello
    - utter_greetings.hello
* greetings.bye
    - utter_greetings.bye
    
##Generated Story 019
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* geteodbal
    - action_accntbal
* getstatements{"txntype": "exp"}
    - action_getstatement
* agent.acquaintance
    - utter_agent.acquaintance
* getweather
    - action_weather
    - slot{"location": "Mumbai"}
    - slot{"pickup_location": "Mumbai"}
* getnewcheckbook
    - action_getcheckbook
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "cheque book"}
* confirmation.yes
    - action_getcheckbook
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
* greetings.bye
    - utter_greetings.bye

##Generated Story 020
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* getweather
    - action_weather
    - slot{"location": "Mumbai"}
    - slot{"pickup_location": "Mumbai"}
* geteodbal
    - action_accntbal
* agent.acquaintance
    - utter_agent.acquaintance
* greetings.bye
    - utter_greetings.bye
* greetings.hello
    - utter_greetings.hello
* getnewcheckbook
    - action_getcheckbook
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "cheque book"}
* confirmation.yes
    - action_getcheckbook
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
* appraisal.thank_you
    - utter_appraisal.thank_you
    
##Generated Story 021
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* getweather
    - action_weather
    - slot{"location": "Mumbai"}
    - slot{"pickup_location": "Mumbai"}
* agent.acquaintance
    - utter_agent.acquaintance
* getrestaurant
    - action_restaurant
    - slot{"location": "Mumbai"}
* appraisal.thank_you
    - utter_appraisal.thank_you
* geteodbal
    - action_accntbal
* appraisal.thank_you
    - utter_appraisal.thank_you
* greetings.bye
    - utter_greetings.bye
    
##Generated Story 021
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* geteodbal
    - action_accntbal
* getrestaurant{"location": "delhi"}
    - slot{"location": "delhi"}
    - action_restaurant
    - slot{"location": "delhi"}
* getcab{"pickup_location": "mulund", "drop_location": "delhi"}
    - slot{"pickup_location": "mulund"}
    - slot{"drop_location": "delhi"}
    - action_getcab
    - slot{"pickup_location": "mulund"}
    - slot{"drop_location": "delhi"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "mulund"}
    - slot{"bkd_drop_location": "delhi"}
* getnewcheckbook
    - action_getcheckbook
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "cheque book"}
* confirmation.yes
    - action_getcheckbook
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
* appraisal.thank_you
    - utter_appraisal.thank_you
* greetings.bye
    - utter_greetings.bye

##Generated Story 022     
* agent.bad
    - utter_agent.bad
    
##Generated Story 023
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* agent.acquaintance
    - utter_agent.acquaintance
* getrestaurant
    - action_restaurant
    - slot{"location": "Mumbai"}
* agent.bad
    - utter_agent.bad
* getrestaurant
    - action_restaurant
    - slot{"location": "Mumbai"}
* appraisal.thank_you
    - utter_appraisal.thank_you
* geteodbal
    - action_accntbal
* greetings.bye
    - utter_greetings.bye
   
##Generated Story 024
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* geteodbal{"location": "bal"}
    - slot{"location": "bal"}
    - action_accntbal
* getrestaurant{"NORP": "chinese", "cuisine": "chinese", "location": "thane"}
    - slot{"location": "thane"}
    - action_restaurant
    - slot{"location": "thane"}
* getcab{"drop_location": "delhi"}
    - slot{"drop_location": "delhi"}
    - action_getcab
    - slot{"pickup_location": "default"}
    - slot{"drop_location": "delhi"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "default"}
    - slot{"bkd_drop_location": "delhi"}
* appraisal.thank_you
    - utter_appraisal.thank_you
* agent.acquaintance
    - utter_agent.acquaintance
* getrestaurant
    - action_restaurant
    - slot{"location": "thane"}
* getrestaurant
    - action_restaurant
    - slot{"location": "thane"}
* greetings.bye
    - utter_greetings.bye


##Generated Story 025
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* getnewcheckbook
    - action_getcheckbook
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "cheque book"}
* confirmation.no
    - utter_no_problem
* geteodbal{"location": "bal"}
    - slot{"location": "bal"}
    - action_accntbal
* agent.acquaintance
    - utter_agent.acquaintance
* getupcomingexpense{"acc_act_type": "upcoming expense"}
    - action_upcomingexpense
    - slot{"user_id": "PRABHA0901"}
* getrestaurant
    - action_restaurant
    - slot{"location": "bal"}
* getcab{"pickup_location": "bkc"}
    - slot{"pickup_location": "bkc"}
    - action_getcab
    - slot{"pickup_location": "bkc"}
    - slot{"drop_location": "default"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "bkc"}
    - slot{"bkd_drop_location": "default"}
* appraisal.thank_you
    - utter_appraisal.thank_you
* greetings.bye
    - utter_greetings.bye
        
##Generated Story 026
    * greetings.hello
        - utter_greetings.hello
    
##Generated Story 027
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* geteodbal
    - action_accntbal
* appraisal.thank_you
    - utter_appraisal.thank_you
* getrestaurant
    - action_restaurant
    - slot{"location": "vashi"}
* getweather
    - action_weather
* getweather{"location": "mumbai"}
    - slot{"location": "mumbai"}
    - action_weather
    - slot{"location": "mumbai"}
    - slot{"pickup_location": "mumbai"}
* getrestaurant
    - action_restaurant
    - slot{"location": "mumbai"}
* getupcomingexpense{"acc_act_type": "upcoming expense"}
    - action_upcomingexpense
    - slot{"user_id": "PRABHA0901"}
* getstatements{"DATE": "this year", "txntype": "trans", "date": "this year"}
    - slot{"DATE": "this year"}
    - slot{"date": "this year"}
    - action_getstatement
* appraisal.thank_you
    - utter_appraisal.thank_you
* greetings.bye
    - utter_greetings.bye
        
      
##Generated Story 032
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* getweather
    - action_weather
    - slot{"location": "Mumbai"}
    - slot{"pickup_location": "Mumbai"}
* getstatements{"txntype": "exp"}
    - action_getstatement
* appraisal.thank_you
    - utter_appraisal.thank_you
* getcab
    - action_getcab
    - slot{"pickup_location": "Mumbai"}
    - slot{"drop_location": "default"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "Mumbai"}
    - slot{"bkd_drop_location": "default"}
* agent.bad
    - utter_agent.bad
* greetings.bye
    - utter_greetings.bye

##Generated Story 033
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* getweather
    - action_weather
    - slot{"location": "Mumbai"}
    - slot{"pickup_location": "Mumbai"}
* getstatements{"txntype": "exp"}
    - action_getstatement
* appraisal.thank_you
    - utter_appraisal.thank_you
* getcab
    - action_getcab
    - slot{"pickup_location": "Mumbai"}
    - slot{"drop_location": "default"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "Hyderabad"}
    - slot{"bkd_drop_location": "default"}
* greetings.bye
    - utter_greetings.bye

##Generated Story 034
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* geteodbal
    - action_accntbal
* appraisal.thank_you
    - utter_appraisal.thank_you
* getweather
    - action_weather
    - slot{"location": "Mumbai"}
    - slot{"pickup_location": "Mumbai"}
* getnewcheckbook
    - action_getcheckbook
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "cheque book"}
* confirmation.yes
    - action_getcheckbook
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
* appraisal.thank_you
    - utter_appraisal.thank_you
* getcab{"drop_location": "golconda"}
    - slot{"drop_location": "golconda"}
    - action_getcab
    - slot{"pickup_location": "Mumbai"}
    - slot{"drop_location": "golconda"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "Mumbai"}
    - slot{"bkd_drop_location": "golconda"}
* greetings.bye
    - utter_greetings.bye

    
##Generated Story 035
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>LEONPAUL23793", "user_id": "llllllllllll0000000000000>leonpaul23793"}
    - slot{"user_id": "llllllllllll0000000000000>leonpaul23793"}
    - action_storeuseid
    - slot{"user_id": "LEONPAUL23793"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* agent.acquaintance
    - utter_agent.acquaintance
* appraisal.thank_you
    - utter_appraisal.thank_you
* geteodbal
    - action_accntbal
* getstatements{"txntype": "exp"}
    - action_getstatement
* getstatements{"txntype": "expenses"}
    - action_getstatement
* appraisal.thank_you
    - utter_appraisal.thank_you

##Generated Story 036
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>LEONPAUL23793", "user_id": "llllllllllll0000000000000>leonpaul23793"}
    - slot{"user_id": "llllllllllll0000000000000>leonpaul23793"}
    - action_storeuseid
    - slot{"user_id": "LEONPAUL23793"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* getweather
    - action_weather
    - slot{"location": "Mumbai"}
    - slot{"pickup_location": "Mumbai"}
* getstatements{"txntype": "expenses"}
    - action_getstatement


##Generated Story 037
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>LEONPAUL23793", "user_id": "llllllllllll0000000000000>leonpaul23793"}
    - slot{"user_id": "llllllllllll0000000000000>leonpaul23793"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello


##Generated Story 038
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>LEONPAUL23793", "user_id": "llllllllllll0000000000000>leonpaul23793"}
    - slot{"user_id": "llllllllllll0000000000000>leonpaul23793"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}

##Generated Story 039
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}


##Generated Story 040
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* agent.bad
    - utter_agent.bad
* agent.bad
    - utter_agent.bad
* getweather
    - action_weather
    - slot{"location": "bal"}
    - slot{"pickup_location": "bal"}
* appraisal.thank_you
    - utter_appraisal.thank_you
* greetings.bye
    - utter_greetings.bye


	

##Generated Story 047
* greetings.hello
	- utter_greetings.hello
* greetings.bye
	- utter_greetings.bye 

##Generated Story 048
* greetings.hello
	- utter_greetings.hello
* agent.acquaintance
	- utter_agent.acquaintance


##Generated Story 050
* greetings.hello
	- utter_greetings.hello
* greetings.bye
	- utter_greetings.bye
* greetings.hello
	- utter_greetings.hello
* greetings.bye
	- utter_greetings.bye
	
##Generated Story 051
* greetings.hello
	- utter_greetings.hello
* agent.acquaintance
	- utter_agent.acquaintance
* greetings.bye
	- utter_greetings.bye


##Generated Story 054
* greetings.hello
    - utter_greetings.hello
* agent.acquaintance
    - utter_agent.acquaintance
* greetings.bye
    - utter_greetings.bye


##Generated Story 063
* greetings.hello
	- utter_greetings.hello
* agent.acquaintance
	- utter_agent.acquaintance

##Generated Story 064
* greetings.hello
	- utter_greetings.hello
* agent.acquaintance
	- utter_agent.acquaintance
* greetings.bye
	- utter_greetings.bye

##Generated Story 065
* greetings.hello
	- utter_greetings.hello
* agent.acquaintance
	- utter_agent.acquaintance

##Generated Story 066
* greetings.hello
	- utter_greetings.hello
* agent.acquaintance
	- utter_agent.acquaintance
* agent.bad
	- utter_agent.bad

##Generated Story 067
* greetings.hello
	- utter_greetings.hello



##Generated Story 068
* agent.bad
	- utter_agent.bad


##Generated Story 070
* greetings.hello
	- utter_greetings.hello


##Generated Story 074
* greetings.hello
	- utter_greetings.hello

##Generated Story 075
* greetings.hello
	- utter_greetings.hello
* agent.acquaintance
	- utter_agent.acquaintance
* greetings.hello
	- utter_greetings.hello
* agent.bad
	- utter_agent.bad
* greetings.hello
	- utter_greetings.hello
* greetings.bye
	- utter_greetings.bye



##Generated Story 077
* greetings.hello
	- utter_greetings.hello
* agent.acquaintance
	- utter_agent.acquaintance

##Generated Story 078
* greetings.hello
	- utter_greetings.hello
* agent.acquaintance
	- utter_agent.acquaintance

##Generated Story 079
* greetings.hello
	- utter_greetings.hello
* agent.acquaintance
	- utter_agent.acquaintance


##Generated Story 080
* greetings.hello
	- utter_greetings.hello

##Generated Story 083
* greetings.hello
	- utter_greetings.hello
* greetings.bye
	- utter_greetings.bye
* agent.acquaintance
	- utter_agent.acquaintance
* agent.acquaintance
	- utter_agent.acquaintance
* greetings.hello
	- utter_greetings.hello
* agent.acquaintance
	- utter_agent.acquaintance
* agent.acquaintance
	- utter_agent.acquaintance
* confirmation.no
* greetings.bye
	- utter_greetings.bye

   

##Generated Story 085
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* agent.acquaintance
    - utter_agent.acquaintance


##Generated Story 086
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* getweather
    - action_weather
    - slot{"location": "Mumbai"}
    - slot{"pickup_location": "Mumbai"}
* getcab
    - action_getcab
    - slot{"pickup_location": "Mumbai"}
    - slot{"drop_location": "default"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "Mumbai"}
    - slot{"bkd_drop_location": "default"}
* agent.acquaintance
    - utter_agent.acquaintance
* geteodbal
    - action_accntbal
* greetings.bye
    - utter_greetings.bye

##Generated Story 087
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* agent.acquaintance
    - utter_agent.acquaintance
* agent.bad
    - utter_agent.bad


    
##Generated Story 088
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* agent.acquaintance
    - utter_agent.acquaintance


##Generated Story 089
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
* greetings.hello
    - utter_greetings.hello
* getupcomingexpense{"acc_act_type": "upcoming expense"}
    - action_upcomingexpense
    - slot{"user_id": "PRABHA0901"}
* appraisal.thank_you
    - utter_appraisal.thank_you
* getnewcheckbook
    - action_getcheckbook
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": null}


##Generated Story 089
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* agent.acquaintance
    - utter_agent.acquaintance


##Generated Story 090
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* greetings.bye
    - utter_greetings.bye


##Generated Story 091
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}

##Generated Story 092
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}

##Generated Story 093
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}


##Generated Story 094
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* getweather{"drop_location": "thane"}
    - slot{"drop_location": "thane"}
    - action_weather
    - slot{"location": "Mumbai"}
    - slot{"pickup_location": "Mumbai"}
* getweather{"location": "thane"}
    - slot{"location": "thane"}
    - action_weather
    - slot{"location": "thane"}
    - slot{"pickup_location": "thane"}
* getnewcheckbook
    - action_getcheckbook
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "cheque book"}
* confirmation.no
    - utter_no_problem
    
##Generated Story 095
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.bye
    - utter_greetings.bye
   
##Generated Story 096
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* appraisal.thank_you
    - utter_appraisal.thank_you
* agent.show_menu
    - action_showmenu
* geteodbal
    - action_accntbal
* greetings.bye
    - utter_greetings.bye

##Generated Story 097
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
* greetings.hello
    - utter_greetings.hello
* getupcomingexpense{"acc_act_type": "upcoming expense"}
    - action_upcomingexpense
    - slot{"user_id": "PRABHA0901"}
* appraisal.thank_you
    - utter_appraisal.thank_you
* getnewcheckbook
    - action_getcheckbook
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": null}
* agent.acquaintance
    - utter_agent.acquaintance
* getcab
    - action_getcab
* appraisal.thank_you
    - utter_appraisal.thank_you
* getrestaurant{"location": "delhi"}
    - slot{"location": "delhi"}
    - action_restaurant
    - slot{"location": "delhi"}
* appraisal.thank_you
    - utter_appraisal.thank_you


##Generated Story 098
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>PRABHA0901"}
    - slot{"user_id": "llllllllllll0000000000000>PRABHA0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* getweather{"drop_location": "thane"}
    - slot{"drop_location": "thane"}
    - action_weather
    - slot{"location": "Mumbai"}
    - slot{"pickup_location": "Mumbai"}
* getweather{"location": "thane"}
    - slot{"location": "thane"}
    - action_weather
    - slot{"location": "thane"}
    - slot{"pickup_location": "thane"}
* getnewcheckbook
    - action_getcheckbook
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "cheque book"}
* confirmation.no
    - utter_no_problem

##Generated Story 099
    * greetings.bye
        - utter_greetings.bye