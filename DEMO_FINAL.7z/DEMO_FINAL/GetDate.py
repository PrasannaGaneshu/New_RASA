# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
# Run get_date(str) with a string in the place of the str argument. The argument is the question you want to test
# Run test_date1() as it is without an argument to check all the variations of questions this script can handle as well as the output it gives.
# Additionally, run test_date2() to check the questions in the getstatementsdatefinal.json file. Remember to modify the file path of the JSON file in the function.


from datetime import timedelta
from dateutil import parser
from datetime import *
from dateutil import * 
import calendar
import re
import json
import codecs
from dateutil.tz import tzlocal
now = datetime.now(tzlocal())


def find_between( s, first, last ): #Extract substring betwen two words of string
    try:
        start = s.index( first ) + len( first )
        end = s.index( last, start )
        return s[start:end]
    except ValueError:
        return ""

def find_before(s, word):
    # Find first part and return slice before it.
    pos_a = s.find(word)
    if pos_a == -1: return ""
    return s[0:pos_a]

def find_after(s, word):
    # Find and validate first part.
    pos_a = s.find(word)
    if pos_a == -1: return ""
    # Returns chars after the found string.
    adjusted_pos_a = pos_a + len(word)
    if adjusted_pos_a >= len(s): return ""
    return s[adjusted_pos_a:]
    
def find_day_date(str_day): #Extract date for variations of 'last X days'.
    try:
        day_num = int(str_day)
        day_date = round((now - timedelta(days=day_num)).timestamp())
        return day_date
    except ValueError:
        return ""
    
def find_week_date(str_week):  #Extract date for variations of 'last X weeks'.
    try:
        week_num = int(str_week)
        day_num = (7*week_num)
        week_date = round((now - timedelta(days=day_num)).timestamp())
        return week_date
    except ValueError:
        return ""
    
def find_month_date(str_month):    #Extract date for variations of 'last X months'.
    try:
        month_num = int(str_month)
        day_num = (31*month_num)
        month_date = round((now - timedelta(days=day_num)).timestamp())
        return month_date
    except ValueError:
        return ""
    
def find_year_date(str_year):         #Extract date for variations of 'last X years'.
    try:
        year_num = int(str_year)
        day_num = (365*year_num)
        year_date = round((now - timedelta(days=day_num)).timestamp())
        return year_date
    except ValueError:
        return ""

def find_date(str_sample):     #Extract date for today, yesterday etc.
    try:
        now = datetime.now(tzlocal())
        if ('yesterday' in str_sample):
            date = round((now - timedelta(days=1)).timestamp())
        elif ('today' in str_sample):
            date = round(now.timestamp())
        return date
    except ValueError:
        return ""

    
def find_last_date(str_sample):       #Extract date for ths week, this month this year.
    try:
        if ('week' in str_sample):
            date = round((now - timedelta(days=7)).timestamp())
        elif ('month' in str_sample):
            date = round((now - timedelta(days=31)).timestamp())
        elif ('year' in str_sample):
            date = round((now - timedelta(days=365)).timestamp())
        return date
    except ValueError:
        return ""
    
def find_spec_date(str_sample):        #Additional functionality to extract specific date for wide variety of formarts
    try:
        date = round((parser.parse(str_sample)).timestamp())
        return date
    except ValueError:
        return ""

def contains_word(s, w):
    return (' ' + w + ' ') in (' ' + s + ' ')

def no_word(s,w):
    return (' ' + w + ' ') not in (' ' + s + ' ')

def find_time_before(str_sample,w):
    regex = r"((?:\S+\s+){0,1}\b"+w+")"
    return re.findall(regex, str_sample)
    
    
def get_date(strg):    #Extract date for all scenarios. As of now, more need to incorporated.
    strg = re.sub('\W+', ' ', strg)
    date = ''
    try:
        if ((no_word(strg,'and') and contains_word(strg,'days')) or (contains_word(strg,'and') and contains_word(find_before(strg,'and'),'days')) or (contains_word(strg,'past') and contains_word(strg,'day'))):
            if(contains_word(strg,'last')):
                date1 = find_day_date(find_between(strg,'last','days'))
                date2 = find_date('today')
                date = [date1,date2]
            elif(contains_word(strg,'since') and no_word(strg,'last') and no_word(strg,'past')):
                date1 = find_day_date(find_between(strg,'since','days'))
                date2 = find_date('today')
                date = [date1,date2]
            elif(contains_word(strg,'since') and contains_word(strg,'last') and no_word(strg,'past')):
                date1 = find_day_date(find_between(strg,'last','days'))
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'for')  and no_word(strg,'past')):
                date1 = find_day_date(find_between(strg,'for','days'))   
                date2 = find_date('today')
                date = [date1,date2]                
            elif (contains_word(strg,'till') and no_word(strg,'past')):
                date1 = find_day_date(find_between(strg,'till','days'))
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'of') and no_word(strg,'past')):
                date1 = find_day_date(re.search(r'(\d+) days',strg).group(1))
                date2 = find_date('today')
                date = [date1,date2]
            elif(contains_word(strg,'past')):
                if(contains_word(strg,'days and')): # Start of Past X Days and Y ____
                    post_wrd = find_after(strg,'and')
                    if(contains_word(post_wrd, 'days') or contains_word(post_wrd, 'day')):
                        try:
                            ii = 1
                            if(contains_word(post_wrd, 'days')):
                                dayy = int(find_before(find_after(strg,'and'),'days')) * ii
                            elif(contains_word(post_wrd, 'day')):
                                dayy = int(find_before(find_after(strg,'and'),'day')) * ii
                        except ValueError:
                            print('Invalid entry for days')
                        day = int(find_between(strg,'past','days'))
                        fin_day = int(day) + int(dayy)
                        date1 = find_day_date(str(fin_day))
                        date2 = find_date('today')
                        date = [date1,date2]
                    
                    elif(contains_word(post_wrd, 'weeks') or contains_word(post_wrd, 'week')):
                        try:
                            ii = 7
                            if(contains_word(post_wrd, 'weeks')):
                                dayy = int(find_before(find_after(strg,'and'),'weeks')) * ii
                            elif(contains_word(post_wrd, 'week')):
                                dayy = int(find_before(find_after(strg,'and'),'week')) * ii
                        except ValueError:
                            print('Invalid entry for weeks')
                        day = int(find_between(strg,'past','days'))
                        fin_day = int(day) + int(dayy)
                        date1 = find_day_date(str(fin_day))
                        date2 = find_date('today')
                        date = [date1,date2]
                    
                    elif(contains_word(post_wrd, 'months') or contains_word(post_wrd, 'month')):
                        try:
                            ii = 31
                            if(contains_word(post_wrd, 'months')):
                                dayy = int(find_before(find_after(strg,'and'),'months')) * ii
                            elif(contains_word(post_wrd, 'month')):
                                dayy = int(find_before(find_after(strg,'and'),'month')) * ii
                        except ValueError:
                            print('Invalid entry for months')
                        day = int(find_between(strg,'past','days'))
                        fin_day = int(day) + int(dayy)
                        date1 = find_day_date(str(fin_day))
                        date2 = find_date('today')
                        date = [date1,date2]
                    
                    elif(contains_word(post_wrd, 'years') or contains_word(post_wrd, 'year')):
                        try:
                            ii = 365
                            if(contains_word(post_wrd, 'years')):
                                dayy = int(find_before(find_after(strg,'and'),'years')) * ii
                            elif(contains_word(post_wrd, 'year')):
                                dayy = int(find_before(find_after(strg,'and'),'year')) * ii
                        except ValueError:
                            print('Invalid entry for years')
                        day = int(find_between(strg,'past','days'))
                        fin_day = int(day) + int(dayy)
                        date1 = find_day_date(str(fin_day)) # End of Past X Days and Y __
                        date2 = find_date('today')
                        date = [date1,date2]
                        
                elif(contains_word(strg,'day and')):                  # Start of Past X Day and Y ____
                    post_wrd = find_after(strg,'and')
                    if(contains_word(post_wrd, 'days') or contains_word(post_wrd, 'day')):
                        try:
                            ii = 1
                            if(contains_word(post_wrd, 'days')):
                                dayy = int(find_before(find_after(strg,'and'),'days')) * ii
                            elif(contains_word(post_wrd, 'day')):
                                dayy = int(find_before(find_after(strg,'and'),'day')) * ii
                        except ValueError:
                            print('Invalid entry for days')
                        day = int(find_between(strg,'past','day'))
                        fin_day = int(day) + int(dayy)
                        date1 = find_day_date(str(fin_day))
                        date2 = find_date('today')
                        date = [date1,date2]
                        
                    elif(contains_word(post_wrd, 'weeks') or contains_word(post_wrd, 'week')):
                        try:
                            ii = 7
                            if(contains_word(post_wrd, 'weeks')):
                                dayy = int(find_before(find_after(strg,'and'),'weeks')) * ii
                            elif(contains_word(post_wrd, 'week')):
                                dayy = int(find_before(find_after(strg,'and'),'week')) * ii
                        except ValueError:
                            print('Invalid entry for weeks')
                        day = int(find_between(strg,'past','day'))
                        fin_day = int(day) + int(dayy)
                        date1 = find_day_date(str(fin_day))
                        date2 = find_date('today')
                        date = [date1,date2]
                        
                    elif(contains_word(post_wrd, 'months') or contains_word(post_wrd, 'month')):
                        try:
                            ii = 31
                            if(contains_word(post_wrd, 'months')):
                                dayy = int(find_before(find_after(strg,'and'),'months')) * ii
                            elif(contains_word(post_wrd, 'month')):
                                dayy = int(find_before(find_after(strg,'and'),'month')) * ii
                        except ValueError:
                            print('Invalid entry for months')
                        day = int(find_between(strg,'past','day'))
                        fin_day = int(day) + int(dayy)
                        date1 = find_day_date(str(fin_day))
                        date2 = find_date('today')
                        date = [date1,date2]
                        
                    elif(contains_word(post_wrd, 'years') or contains_word(post_wrd, 'year')):
                        try:
                            ii = 365
                            if(contains_word(post_wrd, 'years')):
                                dayy = int(find_before(find_after(strg,'and'),'years')) * ii
                            elif(contains_word(post_wrd, 'year')):
                                dayy = int(find_before(find_after(strg,'and'),'year')) * ii
                        except ValueError:
                            print('Invalid entry for years')
                        day = int(find_between(strg,'past','day'))
                        fin_day = int(day) + int(dayy)
                        date1 = find_day_date(str(fin_day)) # End of Past X Day and Y ____
                        date2 = find_date('today')
                        date = [date1,date2]
                else:
                    if(contains_word(strg[strg.find('past'):],'day')):
                        date1 = find_day_date('1') #End of Past X Days
                        date2 = find_date('today')
                        date = [date1,date2]
                    else:
                        if(find_between(strg,'past','days') == ' ' or find_between(strg,'past','days')== ''):
                            date1 = find_day_date('1') #End of Past X Days
                        else:
                            date1 = find_day_date(find_between(strg,'past','days')) #End of Past X Days
                        date2 = find_date('today')
                        date = [date1,date2]
            
            else:
                if(contains_word(strg,'days') and (no_word(strg,'last') and no_word(strg,'past') and no_word(strg,'this') and no_word(strg,'since') and no_word(strg,'last'))):
                    num = int(find_before(str(find_time_before(strg,'days')[0]),'days'))
                    date1 = find_day_date(num)
                    date2 = find_date('today')
                    date = [date1,date2]
                else:
                    date1 = find_day_date('10')
                    date2 = find_date('today')
                    date = [date1,date2]
                    
        elif(contains_word(strg,'day') and (no_word(strg,'last') and no_word(strg,'past') and no_word(strg,'this') and no_word(strg,'since') and no_word(strg,'last'))):
                    num = int(find_before(str(find_time_before(strg,'day')[0]),'day'))
                    date1 = find_day_date(num)
                    date2 = find_date('today')
                    date = [date1,date2]
        
        elif (contains_word(strg,'weeks') or (contains_word(strg,'past') and contains_word(strg,'week'))):
            if(contains_word(strg,'last')):
                date1 = find_week_date(find_between(strg,'last','weeks'))
                date2 = find_date('today')
                date = [date1,date2]
            elif(contains_word(strg,'since') and no_word(strg,'last') and no_word(strg,'past')):
                date1 = find_week_date(find_between(strg,'since','weeks'))
                date2 = find_date('today')
                date = [date1,date2]
            elif(contains_word(strg,'since') and contains_word(strg,'last') and no_word(strg,'past')):
                date1 = find_week_date(find_between(strg,'last','weeks'))
                date2 = find_date('today')
                date = [date1,date2]
            elif(contains_word(strg,'since') and no_word(strg,'past')):
                date1 = find_week_date(find_between(strg,'since','weeks'))
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'for') and no_word(strg,'past')):
                date1 = find_week_date(find_between(strg,'for','weeks'))  
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'till') and no_word(strg,'past')):
                date1 = find_week_date(find_between(strg,'till','weeks'))
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'of') and no_word(strg,'past')):
                date1 = find_week_date(re.search(r'(\d+) weeks',strg).group(1))
                date2 = find_date('today')
                date = [date1,date2]
            elif(contains_word(strg,'past')):
                if(contains_word(strg,'weeks and')): # Start of Past X Weeks and Y ____
                    post_wrd = find_after(strg,'and')
                    if(contains_word(post_wrd, 'weeks') or contains_word(post_wrd, 'week')):
                        try:
                            ii = 7
                            if(contains_word(post_wrd, 'weeks')):
                                dayy = int(find_before(find_after(strg,'and'),'weeks')) * ii
                            elif(contains_word(post_wrd, 'week')):
                                dayy = int(find_before(find_after(strg,'and'),'week')) * ii
                        except ValueError:
                            print('Invalid entry for weeks')
                        day = int(find_between(strg,'past','weeks'))
                        fin_day = (int(day)*7) + int(dayy)
                        date1 = find_day_date(str(fin_day))
                        date2 = find_date('today')
                        date = [date1,date2]
                    
                    elif(contains_word(post_wrd, 'months') or contains_word(post_wrd, 'month')):
                        try:
                            ii = 31
                            if(contains_word(post_wrd, 'months')):
                                dayy = int(find_before(find_after(strg,'and'),'months')) * ii
                            elif(contains_word(post_wrd, 'month')):
                                dayy = int(find_before(find_after(strg,'and'),'month')) * ii
                        except ValueError:
                            print('Invalid entry for months')
                        day = int(find_between(strg,'past','weeks'))
                        fin_day = (int(day)*7) + int(dayy)
                        date1 = find_day_date(str(fin_day))
                        date2 = find_date('today')
                        date = [date1,date2]
                    elif(contains_word(post_wrd, 'years') or contains_word(post_wrd, 'year')):
                        try:
                            ii = 365
                            if(contains_word(post_wrd, 'years')):
                                dayy = int(find_before(find_after(strg,'and'),'years')) * ii
                            elif(contains_word(post_wrd, 'year')):
                                dayy = int(find_before(find_after(strg,'and'),'year')) * ii
                        except ValueError:
                            print('Invalid entry for years')
                        day = int(find_between(strg,'past','weeks'))
                        fin_day = (int(day)*7) + int(dayy)
                        date1 = find_day_date(str(fin_day)) # End of Past X Weeks and Y __
                        date2 = find_date('today')
                        date = [date1,date2]
                
                elif(contains_word(strg,'week and')):                  # Start of Past X Week and Y ____
                    post_wrd = find_after(strg,'and')
                    if(contains_word(post_wrd, 'weeks') or contains_word(post_wrd, 'week')):
                        try:
                            ii = 7
                            if(contains_word(post_wrd, 'weeks')):
                                dayy = int(find_before(find_after(strg,'and'),'weeks')) * ii
                            elif(contains_word(post_wrd, 'week')):
                                dayy = int(find_before(find_after(strg,'and'),'week')) * ii
                        except ValueError:
                            print('Invalid entry for weeks')
                        day = int(find_between(strg,'past','week'))
                        fin_day = (int(day)*7) + int(dayy)
                        date1 = find_day_date(str(fin_day))
                        date2 = find_date('today')
                        date = [date1,date2]
                
                    elif(contains_word(post_wrd, 'months') or contains_word(post_wrd, 'month')):
                        try:
                            ii = 31
                            if(contains_word(post_wrd, 'months')):
                                dayy = int(find_before(find_after(strg,'and'),'months')) * ii
                            elif(contains_word(post_wrd, 'month')):
                                dayy = int(find_before(find_after(strg,'and'),'month')) * ii
                        except ValueError:
                            print('Invalid entry for months')
                        day = int(find_between(strg,'past','week'))
                        fin_day = (int(day)*7) + int(dayy)
                        date1 = find_day_date(str(fin_day))
                        date2 = find_date('today')
                        date = [date1,date2]
                    elif(contains_word(post_wrd, 'years') or contains_word(post_wrd, 'year')):
                        try:
                            ii = 365
                            if(contains_word(post_wrd, 'years')):
                                dayy = int(find_before(find_after(strg,'and'),'years')) * ii
                            elif(contains_word(post_wrd, 'year')):
                                dayy = int(find_before(find_after(strg,'and'),'year')) * ii
                        except ValueError:
                            print('Invalid entry for years')
                        day = int(find_between(strg,'past','week'))
                        fin_day = (int(day)*7) + int(dayy)
                        date1 = find_day_date(str(fin_day)) # End of Past X Week and Y ____
                        date2 = find_date('today')
                        date = [date1,date2]
                else:
                    if(contains_word(strg[strg.find('past'):],'week')):
                        date1 = find_week_date('1') #End of Past X Week
                        date2 = find_date('today')
                        date = [date1,date2]
                    else:
                        if(find_between(strg,'past','weeks') == ' ' or find_between(strg,'past','weeks')== ''):
                            date1 = find_week_date('1') #End of Past X Weeks
                        else:
                            date1 = find_week_date(find_between(strg,'past','weeks')) #End of Past X Weeks
                        date2 = find_date('today')
                        date = [date1,date2]
            else:
                if(contains_word(strg,'weeks') and (no_word(strg,'last') and no_word(strg,'past') and no_word(strg,'this') and no_word(strg,'since') and no_word(strg,'last'))):
                    num = int(find_before(str(find_time_before(strg,'weeks')[0]),'weeks'))
                    date1 = find_week_date(num)
                    date2 = find_date('today')
                    date = [date1,date2]
                else:
                    date1 = find_day_date('10')
                    date2 = find_date('today')
                    date = [date1,date2]
                    
        elif(contains_word(strg,'week') and (no_word(strg,'last') and no_word(strg,'past') and no_word(strg,'this') and no_word(strg,'since') and no_word(strg,'last'))):
            num = int(find_before(str(find_time_before(strg,'week')[0]),'week'))
            date1 = find_week_date(num)
            date2 = find_date('today')
            date = [date1,date2]

        elif (contains_word(strg,'months') or (contains_word(strg,'past') and contains_word(strg,'month'))):
            if(contains_word(strg,'last')):
                date1 = find_month_date(find_between(strg,'last','months'))
                date2 = find_date('today')
                date = [date1,date2]
            elif(contains_word(strg,'since') and no_word(strg,'last') and no_word(strg,'past')):
                date1 = find_month_date(find_between(strg,'since','months'))
                date2 = find_date('today')
                date = [date1,date2]
            elif(contains_word(strg,'since') and contains_word(strg,'last') and no_word(strg,'past')):
                date1 = find_month_date(find_between(strg,'last','months'))
                date2 = find_date('today')
                date = [date1,date2]
            elif(contains_word(strg,'since') and no_word(strg,'past')):
                date1 = find_month_date(find_between(strg,'since','months'))
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'for') and no_word(strg,'past')):
                date1 = find_month_date(find_between(strg,'for','months'))
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'till') and no_word(strg,'past')):
                date1 = find_month_date(find_between(strg,'till','months'))
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'of') and no_word(strg,'past')):
                date1 = find_month_date(re.search(r'(\d+) months',strg).group(1))
                date2 = find_date('today')
                date = [date1,date2]
            elif(contains_word(strg,'past')):
                if(contains_word(strg,'months and')): # Start of Past X Months and Y ____
                    post_wrd = find_after(strg,'and')
                    if(contains_word(post_wrd, 'months') or contains_word(post_wrd, 'month')):
                        try:
                            ii = 31
                            if(contains_word(post_wrd, 'months')):
                                dayy = int(find_before(find_after(strg,'and'),'months')) * ii
                            elif(contains_word(post_wrd, 'month')):
                                dayy = int(find_before(find_after(strg,'and'),'month')) * ii
                        except ValueError:
                            print('Invalid entry for months')
                        day = int(find_between(strg,'past','months'))
                        fin_day = (int(day)*31) + int(dayy)
                        date1 = find_day_date(str(fin_day))
                        date2 = find_date('today')
                        date = [date1,date2]
                    elif(contains_word(post_wrd, 'years') or contains_word(post_wrd, 'year')):
                        try:
                            ii = 365
                            if(contains_word(post_wrd, 'years')):
                                dayy = int(find_before(find_after(strg,'and'),'years')) * ii
                            elif(contains_word(post_wrd, 'year')):
                                dayy = int(find_before(find_after(strg,'and'),'year')) * ii
                        except ValueError:
                            print('Invalid entry for years')
                        day = int(find_between(strg,'past','months'))
                        fin_day = (int(day)*31) + int(dayy)
                        date1 = find_day_date(str(fin_day)) # End of Past X Months and Y __
                        date2 = find_date('today')
                        date = [date1,date2]
                
                elif(contains_word(strg,'month and')):                  # Start of Past X Month and Y ____
                    post_wrd = find_after(strg,'and')
                    if(contains_word(post_wrd, 'months') or contains_word(post_wrd, 'month')):
                        try:
                            ii = 31
                            if(contains_word(post_wrd, 'months')):
                                dayy = int(find_before(find_after(strg,'and'),'months')) * ii
                            elif(contains_word(post_wrd, 'month')):
                                dayy = int(find_before(find_after(strg,'and'),'month')) * ii
                        except ValueError:
                            print('Invalid entry for months')
                        day = int(find_between(strg,'past','month'))
                        fin_day = (int(day)*31) + int(dayy)
                        date1 = find_day_date(str(fin_day))
                        date2 = find_date('today')
                        date = [date1,date2]
                    
                    elif(contains_word(post_wrd, 'years') or contains_word(post_wrd, 'year')):
                        try:
                            ii = 365
                            if(contains_word(post_wrd, 'years')):
                                dayy = int(find_before(find_after(strg,'and'),'years')) * ii
                            elif(contains_word(post_wrd, 'year')):
                                dayy = int(find_before(find_after(strg,'and'),'year')) * ii
                        except ValueError:
                            print('Invalid entry for years')
                        day = int(find_between(strg,'past','month'))
                        fin_day = (int(day)*31) + int(dayy)
                        date1 = find_day_date(str(fin_day)) # End of Past X Week and Y ____
                        date2 = find_date('today')
                        date = [date1,date2]
                else:
                    if(contains_word(strg[strg.find('past'):],'month')):
                        date1 = find_month_date('1') #End of Past X Month
                        date2 = find_date('today')
                        date = [date1,date2]
                    else:
                        
                        if(find_between(strg,'past','months') == ' ' or find_between(strg,'past','months')== ''):
                            date1 = find_month_date('1') #End of Past X Months
                        else:
                            date1 = find_month_date(find_between(strg,'past','months')) #End of Past X Months
                        date2 = find_date('today')
                        date = [date1,date2]
            else:
                if(contains_word(strg,'months') and (no_word(strg,'last') and no_word(strg,'past') and no_word(strg,'this') and no_word(strg,'since') and no_word(strg,'last'))):
                    num = int(find_before(str(find_time_before(strg,'months')[0]),'months'))
                    date1 = find_month_date(num)
                    date2 = find_date('today')
                    date = [date1,date2]
                else:
                    date1 = find_day_date('10')
                    date2 = find_date('today')
                    date = [date1,date2]
                    
        elif(contains_word(strg,'month') and (no_word(strg,'last') and no_word(strg,'past') and no_word(strg,'this') and no_word(strg,'since') and no_word(strg,'last'))):
                    num = int(find_before(str(find_time_before(strg,'month')[0]),'month'))
                    date1 = find_month_date(num)
                    date2 = find_date('today')
                    date = [date1,date2]

        elif (contains_word(strg,'years') or (contains_word(strg,'past') and contains_word(strg,'year'))):
            if(contains_word(strg,'last') and no_word(strg,'past')):
                date1 = find_year_date(find_between(strg,'last','years'))
                date2 = find_date('today')
                date = [date1,date2]
            elif(contains_word(strg,'since') and no_word(strg,'last') and no_word(strg,'past')):
                date1 = find_year_date(find_between(strg,'since','years'))
                date2 = find_date('today')
                date = [date1,date2]
            elif(contains_word(strg,'since') and contains_word(strg,'last') and no_word(strg,'past')):
                date1 = find_year_date(find_between(strg,'last','years'))
                date2 = find_date('today')
                date = [date1,date2]
            elif(contains_word(strg,'since') and no_word(strg,'past')):
                date1 = find_year_date(find_between(strg,'since','years'))
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'for') and no_word(strg,'past')):
                date1 = find_year_date(find_between(strg,'for','years'))
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'till') and no_word(strg,'past')):
                date1 = find_year_date(find_between(strg,'till','years'))
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'of') and no_word(strg,'past')):
                date1 = find_year_date(re.search(r'(\d+) years',strg).group(1))
                date2 = find_date('today')
                date = [date1,date2]
            elif(contains_word(strg,'past')):
                if(contains_word(strg,'years and')): # Start of Past X Months and Y ____
                    post_wrd = find_after(strg,'and')
                    if(contains_word(post_wrd, 'years') or contains_word(post_wrd, 'year')):
                        try:
                            ii = 365
                            if(contains_word(post_wrd, 'years')):
                                dayy = int(find_before(find_after(strg,'and'),'years')) * ii
                            elif(contains_word(post_wrd, 'year')):
                                dayy = int(find_before(find_after(strg,'and'),'year')) * ii
                        except ValueError:
                            print('Invalid entry for years')
                        day = int(find_between(strg,'past','years'))
                        fin_day = (int(day)*365) + int(dayy)
                        date1 = find_day_date(str(fin_day)) # End of Past X Months and Y __
                        date2 = find_date('today')
                        date = [date1,date2]
                
                elif(contains_word(strg,'year and')):                  # Start of Past X Month and Y ____
                    post_wrd = find_after(strg,'and')
                    if(contains_word(post_wrd, 'years') or contains_word(post_wrd, 'year')):
                        try:
                            ii = 365
                            if(contains_word(post_wrd, 'years')):
                                dayy = int(find_before(find_after(strg,'and'),'years')) * ii
                            elif(contains_word(post_wrd, 'year')):
                                dayy = int(find_before(find_after(strg,'and'),'year')) * ii
                        except ValueError:
                            print('Invalid entry for years')
                        day = int(find_between(strg,'past','year'))
                        fin_day = (int(day)*365) + int(dayy)
                        date1 = find_day_date(str(fin_day)) # End of Past X Week and Y ____
                        date2 = find_date('today')
                        date = [date1,date2]
                else:
                    if(contains_word(strg[strg.find('past'):],'year')):
                        date1 = find_year_date('1') #End of Past X Year
                        date2 = find_date('today')
                        date = [date1,date2]
                    else:
                        if(find_between(strg,'past','years') == ' ' or find_between(strg,'past','years')== ''):
                            date1 = find_year_date('1') #End of Past X Years
                        else:
                            date1 = find_year_date(find_between(strg,'past','years')) #End of Past X Years
                        date2 = find_date('today')
                        date = [date1,date2]
            
            else:
                if(contains_word(strg,'years') and (no_word(strg,'last') and no_word(strg,'past') and no_word(strg,'this') and no_word(strg,'since') and no_word(strg,'last'))):
                    num = int(find_before(str(find_time_before(strg,'years')[0]),'years'))
                    date1 = find_year_date(num)
                    date2 = find_date('today')
                    date = [date1,date2]
                else:
                    date1 = find_day_date('10')
                    date2 = find_date('today')
                    date = [date1,date2]
                    
        elif(contains_word(strg,'year') and (no_word(strg,'last') and no_word(strg,'past') and no_word(strg,'this') and no_word(strg,'since') and no_word(strg,'last'))):
                    num = int(find_before(str(find_time_before(strg,'year')[0]),'year'))
                    date1 = find_year_date(num)
                    date2 = find_date('today')
                    date = [date1,date2]

        elif (contains_word(strg,'today') and no_word(strg,'till') and no_word(strg,'from') and no_word(strg,'between') and no_word(strg,'to')):
                date1 = find_date('today')
                date2 = find_date('today')
                date = [date1,date2]

        elif (contains_word(strg,'yesterday') and no_word(strg,'till') and no_word(strg,'from') and no_word(strg,'between') and no_word(strg,'to')):
                date1 = find_date('yesterday')
                date2 = find_date('yesterday')
                date = [date1,date2]

        elif (contains_word(strg,'on')):
            date = find_spec_date(find_after(strg,'on'))
        
        elif (contains_word(strg,'till')  and no_word(strg,'from') and no_word(strg,'last year')):
            if (contains_word(strg,'till today')):
                date = find_date('today')
            elif (contains_word(strg,'till date')):
                date = find_date('today')
            elif (contains_word(strg,'till yesterday')):
                date1 = find_date('yesterday')
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'till last week')):
                date1 = find_last_date('week')
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'till this week')):
                date1 = find_last_date('week')
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'till last month')):
                date1 = find_last_date('month')
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'till this month')):
                date1 = find_last_date('month')
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'till last year')):
                date1 = find_last_date('year')
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'till this year')):
                date1 = find_last_date('year')
                date2 = find_date('today')
                date = [date1,date2]
            else:
                date1 = find_day_date('10')
                date2 = find_date('today')
                date = [date1,date2]

        elif (contains_word(strg,'since')):
            if(no_word(strg,'last') and no_word(strg,'this')):
                date1 = find_spec_date(find_after(strg,'since'))
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'since last week')):
                date1 = find_last_date('week')
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'since this week')):
                date1 = find_last_date('week')
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'since last month')):
                date1 = find_last_date('month')
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'since this month')):
                date1 = find_last_date('month')
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'since last year')):
                date1 = find_last_date('year')
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'since this year')):
                date1 = find_last_date('year')
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'to') and no_word(strg,'till')):
                if (contains_word(strg,'today')):
                    date1 = find_spec_date(find_after(find_before(strg,'to'),'since'))
                    date2 = find_date('today')
                    date = [date1,date2]
                elif (contains_word(strg,'yesterday')):
                    date1 = find_spec_date(find_after(find_before(strg,'to'),'since'))
                    date2 = find_date('yesterday')
                    date = [date1,date2]
                else:
                    date1 = find_spec_date(find_after(find_before(strg,'to'),'since'))
                    date2 = find_spec_date(find_after(strg,'to'))
                    date = [date1,date2]
            elif (contains_word(strg,'till')):
                if (contains_word(strg,'today')):
                    date1 = find_spec_date(find_after(find_before(strg,'till'),'since'))
                    date2 = find_date('today')
                    date = [date1,date2]
                elif (contains_word(strg,'yesterday')):
                    date1 = find_spec_date(find_after(find_before(strg,'till'),'since'))
                    date2 = find_date('yesterday')
                    date = [date1,date2]
                else:
                    date1 = find_spec_date(find_after(find_before(strg,'till'),'since'))
                    date2 = find_spec_date(find_after(strg,'till'))
                    date = [date1,date2] 
            else:
                date1 = find_day_date('10')
            date2 = find_date('today')
            date = [date1,date2]

        elif (contains_word(strg,'this')):
            if(no_word(strg,'last')):
                date1 = find_last_date(find_after(strg,'this'))
                date2 = find_date('today')
                date = [date1,date2]
            elif ('this last week' in strg):
                date1 = find_last_date('week')
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'this last month')):
                date1 = find_last_date('month')
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'this last year')):
                date1 = find_last_date('year')
                date2 = find_date('today')
                date = [date1,date2]
            else:
                date1 = find_day_date('10')
                date2 = find_date('today')
                date = [date1,date2]

        elif (contains_word(strg,'last')):
            if (contains_word(strg,'last week')):
                date1 = find_last_date('week')
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'last month')):
                date1 = find_last_date('month')
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'last year')):
                date1 = find_last_date('year')
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'day')):
                date1 = find_day_date(find_between(strg,'last','day'))
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'week')):
                date1 = find_week_date(find_between(strg,'last','week'))
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'month')):
                date1 = find_month_date(find_between(strg,'last','month'))
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'year')):
                date1 = find_year_date(find_between(strg,'last','year'))
                date2 = find_date('today')
                date = [date1,date2]
            else:
               date1 = find_day_date('10')
            date2 = find_date('today')
            date = [date1,date2]

        elif (contains_word(strg,'from')):
            if(no_word(strg,'to') and no_word(strg,'till') and no_word(strg,'yesterday') and no_word(strg,'today')):
                date1 = find_spec_date(find_after(strg,'from'))
                date2 = find_date('today')
                date = [date1,date2]

            elif (contains_word(strg,'yesterday') and no_word(strg,'till') and no_word(strg,'to')):
                date1 = find_date('yesterday')
                date2 = find_date('today')
                date = [date1,date2]

            elif (contains_word(strg,'today') and no_word(strg,'till') and no_word(strg,'to')):
                date = find_date('today')
                

            elif (contains_word(strg,'to') and no_word(strg,'till')):
                if (contains_word(strg,'today')):
                    date1 = find_spec_date(find_after(find_before(strg,'to'),'from'))
                    date2 = find_date('today')
                    date = [date1,date2]
                elif (contains_word(strg,'yesterday')):
                    date1 = find_spec_date(find_after(find_before(strg,'to'),'from'))
                    date2 = find_date('yesterday')
                    date = [date1,date2]
                else:
                    date1 = find_spec_date(find_after(find_before(strg,'to'),'from'))
                    date2 = find_spec_date(find_after(strg,'to'))
                    date = [date1,date2]

            elif (contains_word(strg,'till')):
                if (contains_word(strg,'today')):
                    date1 = find_spec_date(find_after(find_before(strg,'till'),'from'))
                    date2 = find_date('today')
                    date = [date1,date2]
                elif (contains_word(strg,'yesterday')):
                    date1 = find_spec_date(find_after(find_before(strg,'till'),'from'))
                    date2 = find_date('yesterday')
                    date = [date1,date2]
                else:
                    date1 = find_spec_date(find_after(find_before(strg,'till'),'from'))
                    date2 = find_spec_date(find_after(strg,'till'))
                    date = [date1,date2]

        elif (contains_word(strg,'between')):
            if (contains_word(strg,'today') and no_word(strg,'yesterday')):
                date1 = find_spec_date(find_after(find_before(strg,'and'),'between'))
                date2 = find_date('today')
                date = [date1,date2]
            elif (contains_word(strg,'yesterday') and no_word(strg,'today')):
                date1 = find_spec_date(find_after(find_before(strg,'and'),'between'))
                date2 = find_date('yesterday')
                date = [date1,date2]
            elif (contains_word(strg,'today') and contains_word(strg,'yesterday')):
            
                date1 = find_date('yesterday')
                date2 = find_date('today')
                date = [date1,date2]
                
            else:
                date1 = find_spec_date(find_after(find_before(strg,'and'),'between'))
                date2 = find_spec_date(find_after(strg,'and'))
                date = [date1,date2]
            
        elif (contains_word(strg,'to date')):
            date = find_date('today')
        
        elif (contains_word(strg,'today') or contains_word(strg,'today\'s') or contains_word(strg,'todays')):
            date = find_date('today')        
        
        elif (contains_word(strg,'yesterday') or contains_word(strg,'yesterday\'s') or contains_word(strg,'yesterdays')):
            date1 = find_date('yesterday')
            date2 = find_date('today')
            date = [date1,date2]
        
        else:
            date1 = find_day_date('10')
            date2 = find_date('today')
            date = [date1,date2]
                
    except Exception as e:
      date = 'EXCEPTION OCCURRED.'
        
        
            
    return date

def test_date1(): # run this function to test different questions
    questions = []
    questions = ['What is my expenditure today?','What is my expenditure yesterday?','what is my expenditure till last week?','What is my expenditure till last month?','What is my expenditure till last year?','What is my expenses today?','What is my expenses yesterday?','what is my expenses till last week?','What is my expenses till last month?','What is my expenses till last year?','What are my spendings today?','What are my spendings yesterday?','what are my spendings till last week?','What are my spendings till last month?','What are my spendings till last year?','How much have I spent today?','How much have I spent yesterday?','How much have I spent yesterday?','How much have I spent till last week?','How much have I spent till last month?','How much have I spent till last year?','How much have I spent since yesterday?','How much have I spent since last week?','How much have I spent since last month?','How much have I spent since last year?','How much did I spent today?','How much did I spent yesterday?','How much did I spent till last week?','How much did I spent till last month?','How much did I spent till last year?','How much did I spent since yesterday?','How much did I spent since last week?','How much did I spent since last month?','How much did I spent since last year?','What are my transactions today ?','What are my transactions yesterday ?','What are my transactions this week ?','What are my transactions last month ?','What are my transactions this year ?','What are my transactions last year ?','What are my transactions till yesterday ?','What are my transactions till last week ?','What are my transactions till last month ?','What are my transactions till this month ?','What are my transactions till this year ?','What are my transactions till last year ?','What are my transactions since yesterday ?','What are my transactions since this week ?','What are my transactions since last week ?','What are my transactions since this month ?','What are my transactions since last month ?','What are my transactions since this year ?','What are my transactions since last year ?','What are my transactions in the last 25 days?','What are my transactions in the last 3 weeks?','What are my transactions in the last 27 months?','What are my transactions in the last 5 years?','What are my expenses in the last 9 days?','What are my expenses in the last 8 weeks?','What are my expenses in the last 19 months?','What are my expenses in the last 22 years?','expenditure today?','expenditure yesterday?','expenditure till last week?','expenditure till last month?','expenditure till last year?','Get me expenses of 4 years','income of 3 weeks','mobile bill payments of past 4 days and 2 weeks','movies watched at PVR for past 3 years','income of past 1 month','show income of 4 months','Get all of my expenses at Hypercity for the past 4 days and 5 years','Get all of my cash withdrawals for the past 1 week and 3 months','Show me all my purchases at IKEA in the past 4 months and 2 years']
    for i in range(len(questions)):
        str_test = ''
        str_test = questions[i]
        #date_output = ''
        date_output = get_date(str_test)
        print(questions[i])
        print(date_output)

def test_date2(): # run this function to test the training scenarios in the getstatementsdatefinal.json file. Remember to modify the file path in the line below
    data_store =json.load(codecs.open('C:/Users/BAN153664/Desktop/CVA/getstatementsdatefinal.json', 'r', 'utf-8-sig'))
    data_store = data_store['rasa_nlu_data']['common_examples']
    qs = []
    for i in range(205):
        qs.append(data_store[i]['text'])
    
    for i in range(len(qs)):
        #str_test = ''
        str_test = qs[i]
        date_output = get_date(str_test)
        print(qs[i])
        print(date_output)
        print('_________________')
        print()

def start(string_eg): # Run this function to test
    a = True
    #while(a==True):
        #string_eg = input('Enter your question here (Type \'exit\' when you\'re done.): ')
    if (string_eg =='exit' or string_eg =='Exit'):
        print('Exiting application! goodbye!')
        a = False
        sys.exit()
    else:
        result = get_date(string_eg.lower())
        return result