# -*- coding: utf-8 -*-
"""
Created on Fri Oct 12 18:49:39 2018

@author: BAN153664
"""

import sys

from pymongo import MongoClient

class MongoDbConnectivity:

    def getMongoConnection():
        try:
            conn = MongoClient('10.50.72.51',27028)
            print("Connected successfully!!!")
        except:
            print("Could not connect to MongoDB")
        return conn

    def getMongoData(conn,dbname,collectionsName):
        db = conn.dbname
        collection = db.collectionsName
        cursor = collection.find()
        return cursor
def compute_principal1(emi, r, t):
    r = r / (12 * 100) # one month interest
    t = t * 12 # one month period
    #emi = (p * r * pow(1 + r, t)) / (pow(1 + r, t) - 1)
    p = (emi * (pow(1 + r, t) - 1) ) / (r * pow(1 + r, t))
    #p = round(p / 100) * 100
    return (round(p))

def compute_emi(p, r, t):
    r = r / (12 * 100) # one month interest
    t = t # one month period
    #emi = (p * r * pow(1 + r, t)) / (pow(1 + r, t) - 1)
    emi = p * (r * pow(1 + r, t)) / (pow(1 + r, t) - 1)
    #emi = round(emi / 10) * 10
    return (round(emi))

def case_1(nam,funds, price, dclim, pqoff, sal, pl, plpq,plpqamt):
    if(funds > 0):
        if(price > funds):
            if (pqoff is True):
                if(plpq is True and plpqamt > price and compute_emi(price,11,12) <= funds):
                    valuation = ['VAL:\nSo it looks like you might not have enough funds ( Rs.'+"{:,}".format(funds)+' ) in your savings. I\'d recommend that you wait to make this purchase. <br/>Although, You are eligible for a pre-qualified Credit card and a Personal Loan of Rs.'+str(plpqamt)+' either of which could be used to make this purchase.']
                    recoms = ['REC:\nYou are eligible for a pre-qualified Credit card. You could apply for one and use it to make this purchase. \nYou are also Pre-Qualified for a Personal Loan of '+str(plpqamt)+'. Your average funds in savings would be enough to afford the loan for this product. You could apply for one to finance your purchase! \nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'0']
                elif(plpq is True and plpqamt > price and compute_emi(price,11,12) > funds):
                    valuation = ['VAL:\nSo it looks like you might not have enough funds ( Rs.'+"{:,}".format(funds)+' ) in your savings to buy this or to afford the EMI on your Pre-Qualified Personal Loan. <br/>I\'d recommend that you wait to make this purchase. \n\nAlthough, You are eligible for a pre-qualified Credit card that could be used to make this purchase.']
                    recoms = ['REC:\nYou are eligible for a pre-qualified Credit card. You could apply for one and use it to make this purchase \nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'0']
                else:
                    valuation = ['VAL:\nSo it looks like you might not have enough funds ( Rs.'+"{:,}".format(funds)+' ) in your savings. I\'d recommend that you wait to make this purchase. <br/>Although, You are eligible for a pre-qualified Credit card that could be used to make this purchase.']
                    recoms = ['REC:\nYou are eligible for a pre-qualified Credit card. You could apply for one and use it to make this purchase \nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'0']
            elif(pqoff is False):
                if(plpq is True and plpqamt > price and compute_emi(price,11,12) <= funds):
                    valuation = ['VAL:\nSo it looks like you might not have enough funds ( Rs.'+"{:,}".format(funds)+' ) in your savings. <br/>I\'d recommend that you wait  to make this purchase. \n\nAlthough..You are Pre-Qualified for a Personal Loan of Rs.'+str(plpqamt)+' that could be used to finance your purchase!']
                    recoms = ['REC:\n\nYou are Pre-Qualified for a Personal Loan of '+str(plpqamt)+'. You could apply for one to finance your purchase! \nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'0']
                elif(plpq is True and plpqamt > price and compute_emi(price,11,12) > funds):
                   valuation = ['VAL:\nSo it looks like you might not have enough funds ( Rs.'+"{:,}".format(funds)+' ) in your savings to buy this or to afford the EMI on your Pre-Qualified Personal Loan. <br/>I\'d recommend that you wait to make this purchase. You know a credit card would help you make purchases in such situations. You could apply for one!']
                   recoms = ['REC:\nYou know a credit card would help you make purchases in such situations. Why don\'t you apply for one here : https://www.icicibank.com/card/credit-cards/credit-card.page? \nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                   return [valuation,recoms,'0']
                elif(compute_emi(price,11,12) <= funds):
                   valuation = ['VAL:\nSo it looks like you might not have enough funds ( Rs.'+"{:,}".format(funds)+' ) in your savings to buy this<br/>But you could afford to make this purchase via a Personal Loan at 11% interest for 1 year.<br/>You know a credit card would help you make purchases in such situations. You could apply for one!']
                   recoms = ['REC:\nYou know a credit card would help you make purchases in such situations. Why don\'t you apply for one here : https://www.icicibank.com/card/credit-cards/credit-card.page? \nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                   return [valuation,recoms,'1']
                else:
                    valuation = ['VAL:\nSo it looks like you might not have enough funds ( Rs.'+"{:,}".format(funds)+' ) in your savings. <br/>I\'d recommend that you wait to make this purchase. You know a credit card would help you make purchases in such situations. You could apply for one!']
                    recoms = ['REC:\nYou are eligible for a pre-qualified Credit card. You could apply for one and use it to make this purchase \nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'0']
        elif(price < funds):
            if (pqoff is True):
                if(plpq is True and plpqamt > price and compute_emi(price,11,12) <= funds):
                    valuation = ['VAL:So it looks like you should have enough funds ( Rs.'+"{:,}".format(funds)+' ) in your savings to make this purchase. <br/>You are eligible for a pre-qualified Credit card and also Pre-Qualified for a Personal Loan of '+str(plpqamt)+'. You could apply for either of them to finance your purchase, as an alternative!']
                    recoms = ['REC:\nYou are eligible for a pre-qualified Credit card and also Pre-Qualified for a Personal Loan of '+str(plpqamt)+'. You could apply for one to finance your purchase! \nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
                if(plpq is True and plpqamt > price and compute_emi(price,11,12) > funds):
                    valuation = ['VAL:So it looks like you should have enough funds ( Rs.'+"{:,}".format(funds)+' ) in your savings to make this purchase. <br/>You are eligible for a pre-qualified Credit card You could apply for it to finance your purchase, as an alternative!']
                    recoms = ['REC:\nYou are eligible for a pre-qualified Credit card and also Pre-Qualified for a Personal Loan of '+str(plpqamt)+'. You could apply for one to finance your purchase! \nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
                else:
                    valuation = ['VAL:So it looks like you should have enough funds ( Rs.'+"{:,}".format(funds)+' ) in your savings to make this purchase.<br/>You are also eligible for a pre-qualified Credit card. You could apply for one and use it to make this purchase']
                    recoms = ['REC:\nYou are eligible for a pre-qualified Credit card. You could apply for one and use it to make this purchase \nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
            elif(pqoff is False):
                if(plpq is True and plpqamt > price and compute_emi(price,11,12) <= funds):
                    valuation = ['VAL:So it looks like you should have enough funds ( Rs.'+"{:,}".format(funds)+' ) in your savings to make this purchase. <br/>You are also Pre-Qualified for a Personal Loan of '+str(plpqamt)+'. Your average funds in savings would be enough to afford the loan for this product. You could apply for one to finance your purchase, as an alternative!']
                    recoms = ['REC:\n\nYou are Pre-Qualified for a Personal Loan of '+str(plpqamt)+'. You could apply for one to finance your purchase! \nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
                else:
                    valuation = ['VAL:So it looks like you should have enough funds ( Rs.'+"{:,}".format(funds)+' ) in your savings to make this purchase.\n']
                    recoms = ['REC:\nYou know a credit card would help you make purchases in such situations. Why don\'t you apply for one here : https://www.icicibank.com/card/credit-cards/credit-card.page? \nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
    else:
        valuation = ['VAL:I\'m not sure if this purchase will be possible at the moment since I am unable to assess suffcient funds.<br/>My advice would be to wait to make this purchase!']
        recoms = ['REC:\nPerhaps if you applied for a credit card you could make this purchase, but your current lack of funds could be an issue when it comes to paying back your credit card bill. I would recommend that you improve your savings funds.']
        return[valuation,recoms,'0']


def case_2(nam, funds, price, dclim, pqoff, sal, ccfunds, pl, plpq, plpqamt):
    if(ccfunds > 0):
        if(price < ccfunds):
            if(plpq is True and plpqamt > price and compute_emi(price,11,12) <= funds):
                valuation = ['VAL:Great! You have sufficient funds on your credit card/cards ( Rs.'+str(ccfunds)+' )..\nSo I\'d would suggest that you use your credit card for this purchase. <br/>You are also Pre-Qualified for a Personal Loan of '+str(plpqamt)+'. Your average funds in savings would be enough to afford the loan for this product. You could apply for one to finance your puchase, as an alternative!']
                recoms = ['REC:\n\nYou are Pre-Qualified for a Personal Loan of '+str(plpqamt)+'. You could apply for one to finance your purchase! \nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                return [valuation,recoms,'1']
            else:
                valuation = ['VAL:Great! You have sufficient funds on your credit card/cards ( Rs.'+str(ccfunds)+' )...\nSo I\'d would suggest that you use your credit card for this purchase']
                recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                return [valuation,recoms,'1']
        else:
            if(plpq is True and plpqamt > price and compute_emi(price,11,12) <= funds):
                valuation = ['VAL:So it looks like\nyou might not have enough funds in your savings ( Rs.'+"{:,}".format(funds)+' ) or on your credit card/cards ( Rs.'+str(ccfunds)+' ). <br/>Perhaps, you should consider waiting to make this purchase.']
                recoms = ['REC:\n\nYou are Pre-Qualified for a Personal Loan of '+str(plpqamt)+'. You could apply for one to finance your purchase! \nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                return [valuation,recoms,'0']
            else:
                valuation = ['VAL:So it looks like\nyou might not have enough funds in your savings ( Rs.'+"{:,}".format(funds)+' ) or on your credit card/cards ( Rs.'+str(ccfunds)+' ). <br/>Perhaps, you should consider waiting to make this purchase.']
                recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                return [valuation,recoms,'0']
    else:
        valuation = ['VAL:I\'d suggest that you wait to make this purchase since it looks like your Credit Card limit has been reached and I am unable to assess suffcient funds in your savings!']
        recoms = ['REC:\nPerhaps if you applied for a credit card you could make this purchase, but your current lack of funds could be an issue when it comes to paying back your credit card bill. I would recommend that you improve your savings funds.']
        return[valuation,recoms,'0']


def case_3(nam,funds, price, dclim, pqoff, sal,ccfunds, pl,plpq,plpqamt):
    if(price < ccfunds):
        if(plpq is True and plpqamt > price and compute_emi(price,11,12) <= funds):
            valuation = ['VAL:So it looks like you have enough funds in both your savings ( Rs.'+"{:,}".format(funds)+' ) and on your credit card/cards ( Rs.'+str(ccfunds)+' ) to make this purchase.<br/>You are also Pre-Qualified for a Personal Loan of '+str(plpqamt)+'. Your average funds in savings would be enough to afford the loan for this product. You could apply for one to finance your puchase, as an alternative!']
            recoms = ['REC:\n\nYou are Pre-Qualified for a Personal Loan of '+str(plpqamt)+'. You could apply for one to finance your purchase! \nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
            return [valuation,recoms,'1']
        else:
            valuation = ['VAL:So it looks like you have enough funds in both your savings ( Rs.'+"{:,}".format(funds)+' ) and on your credit card/cards ( Rs.'+str(ccfunds)+' ) to make this purchase. ']
            recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
            return [valuation,recoms,'1']
    else:
        if(plpq is True and plpqamt > price and compute_emi(price,11,12) <= funds):
            valuation = ['VAL:So it looks like you have enough funds ( Rs.'+"{:,}".format(funds)+' ) in savings. \nI\'d reccomend that you use your savings for this purchase. <br/>You are also Pre-Qualified for a Personal Loan of '+str(plpqamt)+'. Your average funds in savings would be enough to afford the loan for this product. You could apply for one to finance your puchase, as an alternative!']
            recoms = ['REC:\n\nYou are Pre-Qualified for a Personal Loan of '+str(plpqamt)+'. You could apply for one to finance your purchase! \nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
            return [valuation,recoms,'1']

        else:
            valuation = ['VAL:So it looks like you have enough funds ( Rs.'+"{:,}".format(funds)+' ) in savings. <br/>I\'d reccomend that you use your savings for this purchase']
            recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
            return [valuation,recoms,'1']



def case_4(nam,loan_ch,price,funds,pl,al,hl,twl,pl_pq,plpq_amt,hl_pq,hlpq_amt,al_pq,alpq_amt,twl_pq,twlpq_amt,hlpq_tenure,alpq_tenure,plpq_tenure,twlpq_tenure):
    if(funds > 0):
        if(loan_ch == '1'):
            if(hl is False and hl_pq is True and hlpq_amt >= price):
                hlpq_emi = compute_emi(hlpq_amt,9,hlpq_tenure)
                if(hlpq_emi <= funds):
                    valuation = ['VAL:Great! I\'d reccomend taking out a Home Loan for this. Also, your average funds of Rs.'+"{:,}".format(funds)+' will be enough to afford this purchase. <br/>And it looks like you are already Pre-Qualified for a Home Loan upto Rs.'+"{:,}".format(hlpq_amt)+' with an EMI of Rs.'+str(hlpq_emi)+' for it at 9% interest for '+str(round(hlpq_tenure/12))+' years.']
                    recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
                elif(hlpq_emi > funds and compute_emi(price,9,hlpq_tenure) <= funds):
                    valuation = ['VAL:Great! I\'d reccomend taking out a Home Loan for this. Also, your average funds of Rs.'+"{:,}".format(funds)+' will be enough to afford this purchase. <br/>And it looks like you are already Pre-Qualified for a Home Loan of Rs.'+"{:,}".format(hlpq_amt)+' at 9% interest for '+str(round(hlpq_tenure/12))+' years. <br/>I\'d recommend that you avail of your PQ offer for an amount of Rs.'+"{:,}".format(price)]
                    recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
                else:
                    prod_emi = compute_emi(price,9,hlpq_tenure)
                    if((prod_emi - round(funds) < 1000) and (prod_emi - round(funds) >= 200)):
                        valuation = ['VAL: Well you have a PQ Home Loan offer for Rs.'+"{:,}".format(hlpq_amt)+'! <br/>While, based on your average funds of Rs.'+"{:,}".format(funds)+', you should be able to afford this purchase by reducing your expenditure by a couple thousand rupees.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    elif((prod_emi - round(funds) < 200)):
                        valuation = ['VAL:Well you have a PQ Home Loan offer for Rs.'+"{:,}".format(hlpq_amt)+'! <br/>Also, based on your average funds of Rs.'+"{:,}".format(funds)+', a slight adjustment in your expense should suffice to make this purchase affordable.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    else:
                        valuation = ['VAL:Hmmm..Your average funds of Rs.'+"{:,}".format(funds)+' will not be enough to afford this purchase. <br/>Perhaps you could consider reducing your expenditure in order to finance the Rs.'+"{:,}".format(prod_emi)+' EMI for this purchase.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'0']
            elif(hl is False and hl_pq is True and hlpq_amt < price):
                hl_amt = compute_principal1(funds,9,round(hlpq_tenure/12))
                prod_emi = compute_emi(price,9,hlpq_tenure)
                if(hl_amt < price and (prod_emi - round(funds)) > 0):
                    if((prod_emi - round(funds) < 1000) and (prod_emi - round(funds) >= 200)):
                        valuation = ['VAL:Well, you have a Pre-Qualfied Home Loan worth Rs.'+"{:,}".format(hlpq_amt)+'. <br/>Also, based on you your average funds of Rs.'+"{:,}".format(funds)+', you should be able to afford this purchase by reducing your expenditure by a couple thousand rupees.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    elif((prod_emi - round(funds) < 200)):
                        valuation = ['VAL:Well, you have a Pre-Qualfied Home Loan worth Rs.'+"{:,}".format(hlpq_amt)+'. <br/>And, based on your average funds of Rs.'+"{:,}".format(funds)+', a slight adjustment in your expense should suffice to make this purchase affordable.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    else:
                        valuation = ['VAL:Perhaps you should hold out on this purchase for now! Your Pre-Qualfied Home Loan worth Rs.'+"{:,}".format(hlpq_amt)+' doesn\'t cover the entire amount.<br/>I\'d recommend that you first increase your funds from Rs.'+"{:,}".format(funds)+' to Rs.'+"{:,}".format(prod_emi)]
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'0']
                else:
                    valuation = ['VAL:Awesome! You should be able to afford this purchase. Your Pre-Qualfied Home Loan worth Rs.'+"{:,}".format(hlpq_amt)+' doesn\'t cover the entire amount. <br/>But, your average funds are about Rs.'+"{:,}".format(funds)+', which should be sufficient to afford the overhead amount.']
                    recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
            elif(hl is True):
                valuation = ['VAL:Well looks like you have already taken out a Home Loan. Perhaps you should hold out on this purchase for now!']
                recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                return [valuation,recoms,'0']
            else:
                hl_amt = compute_principal1(funds,9,20)
                if(hl_amt >= 50000000):
                    hl_loan_amt = 50000000
                else:
                    hl_loan_amt = hl_amt
                prod_emi = compute_emi(price,9,240)
                if(price > hl_loan_amt):
                    if((prod_emi - round(funds) < 1000) and (prod_emi - round(funds) >= 200)):
                        valuation = ['VAL:I\'d recommend applying for a Home Loan. Based on your average funds of Rs.'+"{:,}".format(funds)+', you should be able to afford this purchase by reducing your expenditure by a couple thousand rupees']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    elif((prod_emi - round(funds) < 200)):
                        valuation = ['VAL:I\'d recommend applying for a Home Loan. Based on your average funds of Rs.'+"{:,}".format(funds)+', a slight adjustment in your expense should suffice to make this purchase affordable.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    else:
                        valuation = ['VAL:Perhaps you should hold out on this purchase for now! Your average funds are about Rs.'+"{:,}".format(funds)+' which would get you a Home loan amount upto Rs.'+"{:,}".format(hl_loan_amt)+' at 9% for 20 years that would not be sufficient to afford this purchase.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'0']
                else:
                    valuation = ['VAL:Looks like you can afford this purchase I\'d suggest you take out a Home Loan for it. Your average funds are about Rs.'+"{:,}".format(funds)+' which should be sufficient to afford an EMI for this purchase.']
                    recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
        elif(loan_ch=='2'):
            if(al is False and al_pq is True and alpq_amt >= price):
                alpq_emi = compute_emi(alpq_amt,10,alpq_tenure)
                if(alpq_emi < funds):
                    valuation = ['VAL:Great! I\'d reccomend taking out an Auto Loan for this. Also, your average funds of Rs.'+"{:,}".format(funds)+' will be enough to afford this purchase. <br/>And it looks like you are already Pre-Qualified for an Auto Loan upto Rs.'+"{:,}".format(alpq_amt)+' with an EMI of Rs.'+"{:,}".format(alpq_emi)+' for it at 10% interest for '+str(round(alpq_tenure/12))+' years.']
                    recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
                elif(alpq_emi > funds and compute_emi(price,10,alpq_tenure) <= funds):
                    valuation = ['VAL:Great! I\'d reccomend taking out an Auto Loan for this. Also, your average funds of Rs.'+"{:,}".format(funds)+' will be enough to afford this purchase. <br/>And it looks like you are already Pre-Qualified for an Auto Loan of Rs.'+"{:,}".format(alpq_amt)+' at 10% interest for '+str(round(alpq_tenure/12))+' years. <br/>I\'d recommend that you avail of your PQ offer for an amount of Rs.'+"{:,}".format(price)]
                    recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
                else:
                    prod_emi = compute_emi(price,10,alpq_tenure)
                    if((prod_emi - round(funds) < 1000) and (prod_emi - round(funds) >= 200)):
                        valuation = ['VAL:Alright SO! Based on your average funds of Rs.'+"{:,}".format(funds)+', you should be able to afford this purchase by reducing your expenditure by a couple of thousand rupees.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    elif((prod_emi - round(funds) < 200)):
                        valuation = ['VAL:Alright SO! Based on your average funds of Rs.'+"{:,}".format(funds)+', a slight adjustment in your expense should suffice to make this purchase affordable.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    else:
                        valuation = ['VAL:Hmmm..It looks like your average funds of Rs.'+"{:,}".format(funds)+' will not be enough to afford this purchase. <br/>Perhaps you could consider reducing your expenditure in order to finance the Rs.'+"{:,}".format(prod_emi)+' EMI for this purchase.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'0']
            elif(al is False and al_pq is True and alpq_amt < price):
                al_amt = compute_principal1(funds,10,round(alpq_tenure/12))
                prod_emi = compute_emi(price,10,alpq_tenure)
                if(al_amt < price and (prod_emi - round(funds)) > 0):
                    if((prod_emi - round(funds) < 1000) and (prod_emi - round(funds) >= 200)):
                        valuation = ['VAL:Alright SO! You do have a Pre-Qualfied Auto Loan worth Rs.'+"{:,}".format(alpq_amt)+'.<br/>Also, based on your average funds of Rs.'+"{:,}".format(funds)+', you should be able to afford this purchase by reducing your expenditure by a couple of thousand rupees.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    elif((prod_emi - round(funds) < 200)):
                        valuation = ['VAL:Alright SO! You do have a Pre-Qualfied Auto Loan worth Rs.'+"{:,}".format(alpq_amt)+'.<br/>Also, based on your average funds of Rs.'+"{:,}".format(funds)+', a slight adjustment in your expense should suffice to make this purchase affordable.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    else:
                        valuation = ['VAL:Perhaps you should hold out on this purchase for now! Your Pre-Qualfied Auto Loan worth Rs.'+"{:,}".format(alpq_amt)+' doesn\'t cover the entire amount.  Also, your average funds of Rs.'+"{:,}".format(funds)+' would not be enough. <br/>I\'d recommend that you first increase your funds from Rs.'+"{:,}".format(funds)+' to Rs.'+"{:,}".format(prod_emi)]
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'0']
                else:
                    valuation = ['VAL:Awesome! You should be able to afford this purchase. Your Pre-Qualfied Auto Loan worth Rs.'+"{:,}".format(alpq_amt)+' doesn\'t cover the entire amount. <br/>But, your average funds are about Rs.'+"{:,}".format(funds)+', which should be sufficient to afford the overhead amount.']
                    recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
            elif(al is True):
                valuation = ['VAL:Well looks like you have already taken out an Auto Loan. Perhaps you should hold out on this purchase for now!']
                recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                return [valuation,recoms,'0']
            else:
                al_loan_amt = compute_principal1(funds,10,7)
                prod_emi = compute_emi(price,10,84)
                if(price > al_loan_amt):
                    if((prod_emi - round(funds) < 1000) and (prod_emi - round(funds) >= 200)):
                        valuation = ['VAL:Alright so... I\'d recommend applying for an Auto Loan. Based on your average funds of Rs.'+"{:,}".format(funds)+', you should be able to afford this purchase by reducing your expenditure by a couple of thousand rupees.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    elif((prod_emi - round(funds) < 200)):
                        valuation = ['VAL:Alright so... I\'d recommend applying for an Auto Loan. Based on your average funds of Rs.'+"{:,}".format(funds)+', a slight adjustment in your expense should suffice to make this purchase affordable.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    else:
                        valuation = ['VAL:Perhaps you should hold out on this purchase for now! Your average funds are about Rs.'+"{:,}".format(funds)+' which would get you a loan amount upto Rs.'+"{:,}".format(al_loan_amt)+' at 10% for 7 years that would not be sufficient to afford this purchase.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'0']
                else:
                    valuation = ['VAL:Alright so... I\'d suggest you take out a Auto Loan for it. Your average funds are about Rs.'+"{:,}".format(funds)+' which should be sufficient to afford an EMI for this purchase.']
                    recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']

        elif(loan_ch=='3'):
            if(twl is False and twl_pq is True and twlpq_amt >= price):
                twlpq_emi = compute_emi(twlpq_amt,9,twlpq_tenure)
                if(twlpq_emi < funds):
                    valuation = ['VAL:Great! I\'d reccomend taking out a Two Wheeler Loan for this. Also, your average funds of Rs.'+"{:,}".format(funds)+' will be enough to afford this purchase. <br/>And it looks like you are already Pre-Qualified for a 2 Wheeler Loan upto Rs.'+"{:,}".format(twlpq_amt)+' with an EMI of Rs.'+"{:,}".format(twlpq_emi)+' for it at 9% interest for '+str(round(twlpq_tenure/12))+' years.']
                    recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
                elif(twlpq_emi > funds and compute_emi(price,9,twlpq_tenure) <= funds):
                    valuation = ['VAL:Great! I\'d reccomend taking out a Two Wheeler Loan for this. Also, your average funds of Rs.'+"{:,}".format(funds)+' will be enough to afford this purchase. <br/>And it looks like you are already Pre-Qualified for a 2 Wheeler Loan of Rs.'+"{:,}".format(twlpq_amt)+' at 9% interest for '+str(round(twlpq_tenure/12))+' years. <br/>I\'d recommend that you avail of your PQ offer for an amount of Rs.'+"{:,}".format(price)]
                    recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
                else:
                    prod_emi = compute_emi(price,9,twlpq_tenure)
                    if((prod_emi - round(funds) < 1000) and (prod_emi - round(funds) >= 200)):
                        valuation = ['VAL:Alright so... based on your average funds of Rs.'+"{:,}".format(funds)+', you should be able to afford this purchase by reducing your expenditure by a couple of thousand rupees.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    elif((prod_emi - round(funds) < 200)):
                        valuation = ['VAL:Alright so... based on your average funds of Rs.'+"{:,}".format(funds)+', a slight adjustment in your expense should suffice to make this purchase affordable.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    else:
                        valuation = ['VAL:Hmmm..It looks like your average funds of Rs.'+"{:,}".format(funds)+' will not be enough to afford this purchase. <br/>Perhaps you could consider reducing your expenditure in order to finance the Rs.'+"{:,}".format(prod_emi)+' EMI for this purchase.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'0']
            elif(twl is False and twl_pq is True and twlpq_amt < price):
                twl_amt = compute_principal1(funds,9,round(twlpq_tenure/12))
                prod_emi = compute_emi(price,9,twlpq_tenure)
                if(twl_amt < price and (prod_emi - round(funds)) > 0):
                    if((prod_emi - round(funds) < 1000) and (prod_emi - round(funds) >= 200)):
                        valuation = ['VAL:Alright so... you do have a Pre-Qualfied 2 Wheeler Loan worth Rs.'+"{:,}".format(twlpq_amt)+'.<br/>Also, based on your average funds of Rs.'+"{:,}".format(funds)+', you should be able to afford this purchase by reducing your expenditure by a couple of thousand rupees.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    elif((prod_emi - round(funds) < 200)):
                        valuation = ['VAL:Alright so... you do have a Pre-Qualfied 2 Wheeler Loan worth Rs.'+"{:,}".format(twlpq_amt)+'.<br/>Also, based on your average funds of Rs.'+"{:,}".format(funds)+', a slight adjustment in your expense should suffice to make this purchase affordable.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    else:
                        valuation = ['VAL:Perhaps you should hold out on this purchase for now! Your Pre-Qualfied 2 Wheeler Loan worth Rs.'+"{:,}".format(twlpq_amt)+' doesn\'t cover the entire amount. <br/>Also, your average funds of Rs.'+"{:,}".format(funds)+' would not be enough to afford it. I\'d recommend that you first increase your funds from Rs.'+"{:,}".format(funds)+' to Rs.'+"{:,}".format(prod_emi)]
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'0']
                else:
                    valuation = ['VAL:Awesome! You should be able to afford this purchase. Your Pre-Qualfied 2 Wheeler Loan worth Rs.'+"{:,}".format(twlpq_amt)+' doesn\'t cover the entire amount. <br/>But, your average funds are about Rs.'+"{:,}".format(funds)+', which should be sufficient to afford the overhead amount.']
                    recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
            elif(twl is True):
                valuation = ['VAL:Well looks like you have already taken out a 2 Wheeler Loan. Perhaps you should hold out on this purchase for now!']
                recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                return [valuation,recoms,'0']
            else:
                twl_loan_amt = compute_principal1(funds,9,1)
                prod_emi = compute_emi(price,9,12)
                if(price > twl_loan_amt):
                    if((prod_emi - round(funds) < 1000) and (prod_emi - round(funds) >= 200)):
                        valuation = ['VAL:Alright so... I\'d recommend applying for a 2 Wheeler Loan. Based on your average funds of Rs.'+"{:,}".format(funds)+', you should be able to afford this purchase by reducing your expenditure by a couple of thousand rupees.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    elif((prod_emi - round(funds) < 200)):
                        valuation = ['VAL:Alright so... I\'d recommend applying for a 2 Wheeler Loan. Based on your average funds of Rs.'+"{:,}".format(funds)+', a slight adjustment in your expense should suffice to make this purchase affordable.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    else:
                        valuation = ['VAL:Perhaps you should hold out on this purchase for now! Your average funds are about Rs.'+"{:,}".format(funds)+' which would get you a loan amount upto Rs.'+"{:,}".format(twl_loan_amt)+' at 9% for 1 year that would not be sufficient to afford this purchase.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'0']
                else:
                    valuation = ['VAL:Alright so... I\'d suggest you take out a 2 Wheeler Loan for it. Your average funds are about Rs.'+"{:,}".format(funds)+' which should be sufficient to afford an EMI for this purchase.']
                    recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
        elif(loan_ch =='4'):
            if(pl_pq is True and plpq_amt >= price):
                plpq_emi = compute_emi(plpq_amt,11,plpq_tenure)
                if(plpq_emi < funds):
                    valuation = ['VAL:Great! I\'d reccomend taking out a Personal Loan for this. Also, your average funds of Rs.'+"{:,}".format(funds)+' will be enough to afford this purchase. <br/>And it looks like you are already Pre-Qualified for a Personal Loan upto Rs.'+"{:,}".format(plpq_amt)+' with an EMI of Rs.'+"{:,}".format(plpq_emi)+' for it at 11% interest for '+str(round(plpq_tenure/12))+' years.']
                    recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
                elif(plpq_emi > funds and compute_emi(price,11,plpq_tenure) <= funds):
                    valuation = ['VAL:Great! I\'d reccomend taking out a Personal Loan for this. Also, your average funds of Rs.'+"{:,}".format(funds)+' will be enough to afford this purchase. <br/>And it looks like you are already Pre-Qualified for a Personal Loan of Rs.'+"{:,}".format(plpq_amt)+' at 11% interest for '+str(round(plpq_tenure/12))+' years. <br/>I\'d recommend that you avail of your PQ offer for an amount of Rs.'+"{:,}".format(price)]
                    recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
                else:
                    prod_emi = compute_emi(price,11,plpq_tenure)
                    if((prod_emi - round(funds) < 1000) and (prod_emi - round(funds) >= 200)):
                        valuation = ['VAL:Alright so... based on your average funds of Rs.'+"{:,}".format(funds)+', you should be able to afford this purchase by reducing your expenditure by a couple of thousand rupees.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    elif((prod_emi - round(funds) < 200)):
                        valuation = ['VAL:Alright so... based on your average funds of Rs.'+"{:,}".format(funds)+', a slight adjustment in your expense should suffice to make this purchase affordable.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    else:
                        valuation = ['VAL:Hmmm..It looks like your average funds of Rs.'+"{:,}".format(funds)+' will not be enough to afford this purchase. <br/>Perhaps you could consider reducing your expenditure in order to finance the Rs.'+"{:,}".format(prod_emi)+' EMI for this purchase.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'0']
            elif(pl_pq is True and plpq_amt < price):
                pl_amt = compute_principal1(funds,11,round(plpq_tenure/12))
                prod_emi = compute_emi(price,11,plpq_tenure)
                if(pl_amt < price and (prod_emi - round(funds)) > 0):
                    if((prod_emi - round(funds) < 1000) and (prod_emi - round(funds) >= 200)):
                        valuation = ['VAL:Alright so... you do have a Pre-Qualfied Personal Loan worth Rs.'+"{:,}".format(plpq_amt)+'.<br/>Also, based on your average funds of Rs.'+"{:,}".format(funds)+', you should be able to afford this purchase by reducing your expenditure by a couple of thousand rupees.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    elif((prod_emi - round(funds) < 200)):
                        valuation = ['VAL:Alright so... you do have a Pre-Qualfied Personal Loan worth Rs.'+"{:,}".format(plpq_amt)+'.<br/>Also, based on your average funds of Rs.'+"{:,}".format(funds)+', a slight adjustment in your expense should suffice to make this purchase affordable.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    else:
                        valuation = ['VAL:Perhaps you should hold out on this purchase for now! Your Pre-Qualfied Personal Loan worth Rs.'+"{:,}".format(plpq_amt)+' doesn\'t cover the entire amount. <br/>Also, your average funds of Rs.'+"{:,}".format(funds)+' would not be enough to afford it. I\'d recommend that you first increase your funds from Rs.'+"{:,}".format(funds)+' to Rs.'+"{:,}".format(prod_emi)]
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'0']
                else:
                    valuation = ['VAL:Awesome! You should be able to afford this purchase. Your Pre-Qualfied Personal Loan worth Rs.'+"{:,}".format(plpq_amt)+' doesn\'t cover the entire amount. <br/>But, your average funds are about Rs.'+"{:,}".format(funds)+', which should be sufficient to afford the overhead amount.']
                    recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']
            else:
                pl_loan_amt = compute_principal1(funds,11,1)
                prod_emi = compute_emi(price,11,12)
                if(price > pl_loan_amt):
                    if((prod_emi - round(funds) < 1000) and (prod_emi - round(funds) >= 200)):
                        valuation = ['VAL:Alright so... I\'d recommend applying for a Personal Loan. Based on your average funds of Rs.'+"{:,}".format(funds)+', you should be able to afford this purchase by reducing your expenditure by a couple of thousand rupees.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    elif((prod_emi - round(funds) < 200)):
                        valuation = ['VAL:Alright so... I\'d recommend applying for a Personal Loan. Based on your average funds of Rs.'+"{:,}".format(funds)+', a slight adjustment in your expense should suffice to make this purchase affordable.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'1']
                    else:
                        valuation = ['VAL:Perhaps you should hold out on this purchase for now! Your average funds are about Rs.'+"{:,}".format(funds)+' which would get you a loan amount upto Rs.'+"{:,}".format(pl_loan_amt)+' at 11% interest for 1 year that would not be sufficient to afford this purchase.']
                        recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                        return [valuation,recoms,'0']
                else:
                    valuation = ['VAL:Alright so... I\'d suggest you take out a Personal Loan for it. Your average funds are about Rs.'+"{:,}".format(funds)+' which should be sufficient to afford an EMI for this purchase.']
                    recoms = ['REC:\nYou can also create an I-Wish account to help you setup and plan for this purchase as a goal?']
                    return [valuation,recoms,'1']



        elif(loan_ch == 'exit' or loan_ch == 'quit'):
            sys.exit()
        else:
            print('Oops..looks like you typed something wrong! Choices from 1 to 4 are only valid. Try Again!')
    elif(funds == 0):
        valuation = ['VAL:I\'m not sure if this purchase will be possible at the moment since I am unable to assess suffcient funds.<br/>My advice would be to wait to make this purchase!']
        recoms = ['REC:\nI don\'t have any recommendations at the moment. Your expenses seem to be equal to your income. \nAs a result you don\'t seem to have any funds in your savigs. Hence it would be ahrd for you to make this purchase or to pay back the EMI on a loan.']
        return[valuation,recoms,'0']

def start(inp_vec,price,prod,category,loan,loan_cat):
    pl = (inp_vec['PL_Availed'])
    if (pl == 'null'):
        pl = False
    else:
        pl = True
    pl_pq = (inp_vec['PL_PQ_OFFER'])
    if (pl_pq == 'null'):
        pl_pq = False
    else:
        pl_pq = True
    plpq_amt = inp_vec['PL_PQ_AMOUNT']
    if (plpq_amt == 'null'):
        plpq_amt = float(0)
    else:
        plpq_amt = float(plpq_amt)
    plpq_tenure = inp_vec['PL_PQ_TENURE']
    if (plpq_tenure == 'null'):
        plpq_tenure = 0
    else:
        plpq_tenure = int(plpq_tenure)
    hl = (inp_vec['HL_Availed'])
    if (hl == 'null'):
        hl = False
    else:
        hl = True
    hl_pq = (inp_vec['HL_PQ_OFFER'])
    if (hl_pq == 'null'):
        hl_pq = False
    else:
        hl_pq = True
    hlpq_amt = inp_vec['HL_PQ_AMOUNT']
    if (hlpq_amt == 'null'):
        hlpq_amt = float(0)
    else:
        hlpq_amt = float(hlpq_amt)
    hlpq_tenure = inp_vec['HL_PQ_TENURE']
    if (hlpq_tenure == 'null'):
        hlpq_tenure = 0
    else:
        hlpq_tenure = int(hlpq_tenure)
    al = (inp_vec['AL_Availed'])
    if (al == 'null'):
        al = False
    else:
        al = True
    al_pq = (inp_vec['AL_PQ_OFFER'])
    if (al_pq == 'null'):
        al_pq = False
    else:
        al_pq = True
    alpq_amt = inp_vec['AL_PQ_AMOUNT']
    if (alpq_amt == 'null'):
        alpq_amt = float(0)
    else:
        alpq_amt = float(alpq_amt)
    alpq_tenure = inp_vec['AL_PQ_TENURE']
    if (alpq_tenure == 'null'):
        alpq_tenure = 0
    else:
        alpq_tenure = int(alpq_tenure)
    twl = (inp_vec['TWL_Availed'])
    if (twl == 'null'):
        twl = False
    else:
        twl = True
    twl_pq = (inp_vec['TWL_PQ_OFFER'])
    if (twl_pq == 'null'):
        twl_pq = False
    else:
        twl_pq = True
    twlpq_amt = inp_vec['TWL_PQ_AMOUNT']
    if (twlpq_amt == 'null'):
        twlpq_amt = float(0)
    else:
        twlpq_amt = float(twlpq_amt)
    twlpq_tenure = inp_vec['TWL_PQ_TENURE']
    if (twlpq_tenure == 'null'):
        twlpq_tenure = 0
    else:
        twlpq_tenure = int(twlpq_tenure)
    liq = inp_vec['SA_Calculated_LIQUIDITY']
    if(liq == 'null'):
        liq = float(0)
    else:
        liq = float(liq)
    #mab = inp_vec[3]
    dc_limit = (inp_vec['DC_TRAN_LIMIT'])
    if(dc_limit == 'null'):
        dc_limit = float(0)
    else:
        dc_limit = float(dc_limit)
    cc_liq = inp_vec['CC_Balance']
    if (cc_liq == 'null'):
        cc_liq = float(0)
    else:
        cc_liq = float(cc_liq)
    salary = inp_vec['Salary']
    if (salary == 'null'):
        salary = float(0)
    else:
        salary = float(salary)
    if (inp_vec['CC_PQ_OFFER'] ==1):
        pq_off = True
    else:
        pq_off = False
    price = float(price)
    nam = inp_vec['Full_Name']
    cc_avld = inp_vec['CC_Availed']
    if (cc_avld == 'null'):
        cc_avld = False
    else:
        cc_avld = True
    if(price < max(liq,cc_liq)):
        loan = '0'
    else:
        loan = '1'
    if (loan == '0'):
        #print(cc_avld)
        if (cc_avld is False):
            final_res = case_1(nam,liq,price,dc_limit,pq_off,salary,pl,pl_pq, plpq_amt)
        elif (cc_avld is True):
            if(price < liq):
                final_res = case_3(nam,liq,price,dc_limit,pq_off,salary,cc_liq,pl,pl_pq, plpq_amt)
            elif(price > liq):
                final_res = case_2(nam,liq,price,dc_limit,pq_off,salary,cc_liq,pl,pl_pq, plpq_amt)

    elif (loan == '1'):#Print statements are fonrt end functionality
        loan_ch = loan_cat
        final_res = case_4(nam,loan_ch,price,liq,pl,al,hl,twl,pl_pq,plpq_amt,hl_pq,hlpq_amt,al_pq,alpq_amt,twl_pq,twlpq_amt,hlpq_tenure,alpq_tenure,plpq_tenure,twlpq_tenure)
    return final_res
    #return [hlpq_tenure,alpq_tenure,plpq_tenure,twlpq_tenure]

def main(uid,price,product,category,loan,loan_cat): # loan = 1 if price > 1 lac else 0 #loan_cat = 1,2,3,4 (home,auto,2wheeler,personal)
    conn = MongoDbConnectivity.getMongoConnection()
    df = list(conn.convai.AMAZE_CUSTOMER_MASTER_NEW_2.find({'LINKED_USERID':uid}))
    a = dict(df[0])
    price = float(price)
    result = start(a,float(price),product,category,loan,loan_cat)
    return result
