const url = 'http://10.50.72.76:8081/api/v1';



function fetchhistory()
{
	
	fetch(`${url}/SHREERAMUNIQ139/fetchhistory`, {
			method: 'GET'
		})
        .then(function (response) {
            return response.json();
        })
        .then(function (responses) {
		 if(responses)
		 {
			for (var i in responses){
			 var j = JSON.parse(responses[i])
			 console.log(j["USER_ID"], "==", j["MSG"])
			 document.getElementById("printhere").innerHTML += j["MSG"] +"\n <br/>"
		 }}  
		})
        .catch(function (err) {
			
        });		
}