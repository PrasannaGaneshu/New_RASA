// Author: Shriram Perumal


var $messages = $('.messages-content'),act_resp, comp_intent, just_intent, map_div_num
var i = 0;
var klo = 0;
var tstamp = 0;
var weather_x = 0;
var auth = false;
var div_name="chsrtdiv_0";
var div_time="tymstmp_0";
var user_session_id="00no00";
var draw_C_for="";	  
var conv_start="", conv_index="";
var overall_from_location =""
var overall_to_location =""
var msg = "";
var rest_list = [];
var f_response = null;
var intent = "";
var caniafford_product = ""
var caniafford_merchant = ""
var caniafford_price = ""
var check_price = ""
var div_map_var = 0;
var culinary_pitched = 0;
var flag_invalid = false;
let id = Math.floor(Math.random() * 1000 + 1);
const url = 'http://10.50.72.76:8087/api/v1';


//----ON WINDOWS LOADING----
$(window).load(function() {
  $messages.mCustomScrollbar();
  suggesttoggle();
  hamtoggle();

  document.getElementById('div_tooltip').style.display = 'none';
  user_session_id = (localStorage.getItem("storageName")).toUpperCase();
  f_response = localStorage.getItem("responses");
  
  
  if (f_response){
	msg = f_response;
	$('<div class="message_first new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + f_response + '</div>').appendTo($('.mCSB_container')).addClass('new');
	setDate();
	updateScrollbar();
	auth=true;
	firstdataforuserid="LLLLLLLLLLLL0000000000000>"+user_session_id
	get_bot_response(firstdataforuserid)
	chathistory(user_session_id,"SESSION_LOGIN","BOT",format_time(),"CAPTUREUSERID");
	getLocation()
	}
  else if(!f_response){
	alert("false")
	}
    document.getElementById('div_tooltip').style.display = 'inline';
});
  
//---BOT RESPONSE----
function botResponse() {
  if ($('.message-input').val() != '') { 
  return false;
  }
  $('<div class="message loading new"><div class="avatar"><img src="image/single-logo.png" /></div><span></span></div>').appendTo($('.mCSB_container'));
  updateScrollbar();
  $('.message-input').focus();

  setTimeout(function() { $('.message.loading').remove();
    get_bot_response(msg);
    setDate();
    updateScrollbar();
    $('.message-input').focus();
	i++; }, 1000 + (Math.random() * 20) * 100);
}

//---hamburger menu---
  function hamtoggle()
{   
    var x = document.getElementById("hammenu");
	var y = document.getElementById("btn_hamopclo");
    if (x.style.display == "none") {
        x.style.display = "block";
		document.getElementById("btn_hamopclo").style.color="red";
    } else{
        x.style.display = "none";
		y.style.color = "#C0C0C0";		
    }
}

//---user suggestion---
function suggesttoggle()
{  
    var x = document.getElementById("usersuggest");
    if (x.style.display == "none") {
				while (x.firstChild) {
			x.removeChild(x.firstChild);
		}
		opacity: 1;
        x.style.display = "block";
		x.setAttribute("class","e_style_1")
    } else {
		x.style.display = "none";
		// 
		opacity: 0; 
    }
}

function tooltipon()
{document.getElementById('div_tooltip').style.display = 'none';}
function tooltipoff()
{document.getElementById('div_tooltip').style.display = 'none';}

function chng_send_msg_button(){
  console.log("PUT SOMETHING HERE");
  /* var selector = document.getElementById('submit_img_go');
  selector.src = "../icons/send_main_go.png";
  document.getElementById('submit_img').style.content = "url('../icons/send_main_go.png');"; */
}
  var latitude="", longitude="";

//---get browser location---
// function showLocation(position) {
  // latitude = position.coords.latitude;
  // longitude = position.coords.longitude;
  // console.log(latitude,longitude);
  // data = {userid:user_session_id, lat:latitude,	lon:longitude}
  // fetch(`${url}/${id}/lgusrloc`, {method: 'POST', body: JSON.stringify(data)})}
  // function errorHandler(err)
  // {
    // if(err.code == 1)
    // { 
        // //alert("Error: Location Access is unavailable!");
        // console.log("Error: Location Access is unavailable!");
    // }
    // else if( err.code == 2) 
    // { }
  // }
			
  // function getLocation() {
	// if(navigator.geolocation) {
		// var options = {timeout:60000}; navigator.geolocation.getCurrentPosition(showLocation, errorHandler, options);		
		// } 

	// else {}}
	
	
	
	
	function getLocation(){
		if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else { 
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
		
		
	}
	function showPosition(position) {
    var htmllocation = "Latitude: " + position.coords.latitude + 
    "<br>Longitude: " + position.coords.longitude;
}
		 

//---click to send----
$('.message-submit').click(function() {
  msg12 = $('.message-input').val(); 
  if (msg12 == "" || msg12 == null){
	alert("Please Type Something...");
	$('.message-input').css('background','lightpink');
	$('.message-input').attr("placeholder", "Please Type Something First.....");
	return false;
  }
  $('.message-input').css('background','none');
  $('.message-input').attr("placeholder", "Type message...");
  insertMessage();
});

$(window).on('keydown', function(e) {
  if (e.which == 13) {
	msg12 = $('.message-input').val(); 
	if (msg12 == "" || msg12 == null){
		alert("Sorry I didn't detect any input from you!!");
		$('.message-input').css('background','lightpink');
		$('.message-input').attr("placeholder", "Please Type Something First.....");
		return false;
	}
	$('.message-input').css('background','none');
	$('.message-input').attr("placeholder", "Type message...");
    insertMessage();
    return false;
  }
})
//only numbers for price input

//CHANGELOG :: trying to disable scroll when ctrl is pressed. :: starts
//disable scrolling when CTRL key is pressed
$(window).on('keypress',function(e)
{
    if(e.which == 17 || e.which == 18)
    {
        var x = window.scrollX;
        var y = window.scrollY;
        window.onscroll=function(){window.scrollTo(x, y);};
    }
})

function detectspecialkeys(e){
    var evtobj=window.event? event : e
    if (evtobj.altKey || evtobj.ctrlKey || evtobj.shiftKey)
        alert("you pressed one of the 'Alt', 'Ctrl', or 'Shift' keys")
}
document.onkeypress=detectspecialkeys
// CHANGELOG :: ends

//----scroll bar------
function updateScrollbar() {
  $messages.mCustomScrollbar("update").mCustomScrollbar('scrollTo', 'bottom', {
    scrollInertia: 10,
    timeout: 0
  });
}

//---- conversation date-----
function setDate(timestamppurp){
  date_obj = new Date();
  var hour = date_obj.getHours();
  var minute = date_obj.getMinutes();
  var seconds = date_obj.getSeconds();
  var amorpm = (hour > 11) ? "PM" : "AM";
  if(hour > 12) {
    hour -= 12;
  } else if(hour == 0) {
    hour = "12";
  }
  if(minute < 10) {
    minute = "0" + minute;
  }
  today_conv = hour + ":" + minute + " "+amorpm;  
  
  if(timestamppurp == "map") 
  {
	$('<div id='+div_time+' class="timestamp">' + today_conv + '</div>').appendTo($('.message_noborder:last'));
  }
  else{
	$('<div id='+div_time+' class="timestamp">' + today_conv + '</div>').appendTo($('.message:last'));
  }
   tstamp++;
   div_time = "tymstmp_" + tstamp;
   
   greeting(hour)
}

greet = "";
function greeting(houroftheday){
	
	if (houroftheday < 12)
        greet = 'Good Morning ';
    else if (houroftheday >= 12 && houroftheday <= 17)
        greet = 'Good Afternoon ';
    else if (houroftheday >= 17 && houroftheday <= 24)
        greet = 'Good Evening ';
	
}


function format_time() {
  var epoch = moment(new Date()).unix();
  return epoch;
}

function conversion_back(epochdate)
{
	var datecon	= parseInt(epochdate)*1000
	var epoch = new Date(datecon)
	const monthNames = ["January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December"];
	var fullDate = epoch.getFullYear().toString() + "-" + monthNames[epoch.getMonth()]+"-"+epoch.getDate();
	return fullDate
}


//---User input to chat area---
function insertMessage() {
	//console.log("MSG SENT TO NLU ENG : "+msg)
	if($('.message-input').val() != '')
	{ 
		msg = $('.message-input').val(); 
	}
    if ($.trim(msg) == '') 
	{ 
		return false; 
	}
	
	$('<div class="message message-personal">' + msg + '<div class="usatar"><img src="image/usericon.png" /></div></div>').appendTo($('.mCSB_container')).addClass('new');
  
	if (user_session_id != "00no00")
	{ 
		chathistory(user_session_id, msg, "USER", format_time(),"Y2F")
	} //---Write to history
	setDate();
	updateScrollbar();
	$('.message-input').val(null);
	  
	setTimeout(function() {	
		console.log("== msg ==>", msg, "== conv_start ==>", conv_start,"== conv_index ==>",conv_index);
		if (msg == "yes" || msg == "no")
		{
			console.log("==== convo msg====");
			convo(msg);
		}
		else if(conv_index == "AMIELEGIBL_indexone" || conv_index == "AMIELEGIBL_indextwo" || conv_index == "Pref_GETCABPREFERENCE")
		{
			console.log("==== can I afford [msg]====");
			if(conv_index == "AMIELEGIBL_indextwo"){
				if(true)
                { 
					console.log("=");
				}
			}
			convo(msg);
		}
		else if(conv_index == "AMIELEGIBL_indexthree" && flag_invalid == true){
			convo(msg);
		}
		
        else if(conv_index == "cab_loc_indexone"){
			overall_from_location = msg;
			convo(msg);
		}
		else if(conv_index == "cab_loc_indextwo"){
			overall_to_location = msg;
			msg = "book me a cab from "+overall_from_location+" to "+overall_to_location;
			botResponse(msg);
		}
        else
		{
			console.log("--==--BOT RESPONSE==>>");
			botResponse(msg);	
		}
	}, 1000 + (Math.random() * 20) * 100);
}


//---User response suggestion---
function createsuggestion(wtsug)
{
	var e_style="border:1px solid #B5B5B5; background-color:#fff; color:#2C3A41; border-radius: 20px; height:33px; width:137px; font-size:15px;  position:relative; margin-left:6px; outline:none;";
	var ee_style="border:1px solid #B5B5B5; background-color:#fff; color:#2C3A41; border-radius: 20px; height:33px; width:200px; font-size:15px;  position:relative; margin-left:6px; outline:none;";
    var eee_style="border:1px solid #B5B5B5; background-color:#fff; color:#2C3A41; border-radius: 20px; height:33px; width:210px; font-size:15px;  position:relative; margin-left:6px; outline:none;";
    var eeee_style="border:1px solid #B5B5B5; background-color:#fff; color:#2C3A41; border-radius: 20px; height:33px; width:280px; font-size:15px;  position:relative; margin-left:6px; outline:none;";
    var foo = document.getElementById("usersuggest");
	
	var close_btn = document.createElement("button"); 
	var btn_style = "float:right;display:inline-block;padding:2px 5px;background:#ccc;"
	close_btn.setAttribute("style",btn_style);
	close_btn.setAttribute("id","close1");
	close_btn.innerHTML = "x";
	close_btn.onclick = function(){
		foo.style.display = "none";
        return false;
	}
	foo.appendChild(close_btn);
	
	if (wtsug =='GOOUT')
	{	
		var btn = document.createElement("button");
		btn.setAttribute("style",e_style) //changed from class to style
		btn.innerHTML = "Yes! I am."
		btn.onclick = function() { // Note this is a function
		msg = "yes";
		insertMessage();
		suggesttoggle();}
		
		var btn1 = document.createElement("button");
		btn1.setAttribute("style",e_style)
		btn1.innerHTML = "No! I am not."
		btn1.onclick = function() { // Note this is a function
		msg = "no";
		insertMessage();
		suggesttoggle();
		}
	    foo.appendChild(btn);
	    foo.appendChild(btn1);
	}
	else if (wtsug =='NECAB')
	{
		var btn = document.createElement("button");
		btn.setAttribute("style",e_style)
		btn.innerHTML = "Yeah! I need a ride."
		btn.onclick = function() { // Note this is a function
		msg = "yes";
		insertMessage();
		suggesttoggle();}
		
		var btn1 = document.createElement("button");
		btn1.setAttribute("style",e_style)
		btn1.innerHTML = "Not required"
		btn1.onclick = function() { // Note this is a function
		msg = "no";
		insertMessage();
		suggesttoggle();
		}
	    foo.appendChild(btn);
	    foo.appendChild(btn1);
	}
	else if (wtsug =='CONFMCAB')
	{
		var btn = document.createElement("button");
		btn.setAttribute("style",e_style)
		btn.innerHTML = "Yes, book it"
		btn.onclick = function() { // Note this is a function
		msg = "yes";
		insertMessage();
		suggesttoggle();}
		
		var btn1 = document.createElement("button");
		btn1.setAttribute("style",e_style)
		btn1.innerHTML = "No, cancel it"
		btn1.onclick = function() { // Note this is a function
		msg = "no";
		insertMessage();
		suggesttoggle();
		}
		
		/* var btn2 = document.createElement("button");
		btn2.setAttribute("style",e_style)
		btn2.innerHTML = "change locations"
		btn2.onclick = function() { // Note this is a function
		msg = "change locations";
		insertMessage();
		suggesttoggle();
		} */
		foo.appendChild(btn);
		foo.appendChild(btn1);
		//foo.appendChild(btn2);
	}
	else if (wtsug =='NEEDHOMEDEL')
	{
		var btn = document.createElement("button");
		btn.setAttribute("style",e_style)
		btn.innerHTML = "Yeah! Pls do."
		btn.onclick = function() { // Note this is a function
		msg = "yes";
		insertMessage();
		suggesttoggle();}
		
		var btn1 = document.createElement("button");
		btn1.setAttribute("style",e_style)
		btn1.innerHTML = "Not required"
		btn1.onclick = function() { // Note this is a function
		msg = "no";
		insertMessage();
		suggesttoggle();
		}
	    foo.appendChild(btn);
	    foo.appendChild(btn1);
	}
	else if (wtsug =="CABPREFER")
	{
		var btn = document.createElement("button");
		btn.setAttribute("style",e_style)
		btn.innerHTML = "Ola"
		btn.onclick = function() { // Note this is a function
		msg = "Ola";
		insertMessage();
		suggesttoggle();
		}
		
		var btn1 = document.createElement("button");
		btn1.setAttribute("style",e_style)
		btn1.innerHTML = "Uber"
		btn1.onclick = function() { // Note this is a function
		msg = "Uber";
		insertMessage();
		suggesttoggle();
		}
	    foo.appendChild(btn);
	    foo.appendChild(btn1);
	}
   else if (wtsug =="ACC_BALANCE_SUGGESTION")
	{
		var btn = document.createElement("button");
		btn.setAttribute("style",e_style)
		btn.innerHTML = "ac bal"
		btn.onclick = function() { // Note this is a function
		msg = "ac bal";
		insertMessage();
		suggesttoggle();
		}
		
		var btn1 = document.createElement("button");
		btn1.setAttribute("style",e_style)
		btn1.innerHTML = "whats my acct bal"
		btn1.onclick = function() { // Note this is a function
		msg = "whats my acct bal";
		insertMessage();
		suggesttoggle();
		}
	    foo.appendChild(btn);
	    foo.appendChild(btn1);
	}
    else if (wtsug =="CR_CARD_OUT_SUGGESTION")
	{
		var btn = document.createElement("button");
		btn.setAttribute("style",e_style)
		btn.innerHTML = "cc outstanding"
		btn.onclick = function() { // Note this is a function
		msg = "cc outstanding";
		insertMessage();
		suggesttoggle();
		}
		
		var btn1 = document.createElement("button");
		btn1.setAttribute("style",ee_style)
		btn1.innerHTML = "whats my credit card balance"
		btn1.onclick = function() { // Note this is a function
		msg = "whats my credit card balance";
		insertMessage();
		suggesttoggle();
		}
	    foo.appendChild(btn);
	    foo.appendChild(btn1);
	}
	else if (wtsug =="APPLY_CHEQUE_BOOK_SUGGESTION")
	{
		var btn = document.createElement("button");
		btn.setAttribute("style",ee_style)
		btn.innerHTML = "apply for new check book"
		btn.onclick = function() { // Note this is a function
		msg = "apply for new check book";
		insertMessage();
		suggesttoggle();
		}
		
		var btn1 = document.createElement("button");
		btn1.setAttribute("style",e_style)
		btn1.innerHTML = "new check book"
		btn1.onclick = function() { // Note this is a function
		msg = "new check book";
		insertMessage();
		suggesttoggle();
		}
	    foo.appendChild(btn);
	    foo.appendChild(btn1);
	}
	else if (wtsug =="APPLY_CHEQUE_BOOK_SUGGESTION_YN")
	{
		var btn = document.createElement("button");
		btn.setAttribute("style",e_style)
		btn.innerHTML = "Yes!"
		btn.onclick = function() { // Note this is a function
		msg = "Yes";
		insertMessage();
		suggesttoggle();
		}
		
		var btn1 = document.createElement("button");
		btn1.setAttribute("style",e_style)
		btn1.innerHTML = "No!"
		btn1.onclick = function() { // Note this is a function
		msg = "no";
		insertMessage();
		suggesttoggle();
		}
	    foo.appendChild(btn);
	    foo.appendChild(btn1);
	}
	else if (wtsug =="EXP_ANALYSIS_SUGGESTION")
	{
		var btn = document.createElement("button");
		btn.setAttribute("style",ee_style)
		btn.innerHTML = "trans in the last 2 years"
		btn.onclick = function() { // Note this is a function
		msg = "trans in the last 2 years";
		insertMessage();
		suggesttoggle();
		}
		
		var btn1 = document.createElement("button");
		btn1.setAttribute("style",e_style)
		btn1.innerHTML = "txns this week"
		btn1.onclick = function() { // Note this is a function
		msg = "txns this week";
		insertMessage();
		suggesttoggle();
		}
	    foo.appendChild(btn);
	    foo.appendChild(btn1);
	}
	else if (wtsug =="UPCOMING_EXP_SUGGESTION")
	{
		var btn = document.createElement("button");
		btn.setAttribute("style",e_style)
		btn.innerHTML = "upcoming exp"
		btn.onclick = function() { // Note this is a function
		msg = "upcoming exp";
		insertMessage();
		suggesttoggle();
		}
		
		var btn1 = document.createElement("button");
		btn1.setAttribute("style",ee_style)
		btn1.innerHTML = "show my upcoming expenses"
		btn1.onclick = function() { // Note this is a function
		msg = "show my upcoming expenses";
		insertMessage();
		suggesttoggle();
		}
	    foo.appendChild(btn);
	    foo.appendChild(btn1);
	}
	else if (wtsug =="HAM_WEATHER_SUGGESTION")  //{POST FALLBACK CHANGE}
	{
		var btn = document.createElement("button");
		btn.setAttribute("style",eee_style)
		btn.innerHTML = "whats the weather like"
		btn.onclick = function() { // Note this is a function
		msg = "whats the weather like";
		insertMessage();
		suggesttoggle();
		}
		
		var btn1 = document.createElement("button");
		btn1.setAttribute("style",e_style)
		btn1.innerHTML = "weather in delhi"
		btn1.onclick = function() { // Note this is a function
		msg = "weather in delhi";
		insertMessage();
		suggesttoggle();
		}
	    foo.appendChild(btn);
	    foo.appendChild(btn1);
	}
	else if (wtsug =="HAM_RESTAURANT_SUGGESTION") //{POST FALLBACK CHANGE}
	{
		var btn = document.createElement("button");
		btn.setAttribute("style",ee_style)
		btn.innerHTML = "restaurants in bandra"
		btn.onclick = function() { // Note this is a function
		msg = "restaurants in bandra";
		insertMessage();
		suggesttoggle();
		}
		
		var btn1 = document.createElement("button");
		btn1.setAttribute("style",ee_style)
		btn1.innerHTML = "hotels near me"
		btn1.onclick = function() { // Note this is a function
		msg = "hotels near me";
		insertMessage();
		suggesttoggle();
		}
		
		/* var btn2 = document.createElement("button");
		btn2.setAttribute("style",e_style)
		btn2.innerHTML = "chinese food near me"
		btn2.onclick = function() { // Note this is a function
		msg = "chinese food near me";
		insertMessage();
		suggesttoggle();
		} */
		
	    foo.appendChild(btn);
	    foo.appendChild(btn1);
		//foo.appendChild(btn2);
	}
	else if (wtsug =="HAM_CAB_BOOK_SUGGESTION")
	{
		var btn = document.createElement("button");
		btn.setAttribute("style",e_style)
		btn.innerHTML = "get me a cab"
		btn.onclick = function() { // Note this is a function
		msg = "get me a cab";
		insertMessage();
		suggesttoggle();
		}
		
		/* var btn1 = document.createElement("button");
		btn1.setAttribute("style",eee_style)
		btn1.innerHTML = "get me a cab from thane to bandra"
		btn1.onclick = function() { // Note this is a function
		msg = "get me a cab from thane to bandra";
		insertMessage();
		suggesttoggle();
		} */
	    foo.appendChild(btn);
	    //foo.appendChild(btn1);
	}
}

//----Conversation (TO BE MOVED TO PYTHON)----------
function convo(analyze_string)
{
	console.log("==analyze_string==",analyze_string, "==conv_index==",conv_index, "==conv_start==", conv_start);
	if (conv_index =='first')
	{
		if (conv_start =='GETWET'){ 
			pop_msg = "Are you planning to go out?"	
			conv_start = 'GETWET';
            updateScrollbar();
            $('.message-input').focus();
		}
		else if(conv_start =='GETRES'){
			pop_msg = "Are you planning to dine here?"
			conv_start = 'GETRES';
		}
		$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + pop_msg + '</div>').appendTo($('.mCSB_container')).addClass('new');
		setDate();
		updateScrollbar();
        $('.message-input').focus();
		conv_index = 'response_YN';
		suggesttoggle();
		createsuggestion("GOOUT");
	}
	else if (conv_index =='response_YN')
	{
		if (analyze_string.includes("yes") | analyze_string.includes("yeah") | analyze_string.includes("sure") | analyze_string.includes("Yes") | analyze_string.includes("Yeah"))
		{
			if (conv_start =='GETWET'){
				conv_start = 'GETWET';
			}
			else if(conv_start =='GETRES'){
				conv_start = 'GETRESCAB';
			}
			if(conv_start == 'GETRESCAB')
            {
            culinary_treats_1();
            culinary_pitched = 1;
            }
            pop_msg = "Do you need a cab?"
			$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + pop_msg + '</div>').appendTo($('.mCSB_container')).addClass('new');
			setDate();
			updateScrollbar();
            $('.message-input').focus();
			conv_index = 'analyze_CYN'
			suggesttoggle();
			createsuggestion("NECAB");
		}
		else if (analyze_string.includes("no") | analyze_string.includes("not now") | analyze_string.includes("nope") | analyze_string.includes("nah") | analyze_string.includes("No") | analyze_string.includes("Nope") | analyze_string.includes("Nah"))
		{
			if(conv_start =='GETRES'){
				conv_start = 'GETRES';
				pop_msg = "Need home delivery ??";
				conv_index = "analyze_CYN";
				suggesttoggle();
				createsuggestion("NEEDHOMEDEL");
			}
			else{
				pop_msg = "Ok cool.. no problem. please let me know if you need something else";
				conv_index = ""; conv_start = "";
			}
			$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' +pop_msg+ '</div>').appendTo($('.mCSB_container')).addClass('new');
			setDate();
			updateScrollbar();
            $('.message-input').focus();
		}
	}
	else if (conv_index == 'analyze_CYN')
	{
		if (analyze_string.includes("yes") | analyze_string.includes("yeah") | analyze_string.includes("sure") | analyze_string.includes("Yes") | analyze_string.includes("Yeah"))
		{
			if (conv_start =='GETWET' || conv_start=='GETRESCAB'){
				conv_start = 'GETWET';
				// pop_msg = "Are you sure you want me to book a cab from " + overall_from_location + " to "+ overall_to_location + "?"; //COMEHERE
				// cab_map(overall_from_location,overall_to_location,pop_msg);
				// suggesttoggle();
				// createsuggestion("CONFMCAB");
				//prefetch_f_location = respo[1];
				//prefetch_t_location = respo[2];
				div_map_var++;
                enable_location_finder();
				initMap();
			}
			else if(conv_start =='GETRES'){
				conv_start = 'GETRES';
				pop_msg = "Shall I redirect to Zomato's website? You can get your food delivered at home !";
				suggesttoggle();
				createsuggestion("NEEDHOMEDEL");
				$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + pop_msg+'</div>').appendTo($('.mCSB_container')).addClass('new');
				setDate();
				updateScrollbar();
			}
			
			conv_index = 'response_CBKC';
		}
		else if (analyze_string.includes("no") | analyze_string.includes("not now") | analyze_string.includes("nope") | analyze_string.includes("nah") | analyze_string.includes("No") | analyze_string.includes("Nope") | analyze_string.includes("Nah"))
		{
			if(conv_start =='GETRESCAB'){
				conv_start = 'GETRES';
				pop_msg = "Need home delivery ??";
				conv_index = "analyze_CYN";
				suggesttoggle();
				createsuggestion("NEEDHOMEDEL");
			}
			else{
				pop_msg = "Ok cool.. no problem. please let me know if you need something else";
				conv_index = ""; conv_start = "";
                //culinary_pitched = 0;
			}
			$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + pop_msg+ '</div>').appendTo($('.mCSB_container')).addClass('new');
			setDate();
			updateScrollbar();
            $('.message-input').focus();
		}
	}
	else if (conv_index == 'Pref_GETCABPREFERENCE')
	{
		console.log("STEP : 3")
		var cabprefer = "";
		if (conv_start =="GETWET")
		{
			if (msg.includes("Ola") | msg.includes("OLA"))
			{
				cabprefer = "Ola";
			}
			else if (msg.includes("Uber") | msg.includes("UBER"))
			{
				cabprefer = "Uber";
			}
			msg = "book a cab from "+ overall_from_location + " to "+overall_to_location;
			// cab_map(overall_from_location,overall_to_location, "<b>Greetings from " + cabprefer+" !</b> Your cab from "+overall_from_location+ " to "+overall_to_location+" is booked. You can track it from your app.","confirmed" )
			//msg_to_print = "<b>Greetings from " + cabprefer+" !</b> Your cab from "+overall_from_location+ " to "+overall_to_location+" is booked. You can track it from your app.","confirmed"
            msg_to_print = "<b>Greetings from " + cabprefer+" !</b> Your cab is booked. You can track it from your app.","confirmed"
			$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>'+ String(msg_to_print).toString()+'</div>').appendTo($('.mCSB_container')).addClass('new');
			setDate();
			updateScrollbar();
            $('.message-input').focus();
			if(cabprefer == "Uber")
            {
                uber_promo();
            }
            else if(cabprefer == "Ola")
            {
                ola_promo();
            }
            whatelse();

		}
		conv_index ="" ; conv_start ="";
	}
	else if (conv_index == 'response_CBKC')
	{
		if (msg.includes("yes") | msg.includes("yeah") | msg.includes("sure") | msg.includes("Yes") | msg.includes("Yeah"))
		{
			console.log("STEP : 1")
			console.log(conv_start)
			if (conv_start =='GETWET'){
				conv_index = 'Pref_GETCABPREFERENCE';
				pop_msg = "Ok cool.. no problem. please let me know if you need something else";
				$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Great ! which cab service would you like to use? <p style="font-size:10px; font-weight:bold; color:#F0F0F0;">(Currently available: OLA & UBER)</p></div>').appendTo($('.mCSB_container')).addClass('new');
				suggesttoggle();
				createsuggestion("CABPREFER")
				setDate();
				updateScrollbar();
                $('.message-input').focus();
			}
			else if(conv_start =='GETRES'){
				window.open("http://www.zomato.com","_blank");
				if(culinary_pitched == 0)
                {
                    culinary_treats();
                }
                culinary_pitched = 0
                whatelse();
				setDate();
				updateScrollbar();
                $('.message-input').focus();
				conv_index ="" ; conv_start ="";
			}
			
		}
		else if (msg.includes("no") | msg.includes("not now") | msg.includes("nope") | msg.includes("nah") | msg.includes("No") | msg.includes("Nope") | msg.includes("Nah"))
		{
			pop_msg = "Ok cool.. no problem. please let me know if you need something else";
			$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + pop_msg+ '</div>').appendTo($('.mCSB_container')).addClass('new');
			setDate();
			updateScrollbar();
            $('.message-input').focus();
			conv_index = "";conv_start = "";
		}
        
	}
	else if (conv_start =="AMIELEGIBL_startone" && conv_index == "AMIELEGIBL_indexone" )
	{
		conv_start ="AMIELEGIBL_starttwo";
		conv_index = "AMIELEGIBL_indextwo";
		console.log(conv_start + " : " + conv_index)
        var strf = msg
        caniafford_product = strf.split(",")[0];
        caniafford_merchant = strf.split(",")[1];
        if(caniafford_product != null){caniafford_product = caniafford_product.toUpperCase()}
        else{caniafford_product = "NA"}
        
        if(caniafford_merchant != null){caniafford_merchant = caniafford_merchant.toUpperCase()}
        else{caniafford_merchant = "NA"}
        
        console.log("PRODUCT :"+caniafford_product)
        console.log("MERCHANT :"+caniafford_merchant)
        //alert("Product : "+caniafford_product+ " || Merchant : "+caniafford_merchant)
		funcamielgible();
	}
	else if (conv_start =="AMIELEGIBL_starttwo" && conv_index == "AMIELEGIBL_indextwo" )
	{
		conv_start ="AMIELEGIBL_startthree";
		conv_index = "AMIELEGIBL_indexthree";
		console.log(conv_start + " : " + conv_index);
        var strp = msg;
        console.log("==strp==", msg);
		       
		convo(msg);
        console.log("==AMIELEGIBL_starttwo==",msg);
	}
	else if (conv_start =="AMIELEGIBL_startthree" && conv_index=="AMIELEGIBL_indexthree")
	{
		resp=[];
		product_name ="home";
		product_Category ="home";
		loan_flag=0;
		loan_category=4;
		console.log(msg)
	
		if (msg>=100000)
		{
			loan_flag=1;
		}
		
		if (product_select == "4wheeler"){loan_category=2}
		else if (product_select == "2wheeler"){loan_category=3; loan_flag = 1}
		else if (product_select == "realestate"){loan_category=1}
		else if (product_select == "other" || product_select == "electronics"){loan_category=4}
        
		flag_invalid = false;
		if (isANumber(msg)){
			console.log("==No Conversion Needed==", msg);
			afford_criteria(msg, product_name, product_Category, loan_flag, loan_category);
		}else{
			var JsonURLs = "http://10.50.72.76:8087/api/v1/"+msg+"/amt_convert";
			$.getJSON(JsonURLs, function(data) {
				console.log(msg, "==get_converted_price==data== ",data);
				var check_price = data;
				if(data == 0){ 
					invalid_input_alert();
					flag_invalid = true;
					console.log("!!==flag_invalid==(value 0) !!", flag_invalid);
					return false;
				}
				afford_criteria(data, product_name, product_Category, loan_flag, loan_category);	
			})
			.fail(function() { 
				console.log("==No Response From Server==Failed !!");
				return false;
			})
		}
		if(flag_invalid){
			console.log("==flag_invalid [true] ==", flag_invalid);
			conv_start ="AMIELEGIBL_starttwo"; conv_index = "AMIELEGIBL_indextwo";
			convo(msg);
		}
	}
	else if (conv_index=="suggestion_ham") 
	{
		if (conv_start =='ACC_BALANCE'){ 
			pop_msg = "Get your current savings account balance with a quick question. Try typing \'bal\' OR use one of the suggestions below!"	
			conv_index = ""; conv_start = "";
			$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + pop_msg + '</div>').appendTo($('.mCSB_container')).addClass('new');
			setDate();
			updateScrollbar();
            $('.message-input').focus();
			suggesttoggle();
			createsuggestion("ACC_BALANCE_SUGGESTION");
		}
		else if (conv_start =='CR_CARD_OUT'){ 
			pop_msg = "Get the most recent outstanding amount on your credit card. Try typing \'cc outstanding\' OR use one of the suggestions below!"	
			conv_index = ""; conv_start = "";
			$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + pop_msg + '</div>').appendTo($('.mCSB_container')).addClass('new');
			setDate();
			updateScrollbar();
            $('.message-input').focus();
			suggesttoggle();
			createsuggestion("CR_CARD_OUT_SUGGESTION"); 
		}
		else if (conv_start =='APPLY_CHEQUE_BOOK'){ 
			pop_msg = "Apply for a new check book with ease. Try typing \'apply for check book\' OR use one of the suggestions below!"	
			conv_index = ""; conv_start = "";
			$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + pop_msg + '</div>').appendTo($('.mCSB_container')).addClass('new');
			setDate();
			updateScrollbar();
            $('.message-input').focus();
			suggesttoggle();
			createsuggestion("APPLY_CHEQUE_BOOK_SUGGESTION");
		}
		else if (conv_start =='APPLY_CHEQUE_BOOK_YN')
		{
			console.log("==got here==", conv_index, conv_start);
			setDate();
			conv_index = "suggestion_ham"; conv_start = "APPLY_CHEQUE_BOOK_CYN";
			updateScrollbar();
            $('.message-input').focus();
			suggesttoggle();
			createsuggestion("APPLY_CHEQUE_BOOK_SUGGESTION_YN");
		}
		else if (conv_start =='APPLY_CHEQUE_BOOK_CYN')
		{
			if (analyze_string.includes("yes") | analyze_string.includes("yeah") | analyze_string.includes("sure") | analyze_string.includes("Yes") | analyze_string.includes("Yeah"))
			{
				setDate();
				updateScrollbar();
                $('.message-input').focus();
				conv_index = "";conv_start = "";
				suggesttoggle();
                
			}
			else if (analyze_string.includes("no") | analyze_string.includes("not now") | analyze_string.includes("nope") | analyze_string.includes("nah") | analyze_string.includes("No") | analyze_string.includes("Nope") | analyze_string.includes("Nah"))
			{
				pop_msg = "Ok cool.. no problem. please let me know if you need something else";
				conv_index = ""; conv_start = "";
				$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' +pop_msg+ '</div>').appendTo($('.mCSB_container')).addClass('new');
				setDate();
				updateScrollbar();
                $('.message-input').focus();
                
			}
		}
		else if (conv_start =='EXP_ANALYSIS'){ 
			pop_msg = "View a visual breakup of your past expenses. Try typing \'show my expenses\' to get your expenses for the last 10 days OR specify a time frame like \'2 weeks expense\'. <br><br/>You can also use one of the suggestions below!"	
			conv_index = ""; conv_start = "";
			$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + pop_msg + '</div>').appendTo($('.mCSB_container')).addClass('new');
			setDate();
			updateScrollbar();
            $('.message-input').focus();
			suggesttoggle();
			createsuggestion("EXP_ANALYSIS_SUGGESTION");
		}
		else if (conv_start =='UPCOMING_EXP'){ 
			pop_msg = "View a visual breakup of any upcoming expenses. Try typing \'upcoming exp\' OR use one of the suggestions below!"	
			conv_index = ""; conv_start = "";
			$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + pop_msg + '</div>').appendTo($('.mCSB_container')).addClass('new');
			setDate();
			updateScrollbar();
            $('.message-input').focus();
			suggesttoggle();
			createsuggestion("UPCOMING_EXP_SUGGESTION");
		}
		else if (conv_start =='HAM_WEATHER'){ 
			pop_msg = "Quick weather update for a particular location.  Try typing \'weather in mumbai\' OR use one of the suggestions below!"	
			conv_index = ""; conv_start = "";
			$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + pop_msg + '</div>').appendTo($('.mCSB_container')).addClass('new');
			setDate();
			updateScrollbar();
            $('.message-input').focus();
			suggesttoggle();
			createsuggestion("HAM_WEATHER_SUGGESTION");
		}
		else if (conv_start =='HAM_RESTAURANT'){ 
			pop_msg = "Explore Restaurants for a particular location . Try typing \'hotels in bandra\' OR use one of the suggestions below!"	
			conv_index = ""; conv_start = "";
			$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + pop_msg + '</div>').appendTo($('.mCSB_container')).addClass('new');
			setDate();
			updateScrollbar();
            $('.message-input').focus();
			suggesttoggle();
			createsuggestion("HAM_RESTAURANT_SUGGESTION");
		}
		else if (conv_start =='HAM_CAB_BOOK'){ 
			pop_msg = "Get a ride share cab booked to your destination of choice. Try typing \'book a cab from thane to bandra\' OR use one of the suggestions below!"	
			conv_index = ""; conv_start = "";
			$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + pop_msg + '</div>').appendTo($('.mCSB_container')).addClass('new');
			setDate();
			updateScrollbar();
            $('.message-input').focus();
			suggesttoggle();
			createsuggestion("HAM_CAB_BOOK_SUGGESTION");
		}
	}
    
    else if (conv_start =="cab_loc_startone" && conv_index == "cab_loc_indexone" )
	{
		console.log("====LOCATIONS==[Stay Tune]===");
		if(overall_to_location == "default"){
			conv_start = "cab_loc_starttwo";  conv_index = "cab_loc_indextwo";
			enter_to_location();
			return false;
		}
        else{
			msg = "book me a cab from "+overall_from_location+" to "+overall_to_location;
			console.log("==t_msg==",msg);
			botResponse(msg);
		}
	}
}

function invalid_input_alert(){
	console.log("==NaN==");
	alert('Oops..Look like the price you entered is invalid! Please, ensure that the price only contains numbers (no special characters or letters). Thank You!')
    $('.message-input').attr("placeholder", "Please enter a number for the price");	
	document.getElementById('userInput').value = "";
	
	console.log("==New Input (probably valid) ==",msg);
	return false;
}

function afford_criteria(check_price, product_name, product_Category, loan_flag, loan_category){
	if(product_select == "int_vac")
		{            
				console.log(data, ' check2 ' +check_price);
				fetch(`${url}/${user_session_id}/${check_price}/${product_name}/${product_Category}/${loan_flag}/${loan_category}/caniafford`, {	method: 'GET'})
				.then(function (response) { return response.json(); })
				.then(function (responses) {
				if (responses) {
					console.log("Full msg: "+responses)
					resp=responses[0].split(':')
					resp1=responses[1].split(':')
					resp2=responses[2]
					console.log("===BEFORE==",productenq_rec, "---", typeof productenq_rec);
					$('<div id="div_productoverall"><div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + resp[1] +'</div>'
					 + '</div>').appendTo($('.mCSB_container')).addClass('new');
					// setDate();
					updateScrollbar();
					$('.message-input').focus();
					if(resp2 == '1')
					{ 
						setTimeout(pitch_travel,7000);
						setTimeout(pitch_forex,12000);
						setTimeout(whatelse,15000);
						
					}
					else if(resp2 == '0')
					{ 
					   
					   var d_list = caniaff_epoch();
                       cant_afford()
					   setTimeout(draw_chart_caniafford(d_list[1], d_list[0], "getTransactions"),6000)
					   setTimeout(pitch_iwish,12000);
					   setTimeout(whatelse,14000);
					}
				}
				toggleslide_cnt++;
				toggleslide_div = "productenq_excoll_"+toggleslide_cnt;
				productenq_rec = "productenq_rec_"+toggleslide_cnt;
				conv_start ="";
				conv_index ="";	
				})
				.catch(function (err) {});
					console.log("===");
			}
        
        else if(product_select == "dom_vac")
        {            
            //alert('VACAY TIME')
            fetch(`${url}/${user_session_id}/${check_price}/${product_name}/${product_Category}/${loan_flag}/${loan_category}/caniafford`, {	method: 'GET'})
            .then(function (response) { return response.json(); })
            .then(function (responses) {
              if (responses) {
                  
                 console.log("Full msg: "+responses)
                resp=responses[0].split(':')
                resp1=responses[1].split(':') 
                resp2=responses[2]
                console.log("===BEFORE==",productenq_rec, "---", typeof productenq_rec);
                $('<div id="div_productoverall"><div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + resp[1] +'</div>'
                 + '</div>').appendTo($('.mCSB_container')).addClass('new');
                // setDate();
                updateScrollbar();
                $('.message-input').focus();
                if(resp2 == '1')
                { 
                    setTimeout(pitch_travel,7000);
                    setTimeout(whatelse,12000);
                }
                else if(resp2 == '0')
                { 
                   
                   var d_list = caniaff_epoch();
                   cant_afford()
                   draw_chart_caniafford(d_list[1], d_list[0], "getTransactions")
                   setTimeout(pitch_iwish,12000);
                   setTimeout(whatelse,14000);
                }
                
            }
                    
            toggleslide_cnt++;
            toggleslide_div = "productenq_excoll_"+toggleslide_cnt;
            productenq_rec = "productenq_rec_"+toggleslide_cnt;
            conv_start ="";
            conv_index ="";	
            })
            .catch(function (err) {});
                console.log("===");
                console.log("...msg_log...");
        }
        
        else if(product_select == "realestate")
        {            
            //alert('VACAY TIME')
            fetch(`${url}/${user_session_id}/${check_price}/${product_name}/${product_Category}/${loan_flag}/${loan_category}/caniafford`, {	method: 'GET'})
            .then(function (response) { return response.json(); })
            .then(function (responses) {
              if (responses) {
                  
                 console.log("Full msg: "+responses)
                resp=responses[0].split(':')
                resp1=responses[1].split(':') 
                resp2=responses[2]
                console.log("===BEFORE==",productenq_rec, "---", typeof productenq_rec);
                $('<div id="div_productoverall"><div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + resp[1] +'</div>'
                 + '</div>').appendTo($('.mCSB_container')).addClass('new');
                // setDate();
                updateScrollbar();
                $('.message-input').focus();
                if(resp2 == '1')
                { 
                    setTimeout(HL_calc,7000);
                    setTimeout(pitch_home_insurance,12000);
                    setTimeout(whatelse,15000);
                }
                else if(resp2 == '0')
                { 
                   
                   var d_list = caniaff_epoch();
                   cant_afford()
                   draw_chart_caniafford(d_list[1], d_list[0], "getTransactions")
                   setTimeout(pitch_iwish,12000);
                   setTimeout(whatelse,14000);
                }
                
            }
                    
            toggleslide_cnt++;
            toggleslide_div = "productenq_excoll_"+toggleslide_cnt;
            productenq_rec = "productenq_rec_"+toggleslide_cnt;
            conv_start ="";
            conv_index ="";	
            })
            .catch(function (err) {});
                console.log("===");
        }
        else if(product_select == "4wheeler")
        {            
            //alert('VACAY TIME')
            fetch(`${url}/${user_session_id}/${check_price}/${product_name}/${product_Category}/${loan_flag}/${loan_category}/caniafford`, {	method: 'GET'})
            .then(function (response) { return response.json(); })
            .then(function (responses) {
              if (responses) {
                  
                 console.log("Full msg: "+responses)
                resp=responses[0].split(':')
                resp1=responses[1].split(':') 
                resp2=responses[2]
                console.log("===BEFORE==",productenq_rec, "---", typeof productenq_rec);
                $('<div id="div_productoverall"><div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + resp[1] +'</div>'
                 + '</div>').appendTo($('.mCSB_container')).addClass('new');
                // setDate();
                updateScrollbar();
                $('.message-input').focus();
                if(resp2 == '1')
                { 
                    setTimeout(AL_calc,7000);
                    setTimeout(pitch_car_insurance,12000);
                    setTimeout(whatelse,15000);
                }
                else if(resp2 == '0')
                { 
                   var d_list = caniaff_epoch();
                   cant_afford()
                   draw_chart_caniafford(d_list[1], d_list[0], "getTransactions")
                   setTimeout(pitch_iwish,12000);
                   setTimeout(whatelse,14000);
                }
                
            }
                    
            toggleslide_cnt++;
            toggleslide_div = "productenq_excoll_"+toggleslide_cnt;
            productenq_rec = "productenq_rec_"+toggleslide_cnt;
            conv_start ="";
            conv_index ="";	
            })
            .catch(function (err) {});
                console.log("===");
        }
        
        else if(product_select == "2wheeler")
        {            
            //alert('VACAY TIME')
            fetch(`${url}/${user_session_id}/${check_price}/${product_name}/${product_Category}/${loan_flag}/${loan_category}/caniafford`, {	method: 'GET'})
            .then(function (response) { return response.json(); })
            .then(function (responses) {
              if (responses) 
              {                  
                console.log("Full msg: "+responses)
                resp=responses[0].split(':')
                resp1=responses[1].split(':') 
                resp2=responses[2]
                console.log("===BEFORE==",productenq_rec, "---", typeof productenq_rec);
                $('<div id="div_productoverall"><div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + resp[1] +'</div>'
                 + '</div>').appendTo($('.mCSB_container')).addClass('new');
                // setDate();
                updateScrollbar();
                $('.message-input').focus();
                if(resp2 == '1')
                { 
                    setTimeout(TWL_calc,7000);
                    setTimeout(pitch_bike_insurance,12000);
                    setTimeout(whatelse,15000);
                }
                else if(resp2 == '0')
                { 
                   var d_list = caniaff_epoch();
                   cant_afford()
                   draw_chart_caniafford(d_list[1], d_list[0], "getTransactions")
                   setTimeout(pitch_iwish,12000);
                   setTimeout(whatelse,14000);
                }
                
              }
                    
            toggleslide_cnt++;
            toggleslide_div = "productenq_excoll_"+toggleslide_cnt;
            productenq_rec = "productenq_rec_"+toggleslide_cnt;
            conv_start ="";
            conv_index ="";	
            })
            .catch(function (err) {});
                console.log("===");
        }
        else{
            fetch(`${url}/${user_session_id}/${check_price}/${product_name}/${product_Category}/${loan_flag}/${loan_category}/caniafford`, {	method: 'GET'})
            .then(function (response) { return response.json(); })
            .then(function (responses) {
              if (responses) {
                  
                 console.log("Full msg: "+responses)
                resp=responses[0].split(':')
                resp1=responses[1].split(':') 
                resp2=responses[2]
                console.log("===BEFORE==",productenq_rec, "---", typeof productenq_rec);
                $('<div id="div_productoverall"><div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + resp[1] +'</div>'
                 + '</div>').appendTo($('.mCSB_container')).addClass('new');
                // setDate();
                updateScrollbar();
                $('.message-input').focus();
                if(resp2 == '1')
                {                    
                    if(caniafford_merchant.toUpperCase() == "AMAZON")
                     {
                         amazon_promo();
                     }
                    whatelse();
                }
                else if(resp2 == '0')
                { 
                   var d_list = caniaff_epoch();
                   cant_afford()
                   draw_chart_caniafford(d_list[1], d_list[0], "getTransactions")
                   setTimeout(pitch_iwish,12000);
                   setTimeout(whatelse,14000);
                }                 
                
            }
                
            toggleslide_cnt++;
            toggleslide_div = "productenq_excoll_"+toggleslide_cnt;
            productenq_rec = "productenq_rec_"+toggleslide_cnt;
            conv_start ="";
            conv_index ="";	
            })
            .catch(function (err) {});
                console.log("===");
        }
}


function slidetoggle(productenq_rec)
{
	var x = productenq_rec.id
	console.log(typeof productenq_rec)
	document.getElementByID(x).style.display="block"	
}

var toggleslide_cnt=0;
var toggleslide_div = "productenq_excoll_0";
var productenq_rec = "productenq_rec_0";
var ddl_cnt=0;
var ddl_name="ddl_0";

//--------------------------- CAN I AFFORD FUNCTION - START -------------------------------------------
function caniafford()
{
	document.getElementById("btn_hamopclo").click();
	$('<div class="message"><figure class="avatar"><img src="./image/single-logo.png" /></figure><div>Alright! Lets get started... \nFirst select the category of the product you are looking to buy</div>'
	
	+'<div class="selectdiv">'
	+'<label>'
	+'<select class="selectpicke" id ="'+ddl_name+'" name="ddl" onmousedown="this.value=\'\';" onchange="askproductname(this.value);">'
	+'<option value="" disabled selected hidden>Choose Category...</option>'
    +'<option value="4wheeler"><i class="fas fa-motorcyce"></i>Four Wheeler</option>'
    +'<option value="2wheeler">Two Wheeler</option>'
    +'<option value="realestate">Real Estate</option>'
	+'<option value="electronics">Electronics & Appliances</option>'
    +'<option value="mobiles">Mobiles & Accessories</option>'
    +'<option value="computers">Computers & Accessories</option>'
    +'<option value="furniture">Furniture</option>'
    +'<option value="bags">Fashion Accesories</option>'
    +'<option value="music">Musical Instruments</option>'
	+'<option value="event">Occasion / Event</option>'
    +'<option value="dom_vac">Domestic Travel/ Holiday</option>'
    +'<option value="int_vac">International Travel/Holiday</option>'
    +'<option value="others">Others</option>'
    +'</select>'
	+'</label>'
	+'</div>'
	+'</div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar();
	$('.message-input').focus();
	ddl_cnt++;
	ddl_name = "ddl_"+ddl_cnt;
}

function getval(){
	var rates = document.getElementById('sortType').value;
	if (document.getElementById('sort-best').checked) {
		rate_value = document.getElementById('sort-best').value;
		console.log("==========", rate_value);
	}
}

$('#sortType').on('change', function() {
	console.log("==================");
});

var product_select="";
function askproductname(value)
{	 
alert(value);
	product_select = value;
	if(product_select=='4wheeler')
    {
        $('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Perfect!! Which model is it?</div>').appendTo($('.mCSB_container')).addClass('new');
        updateScrollbar();
        $('.message-input').focus();
        //$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>And any particular Dealership/Manufacturer in mind? <br/>You can type it in after the model name separated by a comma OR just type NA if you haven\'t decided yet.<br/><br/>e.g. Jeep Compass, Landmark Jeep-Worli OR Jeep Compass, NA</div>').appendTo($('.mCSB_container')).addClass('new');
	}
    
    else if(product_select=='2wheeler')
    {
        $('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Smart move to buy a 2-wheeler, considering the current fuel prices! Which model is it? </div>').appendTo($('.mCSB_container')).addClass('new');
        updateScrollbar();
        $('.message-input').focus();
        //$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>And any particular Dealership/Manufacturer in mind? <br/>You can type it in after the model name separated by a comma OR just type NA if you haven\'t decided yet.<br/><br/>e.g. Activa, Honda OR Activa,NA </div>').appendTo($('.mCSB_container')).addClass('new');
    }
    
    else if(product_select=='realestate')
    {
        $('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Nice! I have a favourite saying : “Don’t wait to buy real estate. Buy real estate and wait.” -Will Rogers<br/>What\'re you looking at? Apartments or Bungalows?</div>').appendTo($('.mCSB_container')).addClass('new');
        updateScrollbar();
        $('.message-input').focus();
        //$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>And more importantly which builder? I\'m thinking of buying a place as well but can\'t decide on a builder! <br/>You can type it in after the house type separated by a comma OR just type NA if you haven\'t decided yet.<br/><br/>e.g. Apartment, Hiranandani OR Apartment, NA</div>').appendTo($('.mCSB_container')).addClass('new');
    }
    
    else if(product_select=='electronics')
    {
        $('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Ahhh! What\'re you looking at? Appliances or a swanky new TV?<br/>I am actually looking to pick up a new 50 inch TV myself! But can\'t decide on where to get it from!</div>').appendTo($('.mCSB_container')).addClass('new');
        updateScrollbar();
        $('.message-input').focus();
        //$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>What is your preferred place to buy from? <br/>You can type it in after the product name separated by a comma OR just type NA if you haven\'t decided yet.<br/><br/>e.g. Samsung Washing Machine, Croma OR Samsung Washing Machine,NA</div>').appendTo($('.mCSB_container')).addClass('new');
    }
    
    else if(product_select=='mobiles')
    {
        $('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Cool! Which one are you looking at?</div>').appendTo($('.mCSB_container')).addClass('new');
        updateScrollbar();
        $('.message-input').focus();
        //$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>More importantly where are you planning to buy it from? <br/>You can type it in after the product name separated by a comma OR just type NA if you haven\'t decided yet.<br/><br/>e.g. Samsung S9, Flipkart OR Samsung S9,NA</div>').appendTo($('.mCSB_container')).addClass('new');
    }
    
    else if(product_select=='computers')
    {
        $('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Oooh! New Computer! Which one are you planning to buy?</div>').appendTo($('.mCSB_container')).addClass('new');
        updateScrollbar();
        $('.message-input').focus();
        //$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>More importantly where are you planning to buy it from? <br/>You can type it in after the product name separated by a comma OR just type NA if you haven\'t decided yet.<br/><br/>e.g. Lenovo Ideapad, Amazon OR Lenovo Ideapad,NA</div>').appendTo($('.mCSB_container')).addClass('new');
    }
    
    else if(product_select=='furniture')
    {
        $('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Thats nice! What exactly are you planning to get? Perhaps a nice comfy couch or a stylish center table?</div>').appendTo($('.mCSB_container')).addClass('new');
        updateScrollbar();
        $('.message-input').focus();
        //$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>More importantly where are you planning to buy it from? <br/>You can type it in after the product name separated by a comma OR just type NA if you haven\'t decided yet.<br/><br/>e.g. Dining Table, Furlenco OR  Dining Table,NA</div>').appendTo($('.mCSB_container')).addClass('new');
    }
    
    else if(product_select=='bags')
    {
        $('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Woah! Shopping for Fashion products! My kind of person! What are you looking to buy? a bag or a watch?</div>').appendTo($('.mCSB_container')).addClass('new');
        updateScrollbar();
        $('.message-input').focus();
        //$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Which brand/merchant do you like to shop at? <br/>You can type it in after the product name separated by a comma OR just type NA if you haven\'t decided yet.<br/><br/>e.g. Watch, Casio OR Watch,NA</div>').appendTo($('.mCSB_container')).addClass('new');
    }
    
    else if(product_select=='music')
    {
        $('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Awesome! I\'ve been wanting to get a guitar for a while now! What instrument are you thinking of buying?</div>').appendTo($('.mCSB_container')).addClass('new');
        updateScrollbar();
        $('.message-input').focus();
        //$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>And where do you plan to buy it from? <br/>You can type it in after the instrument name separated by a comma OR just type NA if you haven\'t decided yet.<br/><br/>e.g. Guitar, Flipkart OR Guitar,NA</div>').appendTo($('.mCSB_container')).addClass('new');
    }
    
    else if(product_select=='event')
    {
        $('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>I see! What type of occasion is it? I\'m just really curious!</div>').appendTo($('.mCSB_container')).addClass('new');
        updateScrollbar();
        $('.message-input').focus();
    }
    
    else if(product_select=='dom_vac')
    {
        $('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Lucky You!<br/>So where are you planning your trip to?</div>').appendTo($('.mCSB_container')).addClass('new');
        updateScrollbar();
        $('.message-input').focus();
        //$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>So where are you planning your trip to?<br/>And how do you plan on getting there? Flight, Train or Car? <br/><br/>You can type it in after the destination separated by a comma OR just type NA if you haven\'t decided yet.<br/><br/>e.g. Goa, Flight OR  Goa,NA</div>').appendTo($('.mCSB_container')).addClass('new');
    }
    
    else if(product_select=='int_vac')
    {
        $('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Thats Great! Travelling the world is the best feeling! You have new experiences that stay with you for a lifetime!<br/>Where are you planning your trip to?</div>').appendTo($('.mCSB_container')).addClass('new');
        updateScrollbar();
        $('.message-input').focus();
        //$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Where are you planning your trip to?<br/>And what\'s your preferred airline? <br/><br/>You can type it in after the destination separated by a comma OR just type NA if you haven\'t decided yet.<br/><br/>e.g. Dubai, Emirates OR Dubai,NA</div>').appendTo($('.mCSB_container')).addClass('new');
    }
    
    else
    {
        $('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Perfect! And what is the name of the product?</div>').appendTo($('.mCSB_container')).addClass('new');
    }
    
    setDate();
	updateScrollbar();
    $('.message-input').focus();
	conv_start ="AMIELEGIBL_startone";
	conv_index = "AMIELEGIBL_indexone";
}

function funcamielgible()
{	 
	//product_select = value;
	$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Cool! And whats the estimated cost?</div>').appendTo($('.mCSB_container')).addClass('new');
	setDate();
	updateScrollbar();
    $('.message-input').focus();
	conv_start ="AMIELEGIBL_starttwo";
	conv_index = "AMIELEGIBL_indextwo";
}

function pitch_travel()
{     
	$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>Also if you haven\'t thought about it yet, ICICI offers Travel Insurance! So you can enjoy your travels and be worry-free!<a href="https://www.icicilombard.com/travel-insurance/get-quote/basic-details?opt=single-tripsource=nav&gclid=Cj0KCQjwguDeBRDCARIsAGxuU8YnLaHgSRk3nwVktycqNBEZbsXjJfzV4K5ZQbDNcVX6OWQEXRUwohoaAnlQEALw_wcB" style="color:#FFFF00 "target="_blank" ><br><br/>You can Click Here to apply for Travel Insurance for your trip</a></div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar();
    $('.message-input').focus();
}

function pitch_forex()
{     
	$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>Additionally, if you need one you can opt for a Forex Card to make spending on your trip easier!<a href="https://www.icicibank.com/Personal-Banking/cards/Consumer-Cards/travel-card/travel-cards.page" style="color:#FFFF00 "target="_blank" ><br><br/>You can Click Here to apply for a Forex Card</a></div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar();
    $('.message-input').focus();
}

function uber_promo()
{
    $('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>You can now pay for your UBER trips via the UPI payments option in your IMobile App</div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar();
    $('.message-input').focus();
}

function ola_promo()
{
    $('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>You can now pay for your OlaCab trips via the UPI payments option in your IMobile App</div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar();
$('.message-input').focus();    
}

function amazon_promo()
{
    $('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>ICICI currently has the following offer for Amazon Purchases<a href="https://www.icicibank.com/offers/amex-amazon-offer.page?" style="color:#FFFF00 "target="_blank" ><br/>Click Here</a></div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar();
$('.message-input').focus();    
}

function pitch_home_insurance()
{     
	$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>Also if you haven\'t thought about it yet, ICICI offers Home Insurance! Secure your home against unforeseen calamities!<a href="https://www.icicilombard.com/home-insurance/get-quote/basic-details?dealno=DL-4013/2108483" style="color:#FFFF00 "target="_blank" ><br/>You can Click Here to get a Quote!!</a></div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar();
    $('.message-input').focus();
}

function pitch_car_insurance()
{     
	$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>Also if you haven\'t thought about it yet, ICICI offers Auto Insurance! Now you can avail of Own Damage, Personal Accident and Liability cover all in one policy!<a href="https://www.icicilombard.com/motor-insurance/car-insurance/get-quote/basic-details" style="color:#FFFF00 "target="_blank" ><br/>You can Click Here to get a Quote!!</a></div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar();
$('.message-input').focus();    
}

function pitch_bike_insurance()
{     
	$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>Also if you haven\'t thought about it yet, ICICI offers Two-Wheeler Insurance! Now you can avail of Own Damage, Personal Accident and Liability cover all in one policy!<a href="https://www.icicilombard.com/motor-insurance/two-wheeler-insurance" style="color:#FFFF00 "target="_blank" ><br/>You can Click Here to get a Quote!!</a></div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar();
$('.message-input').focus();    
}

function pitch_iwish()
{     
	$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>If you want, you can also setup an I-Wish account to plan for this purchase!<a href="https://www.icicibank.com/calculator/iwish-calculator.page" style="color:#FFFF00 "target="_blank" ><br/>You can Click Here to Open Up the IWish Calculator!!</a></div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar();
    $('.message-input').focus();
}

function culinary_treats()
{     
	$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>Also, just a heads up! You can get a minimum of 15% discount off your food bill by using your ICICI Debit or Credit card<a href="https://www.icicibank.com/offers/categories/culinary-treats.page" style="color:#FFFF00 "target="_blank" ><br/>Click here to know more</a></div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar();
$('.message-input').focus();    
}

function culinary_treats_1()
{     
	$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>Nice! Before you head out, just a quick FYI! You can get a minimum of 15% discount off your food bill by using your ICICI Debit or Credit card<a href="https://www.icicibank.com/offers/categories/culinary-treats.page" style="color:#FFFF00 "target="_blank" ><br/>Click here to know more</a></div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar();
    $('.message-input').focus();
}

function apply_PL()
{     
	$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><a href="https://www.icicibank.com/Personal-Banking/loans/personal-loan/index.page?#" style="color:#FFFF00 "target="_blank" >Click here to apply</a></div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar();
    $('.message-input').focus();
}

function apply_AL()
{     
	$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><a href="https://www.icicibank.com/Personal-Banking/loans/car-loan/index.page?" style="color:#FFFF00 "target="_blank" >Click here to apply</a></div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar(); 
    $('.message-input').focus();
}

function apply_TWL()
{     
	$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><a href="https://www.icicibank.com/Personal-Banking/loans/two-wheeler-loan/index.page?#toptitle" style="color:#FFFF00 "target="_blank" >Click here to apply</a></div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar(); 
    $('.message-input').focus();
}

function apply_HL()
{     
	$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><a href="https://www.icicibank.com/Personal-Banking/loans/home-loan/index.page?" style="color:#FFFF00 "target="_blank" >Click here to apply</a></div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar(); 
    $('.message-input').focus();
}

function HL_calc()
{     
	$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>Home Loan EMI Calculator:<a href="https://www.icicibank.com/calculator/home-loan-emi-calculator.page" style="color:#FFFF00 "target="_blank" > Click Here</a></div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar();
    $('.message-input').focus();
}

function AL_calc()
{     
	$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>Car Loan EMI Calculator:<a href="https://www.icicibank.com/calculator/car-loan-emi-calculator.page#toptitle" style="color:#FFFF00 "target="_blank" > Click Here</a></div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar();
    $('.message-input').focus();
}

function TWL_calc()
{     
	$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>2 Wheeler Loan EMI Calculator:<a href="https://www.icicibank.com/calculator/two-wheeler-loan-emi-calculator.page?#toptitle" style="color:#FFFF00 "target="_blank" > Click Here</a></div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar();
    $('.message-input').focus();
}

function PL_calc()
{     
	$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>Personal Loan EMI Calculator:<a href="https://www.icicibank.com/calculator/personal-loan-emi-calculator.page" style="color:#FFFF00 "target="_blank" > Click Here</a></div>').appendTo($('.mCSB_container')).addClass('new');
	updateScrollbar();
    $('.message-input').focus();
}


function caniaff_epoch()
{
    var ts1 = Math.round((new Date()).getTime() / 1000);
    var ts2  = ts1 - 2592000;
    return [ts1,ts2];
    
    
}
//----------------------------- CAN I AFFORD FUNCTION - END --------------------------------------------------------------


//---------------------------------- WHAT ELSE FUNCTION - START ------------------------------------
function whatelse()
{
  setTimeout(function() {
	var string_1 = "";
	if (intent == "GETEODBAL")
	{
		// string_1 = 'You can know more by<a style="text-decoration: none;" target="_blank" href="https://www.icicibank.com/Personal-Banking/account-deposit/fixed-deposit/index.page" onclick="whatelse()"> clicking here. </a><br/>'
	}
	else if (intent == "GETCAB")
	{
		string_1 = "ICICI now offers 5% cashback on cab travel.<br/>Also you can pay the cab directly from iMobile App. <br/><br/>Happy Jouney !<div>"
	}
	else if (intent == "GETRES")
	{
		string_1 = "Bon Apetit ! <br/>";
	}
	//$('<div class="message" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id ='+div_name+'></div>'+string_1+'</div>').appendTo($('.mCSB_container')).addClass('new');	
	//klo++;
	//div_name = "chsrtdiv_"+klo;	
	$('<div class="message" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id ='+div_name+'></div><div>What else can I assist you with?</div></div>').appendTo($('.mCSB_container')).addClass('new');	
	updateScrollbar();
    $('.message-input').focus();
	klo++;
	div_name = "chsrtdiv_"+klo;	
	var msg_to_chat = "<MSG>WHAT ELSE"
	chathistory(user_session_id,msg_to_chat,"BOT",format_time(),"<FROMINTENT>"+intent);	//--write to history--
	i++; }, 1000 + (Math.random() * 20) * 100);
}
//------------------------- WHAT ELSE FUNCTION - END ----------------------------------------------





// CAB BOOKING NEW STARTS
prefetch_f_location="";
prefetch_t_location="";
div_f_lc = 'div_flocation_0';
div_t_lc = 'div_tlocation_0'; 

// LOCATION FINDER
function enable_location_finder(){
	div_map = 'div_map_'+div_map_var;
    div_f_lc = 'div_flocation_'+div_map_var;
    div_t_lc = 'div_tlocation_'+div_map_var; 
	console.log("map_first:"+div_map)
	$('<div class="message_cabbooking new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id ='+div_name+'></div>'
	+' <div class = "location_overall"><div class = "div_from_location"> '
	+' <textarea id = "'+div_f_lc+'" type="text" class="txt_from_location txt_location" placeholder="Enter pickup location";"></textarea> '// CHANGELOG :: removed onkeypress="initMap()
	+' <div class="div_from_dot"></div></div><div class="div_vert_line"></div><div class="div_to_location"> '
	+' <textarea id = "'+div_t_lc +'" type="text" class="txt_to_location txt_location" placeholder="Enter drop location"></textarea> '
	+' <div class="div_to_dot"></div>	</div><div>	<button type="submit" class="submit-btn" onclick="cab_confirmation()">Book my cab '
	+' <i class="fa fa-cab cab_icon"></i></button></div><div id="'+ div_map +'" class="map"></div> </div> '
	+'</div>').appendTo($('.mCSB_container')).addClass('new');
	if (prefetch_f_location != 'default')
	{
		document.getElementById(div_f_lc).value = prefetch_f_location;
	}
	if (prefetch_t_location != 'default')
	{
		document.getElementById(div_t_lc).value = prefetch_t_location;//overall_to_location    //{POST FALLBACK CHANGE}
	}
	if(prefetch_f_location != 'default')
	{
		initMap();
	}    
}

function cab_confirmation(){
	var originInput = document.getElementById(div_f_lc);
	var destinationInput = document.getElementById(div_t_lc);
	conv_index = 'response_CBKC'
	conv_start ='GETWET'
	msg = "yes book a cab"
	convo(msg)
		klo++;
		div_f_lc = "div_flocation_"+klo;	
		div_t_lc = "div_tlocation_"+klo;
		div_map = "div_map_"+klo;
}

function initMap() {
		  
		  if (latitude == "")
          {latitude='28.64386'}		  
		  if (longitude =="")
		  {longitude='77.12373'}
	  	console.log("map_passed_2:"+div_map)
        var map = new google.maps.Map(document.getElementById(div_map), {
          mapTypeControl: false,
          gestureHandling: 'cooperative',
          //scaleControl: true,
          center: {lat: parseFloat(latitude), lng: parseFloat(longitude)},
          zoom: 5
        });
		new AutocompleteDirectionsHandler(map);
		updateScrollbar();
        //$('.message-input').focus();
      }

       /**
        * @constructor
       */
      function AutocompleteDirectionsHandler(map) {
        this.map = map;
        this.originPlaceId = null;
        this.destinationPlaceId = null;
        this.travelMode = 'DRIVING';
		var originInput = document.getElementById(div_f_lc);
		var destinationInput = document.getElementById(div_t_lc);
		
		
		if(originInput == "")
		{
			originInput = "Hyderabad";
		}
		if(destinationInput =="")
		{
			 destinationInput = "Hyderabad"
		}
				
        this.directionsService = new google.maps.DirectionsService;
        this.directionsDisplay = new google.maps.DirectionsRenderer;
        this.directionsDisplay.setMap(map);

        var originAutocomplete = new google.maps.places.Autocomplete(
            originInput, {placeIdOnly: true});
        var destinationAutocomplete = new google.maps.places.Autocomplete(
            destinationInput, {placeIdOnly: true});
        this.setupPlaceChangedListener(originAutocomplete, 'ORIG');
        this.setupPlaceChangedListener(destinationAutocomplete, 'DEST');
		updateScrollbar();
        //$('.message-input').focus();

      }

      AutocompleteDirectionsHandler.prototype.setupClickListener = function(id, mode) {
        var radioButton = document.getElementById(id);
        var me = this;
        radioButton.addEventListener('click', function() {
          me.travelMode = mode;
          me.route();
        });
      };

      AutocompleteDirectionsHandler.prototype.setupPlaceChangedListener = function(autocomplete, mode) {
        var me = this;
        autocomplete.bindTo('bounds', this.map);
        autocomplete.addListener('place_changed', function() {
          var place = autocomplete.getPlace();
		  if (!place.place_id) {
            alert("Please select an option from the dropdown list.");
            return;
          }
          if (mode === 'ORIG') {
            me.originPlaceId = place.place_id;
          } else {
            me.destinationPlaceId = place.place_id;
          }
          me.route();
        });

      };

      AutocompleteDirectionsHandler.prototype.route = function() {
        if (!this.originPlaceId || !this.destinationPlaceId) {
          return;
        }
        var me = this;

        this.directionsService.route({
          origin: {'placeId': this.originPlaceId},
          destination: {'placeId': this.destinationPlaceId},
          travelMode: this.travelMode
        }, function(response, status) {
          if (status === 'OK') {
            me.directionsDisplay.setDirections(response);
          } else {
            window.alert('Directions request failed due to ' + status);
          }
        });
      };
// CAB BOOKING NEW ENDS



// CAB BOOKING CONFIRMATION
// function cab_confirmation()
// {
	
	// var _from_ = document.getElementById(div_f_lc).value;
	// var _to_ = document.getElementById(div_t_lc).value;
	
	// console.log("SOURCE CAB:",_from_)
	// console.log("DESTINATION CAB:", _to_)
	
	// conv_index = 'analyze_CYN';
	// conv_start = 'GETRESCAB';
	// overall_to_location = _to_;
	// overall_from_location = _from_;
	// msg = "yes i am";
	// console.log("STEP : 1 - intent identification");
	// convo(msg);
	
	// // klo++;
	// // div_name = "chsrtdiv_"+klo;	
	// // div_f_lc = "div_flocation_"+klo;
	// // div_t_lc = "div_tlocation_"+klo;
// }









//----------------------------------- MAIN INTERACTION WITH THE NLG ENGINE - START ----------------------------------------------
function get_bot_response(msg){	
	console.log("-----query------", msg);
	data = {  query: msg  }
    fetch(`${url}/${id}/respond`, {
		method: 'POST', 
		body: JSON.stringify(data)})
		
    .then(function (response) {
        return response.json(); })
		
    .then(function (responses) {
        if (responses) {
		out=[];
		respo=[];
		var result = Object.keys(responses).map(function(key) { return [responses[key].text];});
		console.log("RESULT"+result);
		temp=String(result[0]).toString().split('>');
		
		for(i=0; i<temp.length;i=i+2){ out.push(temp.slice(i,i+2).join('>'))}
		var cus_response_1 = out[0].toString();
		respo = cus_response_1.split('~')
		intent = respo[0].replace(/[^\w\s]/gi,'')
		console.log("RESPO_1: " +respo[1])
		console.log("RESPO_2: " +respo[2])
		
		// ---- USE CASE : 01 -- GET CAB ----------------
		if (intent == 'GETCAB')
			{
				console.log("===-==div_map_var====", div_map_var);
				div_map_var++;
				console.log("!!===-==div_map_var====!!", div_map_var);
				//MODIFY HERE
				prefetch_f_location = respo[1];
				prefetch_t_location = respo[2];
				enable_location_finder();
				initMap();
			}

			else if (intent == 'BNKSTM')
			{	
				var bankstmntdate = respo[1].toString().replace(/[^\w\s]/gi,'')
				console.log(bankstmntdate)
				var epodate  = bankstmntdate.toString().split(' ')
				draw_chart (epodate[0], epodate[1], "getTransactions")
				
				
				var msg_to_chat = "<FROM>"+String(conversion_back(epodate[0])).toString()+"<TO>"+String(conversion_back(epodate[1])).toString()+"<MSG>BANK STATEMENT"
				chathistory(user_session_id,msg_to_chat,"BOT",format_time(),"BNKSTM");
				
			}
			else if (intent == 'GETRES')
			{
				console.log(responses);
				console.log("RESP_0: "+ respo[0] +" RESP_1: "+ respo[1] + " RESP_2: "+ respo[2])
				var obj = JSON.parse(respo[2].replace(/'/g, "").replace(/\\/g, ""));
				console.log(typeof obj);
				rest_list = [];
				var res_data_div_0 = '<div class="rest_container"><div class="row"><div class="col-md-6 col-sm-8 col-xs-12 col-md-offset-3 col-sm-offset-2"><div class="rest_card"><div class="image"><img src="image/eats_3.jpg" width="100%"></div><div class="text">';
				var res_data_div ="";
				var j=0;
				for (var i in obj)
				{	
					res_data_div = res_data_div  + getrestaurantcard(j, obj[i]['name'], obj[i]['rating'], obj[i]['addr']);
					j++;
					rest_list.push([obj[i]['name'], obj[i]['rating'], obj[i]['addr']]);
				}
				res_data_div_final = res_data_div_0+ res_data_div + '</div></div></div></div></div>'
				$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Here is what I could find! Click on any of the restaurants to proceed!</div>').appendTo($('.mCSB_container')).addClass('new');
                $('<div class="messageresta" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id =rest_div_'+div_name+'>'+res_data_div_final+'</div></div>').appendTo($('.mCSB_container')).addClass('new');
				
				klo++;
				div_name = "chsrtdiv_"+klo;
				setDate();
				updateScrollbar();
                $('.message-input').focus();
				//var msg_to_chat = "<LOCATION>"+respo[1].toUpperCase().toString()+"<DESTINATION>"+respo[2].toUpperCase().toString()+"<MSG>RESTAURANT SEARCH"
				//chathistory(user_session_id,msg_to_chat,"BOT",format_time(),"GETRES");
				//whatelse();
			}
			else if (intent == 'GETWET')
			{	
				console.log("response from res: "+respo[2])

				$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id ='+div_name+'></div>'+respo[2]+'</div>').appendTo($('.mCSB_container')).addClass('new');
				klo++;
				div_name = "chsrtdiv_"+klo;	

				getweathercard(respo[1]);
				conv_start="GETWET"; conv_index="first"; overall_to_location = String(respo[1]).toString()
				convo(msg);
				
				console.log(String(result))
				var arr = String(result).split('~');
				var location = arr.indexOf('GETWET')+1;
				var location_to_be_stored = null;
				
				if (((arr.indexOf('GETWET')+1)< (arr.length)) && ((arr.indexOf('GETWET')+1) !=1))
				{
					location_to_be_stored = arr[(arr.indexOf('GETWET')+1)+1]
				}
				console.log("G=====================================" + location_to_be_stored);
				var msg_to_chat = "<LOCATION>"+location_to_be_stored+"<MSG>WEATHER SEARCH"
				chathistory(user_session_id,msg_to_chat,"BOT",format_time(),"GETWET");
				setDate();
				updateScrollbar();
                $('.message-input').focus();
			}
			else if (intent=='GETEODBAL')
			{
				$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id ='+div_name+'></div>'+(respo[1]).toString()+'</div>').appendTo($('.mCSB_container')).addClass('new');
				klo++;
				div_name = "chsrtdiv_"+klo;	
				var msg_to_chat = "<MSG>CURRENT BALANCE CHECKING"
				chathistory(user_session_id,msg_to_chat,"BOT",format_time(),"GETEODBAL");
				setDate();
				updateScrollbar();
                $('.message-input').focus();
				whatelse();
			}
			else if (intent=='GETCCOUT')
			{
				console.log((respo[1]).toString())
				var strf = (respo[1]).toString()
                if(strf.includes("not seeing a credit card")){
                    $('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id ='+div_name+'></div>'+strf+'<a href="https://www.icicibank.com/Personal-Banking/credit-card/apply-online.page?#toptitle" style="color:#FFFF00 "target="_blank" onclick="whatelse()" ><br><br/>You can Click Here to apply</a></div>').appendTo($('.mCSB_container')).addClass('new');
                }
                else if (strf.includes("you've paid of your latest statement.")){
                    $('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id ='+div_name+'></div>'+strf+'</div>').appendTo($('.mCSB_container')).addClass('new');
                }
                else{
                    $('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id ='+div_name+'></div>'+strf+'<a href="https://www.icicibank.com/online-services/clicktopay/index.page" style="color:#FFFF00 "target="_blank" onclick="whatelse()" ><br><br/>You can Click Here to pay it online</a></div>').appendTo($('.mCSB_container')).addClass('new');
                }
                //$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id ='+div_name+'></div>'+(respo[1]).toString()+'<a href="https://www.icicibank.com/online-services/clicktopay/index.page" style="color:#FFFF00 "target="_blank" onclick="whatelse()" ><br><br/>You can Click Here to pay it online</a></div>').appendTo($('.mCSB_container')).addClass('new');
                //$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id ='+div_name+'></div>'+strf+'<a href="https://www.icicibank.com/online-services/clicktopay/index.page" style="color:#FFFF00 "target="_blank" onclick="whatelse()" ><br><br/>You can Click Here to pay it online</a></div>').appendTo($('.mCSB_container')).addClass('new');
				//$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id ='+div_name+'></div>'+(respo[1]).toString()+'<a href="https://www.icicibank.com/online-services/clicktopay/index.page" style="color:#FFFF00 "target="_blank" onclick="whatelse()" ><br><br/>You can Click Here to go to the Card Bill Paysite</a></div>').appendTo($('.mCSB_container')).addClass('new');

				klo++;
				div_name = "chsrtdiv_"+klo;	
				var msg_to_chat = "<MSG>CREDIT CARD OUTSTANDING BALANCE"
				chathistory(user_session_id,msg_to_chat,"BOT",format_time(),"GETCCOUT");
				setDate();
				updateScrollbar();
                $('.message-input').focus();
				//whatelse();
			}
			else if (intent =='UPCMNG')
			{
				draw_chart('123','123',"getUpcomingTransactions")
				var msg_to_chat = "<MSG>UPCOMING EXPENSE"
				chathistory(user_session_id,msg_to_chat,"BOT",format_time(),"UPCMNG");
                updateScrollbar();
                $('.message-input').focus();
				//whatelse();
			}
			else if (intent =='GETCHKBK')
			{	
				console.log("*****GETCHKBK*****", intent)
				console.log((respo[1]).toString())
				$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id ='+div_name+'></div>'+(respo[1]).toString()+'</div>').appendTo($('.mCSB_container')).addClass('new');
				klo++;
				div_name = "chsrtdiv_"+klo;	
				var msg_to_chat = "<MSG>"+respo[1].toString()
				chathistory(user_session_id,msg_to_chat,"BOT",format_time(),"GETCHKBK");
                updateScrollbar();
                $('.message-input').focus();
                
                
				if (respo[1].toString().slice(0,2) == "SR"){
					conv_index = ''; conv_start = '';
                    whatelse();
				}
				else
				{
					conv_index = 'suggestion_ham'; conv_start = 'APPLY_CHEQUE_BOOK_YN';
					convo(respo[1].toString());
				}
			}
			else if (intent =='GETSRDEL')
			{
				//console.log((respo[1]).toString());
				$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id =srTableDiv_'+div_name+'></div></div>').appendTo($('.mCSB_container')).addClass('new');
				
				var obj = JSON.parse(respo[1].replace(/'/g, ""));
				console.log(typeof obj);
				mytable = document.createElement('table');
				mytable.id = "srTable_"+div_name;
				mytable.className = "upcomingtxntable";
				
				var tbl=$("<table/>").attr({"id":"srTable_"+div_name, "class":"upcomingtxntable"});
				$("#srTableDiv_"+div_name).append(tbl);
				
				var tr_h="<tr><td>Id</td><td>Tracking No</td><td>Request Description</td><td>Status</td><td>Date</td></tr>";
				$("#srTable_"+div_name).append(tr_h);
				for(var i=0;i<obj.length;i++)
				{
					var tr="<tr>";
					var td1="<td>"+obj[i]["ID"]+"</td>";
					var td2="<td>"+obj[i]["TRACKING_NUMBER"]+"</td>";
					var td3="<td>"+obj[i]["REQUEST_DESC"]+"</td>";
					var td4="<td>"+obj[i]["STATUS"]+"</td>";
					var td5="<td>"+obj[i]["TARGET_CLOSE_DATE"]+"</td></tr>";
					$("#srTable_"+div_name).append(tr+td1+td2+td3+td4+td5); 
				}
				
				klo++;
				div_name = "chsrtdiv_"+klo;	
				var msg_to_chat = "<MSG> SERVICE REQUEST STATUS CHECK"
				chathistory(user_session_id,msg_to_chat,"BOT",format_time(),"GETSRDEL");
				setDate();
				updateScrollbar();
                $('.message-input').focus();
				whatelse();
			}
			else if (intent=='CARDBLOC')
			{
				console.log(respo[1].toString())
				console.log(intent)
				$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id ='+div_name+'></div>'+(respo[1]).toString()+'</div>').appendTo($('.mCSB_container')).addClass('new');
				klo++;
				div_name = "chsrtdiv_"+klo;	
				var msg_to_chat = "<MSG>BLOCKING CARD"
				chathistory(user_session_id,msg_to_chat,"BOT",format_time(),"CARD BLOCK");
				setDate();
				updateScrollbar();
                $('.message-input').focus();
				//whatelse();
			}
			else if (intent=='CARDUNBLOC')
			{
				console.log(respo[1].toString())
				console.log(intent)
				$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id ='+div_name+'></div>'+(respo[1]).toString()+'</div>').appendTo($('.mCSB_container')).addClass('new');
				klo++;
				div_name = "chsrtdiv_"+klo;	
				var msg_to_chat = "<MSG>UNBLOCKING CARD"
				chathistory(user_session_id,msg_to_chat,"BOT",format_time(),"CARD UNBLOCK");
				setDate();
				updateScrollbar();
                $('.message-input').focus();
				//whatelse();
			}
            else if (intent=='SMALLTALK'){
                $('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id ='+div_name+'></div>'+respo[1].toString()+'</div>').appendTo($('.mCSB_container')).addClass('new');
				klo++;
				div_name = "chsrtdiv_"+klo;	
				var msg_to_chat = "<MSG>small talk"
				chathistory(user_session_id,msg_to_chat,"BOT",format_time(),"SMALL TALK");
				setDate();
				updateScrollbar();
                $('.message-input').focus();
                
            }
            else if (intent=='CANIAFFORD'){
                //$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>Hey can i afford! wooho</div>').appendTo($('.mCSB_container')).addClass('new');
				caniafford()
                document.getElementById("btn_hamopclo").click();
                var msg_to_chat = "<MSG>can i afford"
				chathistory(user_session_id,msg_to_chat,"BOT",format_time(),"CAN I AFFORD");
				setDate();
				updateScrollbar();
                $('.message-input').focus();
                
            }
             
            else if (intent=='SHOWMENU'){ //{POST FALLBACK CHANGE}
                //$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>Hey can i afford! wooho</div>').appendTo($('.mCSB_container')).addClass('new');
				//$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>My Apologies!! That shouldn\'t happen normally! Please Gimme a minute!</div>').appendTo($('.mCSB_container')).addClass('new');
                
                //$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>Ahh..there we go! I apologize for the issue!</div>').appendTo($('.mCSB_container')).addClass('new');
                
                document.getElementById("btn_hamopclo").click();
                var msg_to_chat = "<MSG>SHOW MENU"
				chathistory(user_session_id,msg_to_chat,"BOT",format_time(),"SHOW MENU");
				setDate();
				//updateScrollbar();
                
            }
            
            else if (intent=='GOINGOUT'){
                //$('<div class="message new" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>Hey can i afford! wooho</div>').appendTo($('.mCSB_container')).addClass('new');
				//alert('going out huh')
                conv_index = 'response_YN';
                conv_start = 'GETWET';
                convo("yes");
                var msg_to_chat = "<MSG>GOING OUT"
				chathistory(user_session_id,msg_to_chat,"BOT",format_time(),"GOING OUT");
				setDate();
				//updateScrollbar();
                
            }
			 msg = "";
        }
		else{
		$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + "Sorry, I'm having trouble understanding you, try asking me in an other way" + '</div>').appendTo($('.mCSB_container')).addClass('new');
		setDate();
		updateScrollbar();
        $('.message-input').focus();
		}
		})
        .catch(function (err) {
			$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + err+ '</div>').appendTo($('.mCSB_container')).addClass('new');
			setDate();
			updateScrollbar();
            $('.message-input').focus();
        });
}
//------------------------------------------- MAIN INTERACTION WITH THE NLG ENGINE - END ----------------------------------------------------------------


//------------------------- RESTAURANT DISPLAY- START ---------------------------------------
function getrestaurantcard(div_id, name, rating, addr)
{
	var i = '<a href="javascript:show_res_details('+div_id+');"class="custom-card">'
			+'<div id=rest_container_'+div_id+' class="card"><div class="container" style="height: auto;color:black;">'
			+'<div class="split_seventy left"><div class="card-body" style="font-size: 11px;"><h4 class="card-title">'+name+'</h4>'
			+'<span><div><span>'+getStars(parseFloat(rating))+'</span></div><div><span>'+addr+'</span>'
			+'</div><div><div><span>Late-night food</span><span>&nbsp;&nbsp;Cosy</span><span>&nbsp;&nbsp;Casual</span></div></div>'
			+'</span></div></div></div></div></a><div style="height:5px;"></div>'
	return i
}

function show_res_details(id){
	var r = '<div id=rest_container_'+id+' class="card">'
				+'<div class="container" style="height: auto;color:black;">'
					+'<div class="split_seventy left">'
						+'<div class="card-body"  style="font-size: 11px;"><h4 class="card-title">'+rest_list[id][0]+'</h4>'
							+'<div>'
								+'<span>'+getStars(parseFloat(rest_list[id][1]))+'</span>'
							+'</div>'
						+'<div>'
					+'<div>'
				+'</div>'
			+'</div>'

	$('<div class="messageresta" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id =rest_div_dic_'+id+'>'+r+'</div></div>').appendTo($('.mCSB_container')).addClass('new');
	conv_index = 'first'; conv_start = 'GETRES';
	//overall_to_location = String(rest_list[id][2]); //{POST FALLBACK CHANGE}
    prefetch_t_location = String(rest_list[id][0]);
	convo("");
}



function getStars(rating) {
  rating = Math.round(rating * 2) / 2;
  let output = [];
  for (var i = rating; i >= 1; i--)
    output.push('<i class="fa fa-star" aria-hidden="true" style="color: gold;"></i>&nbsp;');
  if (i == .5) output.push('<i class="fa fa-star-half-o" aria-hidden="true" style="color: gold;"></i>&nbsp;');
  for (let i = (5 - rating); i >= 1; i--)
    output.push('<i class="fa fa-star-o" aria-hidden="true" style="color: gold;"></i>&nbsp;');
  return output.join('');
}
//----------------------- RESTAURANT DISPLAY- END -------------------------------------------------------------

//----------------------------------------- GET WEATHER - START ------------------------------------------------
function getweathercard(locate)
{
	var loc = locate
	var d = new Date();
	var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
	var finaldate = d.getDate()+" "+months[d.getMonth()] +" " +d.getFullYear();

	$('<div class="message_weather" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id ='+div_name+'>'+ 
	'<div class="weatheroverallcard">'
	+'<div class="weather"><div class="sun" id="sun"></div>'
	+'<div class="temp" id="temp"></div>'
	+'<div class="main_weat" id="main_weat"></div>'
	+'</div><div class="city" id="city"></div>'
	+'<div class="date" id="datecolumn"></div></div>'
	+'</div></div>').appendTo($('.mCSB_container')).addClass('new');

    fetch(`${url}/${loc}/getweather`, {	method: 'GET'})
        .then(function (response) { return response.json(); })
        .then(function (responses) {
          if (responses) {			
			
			var temp = document.getElementsByClassName("temp")[weather_x-1];
			temp.innerHTML = responses.main.temp + "&#176;"
	
			var city = document.getElementsByClassName("city")[weather_x-1];
			city.innerHTML = responses.name

			var weat_main = document.getElementsByClassName("main_weat")[weather_x-1];
			weat_main.innerHTML = responses.weather[0].main
			
			var date_id = document.getElementsByClassName("date")[weather_x-1];
			date_id.innerHTML = finaldate.toString()

			var img=document.createElement("img");
			src="http://openweathermap.org/img/w/"+(responses.weather[0].icon).toString()+".png"
			img.id="picture"
			var foo = document.getElementsByClassName("sun")[weather_x-1];
			foo.style.backgroundImage = "url('"+src+"')"; 
	
          }
		})
        .catch(function (err) {});
	klo++;
	weather_x++;
	div_name = "chsrtdiv_"+klo;
	setDate();
	updateScrollbar();
    $('.message-input').focus();
}
//-----------------------------GET WEATHER - END --------------------------------------------------------



//----------------------- DRAW MAP - START---------------------------------------------
function cab_map(source,destination,message, confirm_flag)
{
	$('<div class="message_noborder" ><figure class="avatar"><img src="./image/single-logo.png"/></figure>'
	+'<div style="background:transparent; height:auto; min-height:25px;color:#5d5d5d;">'+ String(message).toString()+'</div>'
	+'<div class="mapclass" id ='+div_name+'></div></div>').appendTo($('.mCSB_container')).addClass('new');
				
	var directionsService = new google.maps.DirectionsService();
	var directionsDisplay = new google.maps.DirectionsRenderer();
	var map = new google.maps.Map(document.getElementById(div_name), {zoom:7,mapTypeId: google.maps.MapTypeId.ROADMAP });				
	directionsDisplay.setMap(map);    
	var request = { origin: source,   destination: destination,  travelMode: google.maps.DirectionsTravelMode.DRIVING };
	directionsService.route(request, function(response, status) {
	if (status == google.maps.DirectionsStatus.OK) { directionsDisplay.setDirections(response); }});
	klo++;
	div_name = "chsrtdiv_" + klo;
	setDate("map");
	updateScrollbar();
    $('.message-input').focus();
	// msg_to_chat = "<SOURCE>"+"Gachibowli" +"<DESTINATION>"+destination+"<MSG>CABBOOKED"
	// chathistory(user_session_id,msg_to_chat,"BOT",format_time(),"GETCAB");
	// whatelse();
}
//-------------------------------DRAW MAP - END------------------------------------------------------------

//----------------------- DRAW GRAPH & CHART - START ----------------------------------------------
google.charts.load('current',{'packages':['corechart']});
function draw_chart(startepoch, endepoc,chartfor){
	from_txn_date = new Date(parseInt(startepoch)*1000).toISOString().match(/(\d{4}\-\d{2}\-\d{2})T(\d{2}:\d{2}:\d{2})/)[1]; //Pritesh_change
	to_txn_date = new Date(parseInt(endepoc)*1000).toISOString().match(/(\d{4}\-\d{2}\-\d{2})T(\d{2}:\d{2}:\d{2})/)[1]; //Pritesh_change
	draw_C_for= chartfor;
	var JSONURL = "http://10.50.72.76:8087/api/v1/"+user_session_id+"/"+startepoch+"/"+endepoc+"/finanaly/"+ chartfor
	//$.getJSON(JSONURL, callback){}
	$.getJSON(JSONURL, function(data) {
		drawChart(data);
	})
	.fail(function() { 
		pop_msg = "Oops! I don't seem to be able to access any data at the moment !! Please try again after while!!";
		$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' +pop_msg+ '</div>').appendTo($('.mCSB_container')).addClass('new');
		setDate();
		updateScrollbar();
        $('.message-input').focus();
		whatelse();
	})
	
	//google.charts.setOnLoadCallback(drawChart);   // Callback that creates and populates a data table, instantiates the pie chart, passes in the data and draws it.

}



function cant_afford()
{
    pop_msg = "Here's a breakup of your expenses for the last 30 days! Perhaps it'll help you figure out where you can reduce your current spending!";
	$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' +pop_msg+ '</div>').appendTo($('.mCSB_container')).addClass('new');
}
function draw_chart_caniafford(startepoch, endepoc,chartfor){
	from_txn_date = new Date(parseInt(startepoch)*1000).toISOString().match(/(\d{4}\-\d{2}\-\d{2})T(\d{2}:\d{2}:\d{2})/)[1]; //Pritesh_change
	to_txn_date = new Date(parseInt(endepoc)*1000).toISOString().match(/(\d{4}\-\d{2}\-\d{2})T(\d{2}:\d{2}:\d{2})/)[1]; //Pritesh_change
	draw_C_for= chartfor;
	var JSONURL = "http://10.50.72.76:8087/api/v1/"+user_session_id+"/"+startepoch+"/"+endepoc+"/finanaly/"+ chartfor
	//$.getJSON(JSONURL, callback){}
	$.getJSON(JSONURL, function(data) {
		drawChart_caniaf(data);
	})
	.fail(function() { 
		pop_msg = "Oops! I don't seem to be able to access any data at the moment !! Please try again after while!!";
		$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' +pop_msg+ '</div>').appendTo($('.mCSB_container')).addClass('new');
		setDate();
		updateScrollbar();
        $('.message-input').focus();
		//whatelse();
	})
	
	//google.charts.setOnLoadCallback(drawChart);   // Callback that creates and populates a data table, instantiates the pie chart, passes in the data and draws it.

}

function drawChart(dataPoints) {	//Pritesh_change
	try {
		chart_data = dataPoints["chart"];
		table_data = dataPoints["table"];
		if (dataPoints != null && dataPoints != 'undefined'){
			var data = new google.visualization.DataTable();
			data.addColumn('string', 'type');
			data.addColumn('number', '69898');
			data.addRows(Object.values(chart_data));
			
			// Set chart options
			var options = {
				width:400,
				height:250,
				pieHole: 0.4,
				backgroundColor: '#ffffff',
				legend:'labeled', 
				pieSlicetext:'none',
				colors: ['#5DA5DA', '#2f4b7c','#665191','#a05195','#d45087','#f95d6a','#ff7c43','#ffa600', '#003f5c','#4D4D4D',  '#60BD68', '#F17CB0', '#B2912F', '#B276B2', '#DECF3F', '#F15854', '#3366CC', '#22AA99', '#5574A6', '#316395', '#329262'],
				chartArea: {
					height: "100%",
					width: "100%"}
			}; 

		  $(window).on("throttledresize", function (event) {initChart();}); // Instantiate and draw our chart, passing in some options.
			if (draw_C_for == 'getUpcomingTransactions')		
			{
				$('<div class="message_noborder" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div id='+div_name+'_upcmngtab></div><div class="chartgraph" id ='+div_name+'></div></div>').appendTo($('.mCSB_container')).addClass('new');
				setDate();
				var chart = new google.visualization.PieChart(document.getElementById(div_name));
				chart.draw(data, options); 
				var obj= table_data;	
				mytable = document.createElement('table');
				mytable.id = div_name+"_upcomingTable";
				mytable.className = "upcomingtxntable";
				var tbl=$("<table/>").attr({"id":div_name+"_upcomingTable", "class":"upcomingtxntable"});
				$("#"+div_name+"_upcmngtab").append(tbl);
				for(var i=0;i<obj.length;i++)
				{
					var tr="<tr>";
					var td1="<td>"+obj[i]["MERCHANT"]+"</td>";
					var td2="<td>"+obj[i]["CATEGORY"]+"</td>";
					var td3="<td>"+obj[i]["DUE_AMT"]+"</td>";
					var td4="<td>"+obj[i]["DUE_DATE"]+"</td></tr>";
					$("#"+div_name+"_upcomingTable").append(tr+td1+td2+td3+td4); 
				}
			}
			else if (draw_C_for == 'getTransactions')
			{
				$('<div class="message_noborder" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div style="min-height:20px;"><div style="font-size: 10px;border-radius: 20px 20px 0px 20px;width: auto;text-align: center;border: 1px solid;">'+from_txn_date+' - '+to_txn_date+'</div><br/></div><div class="chartgraph" id ='+div_name+'></div></div>').appendTo($('.mCSB_container')).addClass('new');
				setDate();
				
				var chart = new google.visualization.PieChart(document.getElementById(div_name));
				chart.draw(data, options);
			}
			klo++;
			div_name = "chsrtdiv_"+klo;
			updateScrollbar();
            $('.message-input').focus();
			whatelse();
	}
	}	
	catch(err) {
		pop_msg = "I'm unable to find any! Looks like you don't have any upcoming transactions at the moment !!";
		$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' +pop_msg+ '</div>').appendTo($('.mCSB_container')).addClass('new');
		setDate();
		updateScrollbar();
        $('.message-input').focus();
		whatelse();
	}
}
function callback(data) { drawChart(data); }

function drawChart_caniaf(dataPoints) {	//Pritesh_change
	try {
		chart_data = dataPoints["chart"];
		table_data = dataPoints["table"];
		if (dataPoints != null && dataPoints != 'undefined'){
			var data = new google.visualization.DataTable();
			data.addColumn('string', 'type');
			data.addColumn('number', '69898');
			data.addRows(Object.values(chart_data));
			
			// Set chart options
			var options = {
				width:400,
				height:250,
				pieHole: 0.4,
				backgroundColor: '#ffffff',
				legend:'labeled', 
				pieSlicetext:'none',
				colors: ['#5DA5DA', '#2f4b7c','#665191','#a05195','#d45087','#f95d6a','#ff7c43','#ffa600', '#003f5c','#4D4D4D',  '#60BD68', '#F17CB0', '#B2912F', '#B276B2', '#DECF3F', '#F15854', '#3366CC', '#22AA99', '#5574A6', '#316395', '#329262'],
				chartArea: {
					height: "100%",
					width: "100%"}
			}; 

		  $(window).on("throttledresize", function (event) {initChart();}); // Instantiate and draw our chart, passing in some options.
			
			if (draw_C_for == 'getTransactions')
			{
				$('<div class="message_noborder" ><figure class="avatar"><img src="./image/single-logo.png"/></figure><div style="min-height:20px;"><div style="font-size: 10px;border-radius: 20px 20px 0px 20px;width: auto;text-align: center;border: 1px solid;">'+from_txn_date+' - '+to_txn_date+'</div><br/></div><div class="chartgraph" id ='+div_name+'></div></div>').appendTo($('.mCSB_container')).addClass('new');
				setDate();
				
				var chart = new google.visualization.PieChart(document.getElementById(div_name));
				chart.draw(data, options);
			}
			klo++;
			div_name = "chsrtdiv_"+klo;
			updateScrollbar();
            $('.message-input').focus();
			//whatelse();
	}
	}	
	catch(err) {
		pop_msg = "I'm unable to find any! Looks like you don't have any upcoming transactions at the moment !!";
		$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' +pop_msg+ '</div>').appendTo($('.mCSB_container')).addClass('new');
		setDate();
		updateScrollbar();
        $('.message-input').focus();
		whatelse();
	}
}

//------------------------- DRAW GRAPH & CHART - END -------------------------------------------------------------------



//-------------------- WRITE TO CHAT HISTORY - START -----------------------------------------
function chathistory(user_session_id, message, whosent, whattime, intent)
{
    data = {
		user_session_id: user_session_id,
		message:message,
		whosent:whosent,
		whattime:whattime,
		intent:intent
		}
	fetch(`${url}/${id}/writehistory`, {
		method: 'POST', 
		body: JSON.stringify(data)
	})
	.then(function (response) { return response.json(); })
	.then(function (responses) {})
	.catch(function (err) {
		$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>' + "I'm having some technical issues. Try again later :) " +err+ '</div>').appendTo($('.mCSB_container')).addClass('new');
		setDate();
		updateScrollbar();
        $('.message-input').focus();
	});
}
//-------------------- WRITE TO CHAT HISTORY - END -----------------------------------------

function suggestion_ham(button)
{
	document.getElementById("btn_hamopclo").click();
	v = button.value;
	
	//console.log("==BUTTON VAL==", v);
	
	if (v == "ACC_BALANCE"){
		conv_start="ACC_BALANCE"; conv_index="suggestion_ham";
	}
	else if(v == "CR_CARD_OUT"){
		conv_start="CR_CARD_OUT"; conv_index="suggestion_ham";
	}
	else if(v == "APPLY_CHEQUE_BOOK"){
		conv_start="APPLY_CHEQUE_BOOK"; conv_index="suggestion_ham";
	}
	else if(v == "EXP_ANALYSIS"){
		conv_start="EXP_ANALYSIS"; conv_index="suggestion_ham";
	}
	else if(v == "UPCOMING_EXP"){
		conv_start="UPCOMING_EXP"; conv_index="suggestion_ham";
	}
	else if(v == "HAM_WEATHER"){
		conv_start="HAM_WEATHER"; conv_index="suggestion_ham";
	}
	else if(v == "HAM_RESTAURANT"){
		conv_start="HAM_RESTAURANT"; conv_index="suggestion_ham";
	}
	else if(v == "HAM_CAB_BOOK"){
		conv_start="HAM_CAB_BOOK"; conv_index="suggestion_ham";
	}
	convo(msg);
}

function hide_suggestion(){
	document.getElementById('usersuggest').style.display = "none";
}


function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        alert('Sorry, but the price can only be a number! Please try again!')
        return false;
    }
    return true;
}

function isANumber(amt_value){
	return !/\D/.test(amt_value);
}


function enter_from_location()
{	 
	console.log("Please Enter From Location !!");
	loc_type = "Could you please enter the pickup location"
	$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>'+loc_type+'</div>').appendTo($('.mCSB_container')).addClass('new');
	setDate();
	updateScrollbar();
    $('.message-input').focus();
}

function enter_to_location()
{	 
	console.log("Please Enter Drop Location !!");
	loc_type = "Could you please enter the drop location"
	$('<div class="message new"><figure class="avatar"><img src="./image/single-logo.png" /></figure>'+loc_type+'</div>').appendTo($('.mCSB_container')).addClass('new');
	setDate();
	updateScrollbar();
    $('.message-input').focus();
}

function get_converted_price(price){
	var JsonURLs = "http://10.50.72.76:8087/api/v1/"+price+"/amt_convert";
	$.getJSON(JsonURLs, function(data) {
		console.log(price, " get_converted_price==data== ",data);
		var check_price = data;
		return data;
	})
	.fail(function() { 
		console.log("==No Response From Server==Failed !!");
		return 0;
	})
}

function get_converted_price_tmp(price){
	var con_price = 0;
	console.log("get_converted_price===price===", price);
	fetch(`${url}/${price}/amt_convert`, {	method: 'GET'})
        .then(function (response) { return response.json(); })
        .then(function (responses) 
        {
			sleep_func(11000);
			
			console.log("==responses==",responses);
            var check_price = responses;
			var con_price = responses;
            console.log('-------check1----------' + check_price);
            if(check_price==0)
            {
                console.log("==NaN==");
                alert('Oops..I\'m unable to understand that! Please, ensure that the cost is valid for e.g. \'65000\' or \'65lacs\' or \'cne crore\'!')
                $('.message-input').attr("placeholder", "Please enter a number for the price");	
                document.getElementById('userInput').value = "";
                return false;
            }
        })
		console.log("get_converted_price===con_price===", con_price);
		return con_price
}


function sleep_func(milliseconds) {
  var start = new Date().getTime();
  for (var i = 0; i < 1e7; i++) {
    if ((new Date().getTime() - start) > milliseconds){
      break;
    }
  }
}

function timeout_ms(ms, promise) {
  return new Promise(function(resolve, reject) {
    setTimeout(function() {
      reject(new Error("timeout"))
    }, ms)
    promise.then(resolve, reject)
  })
}