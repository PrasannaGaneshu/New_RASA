const url = 'http://10.50.72.76:8085/api/v1';


function call_history()
{
fetch(`${url}/shreeramuniq139/fetchhistory`, {
			method: 'GET'
		})
        .then(function (response) {
            return response.json();
        })
        .then(function (responses) {

			// //Month Arrays -----------------------------------------------------------
			// var monthsEnglish = ["January","February","March","April", "May", "June", "July", "August", "September","October","November","December"];
			// var monthsSpanish = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre ","Octubre ","Noviembre","Diciembre"];
			// //Static content ---------------------------------------------------------
			// document.write("<table border='1' width='200'>")
			// document.write("<tr><th>Month #</th><th>English</th><th>Spanish</th></tr>");
			// //Dynamic content --------------------------------------------------------
			// for(var i=0; i<12;i++)
			// {
				// document.write("<tr><td>" + (i+1) + "</td><td>" + monthsEnglish[i] + "</td><td>" + monthsSpanish[i] +"</td></tr>");
			// }
			// //Static content  --------------------------------------------------------
			// document.write("</table>")
			
			
			
			console.log(responses);
			

		})
        .catch(function (err) {
			
        });
}

function createable(USER_ID,MSG,WHO,INTENT,TIMESTAMP)
{
	
	var html = "";
    for (var i = 0; i < 10; i++){
    html +="<tr>"+
            "<td>"+ (i+1) + "</td>"+
            "<td>"+ data[i].name + "</td>"+
            "<td>"+ data[i].number + "</td>"+
            "<td>"+ data[i].city + "</td>"+
            "<td>"+ data[i].hobby + "</td>"+
            "<td>"+ data[i].birthdate + "</td>"+"<td><button data-arrayIndex='"+ i +"' onclick='editData(this)'>Edit</button><button data-arrayIndex='"+ i +"' onclick='deleteData()'>Delete</button></td>"+"</tr>";
}
$("#tableHtml").html(html);
}