const url = 'http://10.50.72.76:8087/api/v1';

//---user validateion page---

var login_input = document.getElementById("login_input_txt");
//console.log("=======login_input======", login_input);
login_input.addEventListener("keyup", function(event) {
    event.preventDefault();
    if (event.keyCode === 13) {
        popuservalidate();
    }
});

function popuservalidate()
{
	var x = document.getElementById("login_input_txt").value;
	validate_user(x);
	//document.getElementById("login_input_txt").value ="";
}

function validate_user(username)
{
	fetch(`${url}/status`, {
        method: 'GET'
    })
        .then(function (response) {
            fetch(`${url}/${username}/validate`, {
        method: 'GET'
    })
        .then(function (response) {
            return response.json();
        })
		.then(function (responses) {
			if (responses)
			{
			localStorage.setItem("responses",responses);
			localStorage.setItem("storageName",username);
			self.location = "index.html";
			
			//opener.open(index.html, '_blank');
			//window.open('', '_parent', '').close();
			}
			else
			{
			   alert("Oops! Something went wrong! Please check the UserId you entered!");
			   document.getElementById("login_input_txt").value = "";
			}
		})
      })
        .catch(function (response) {
            
        })	
}
