import logging
from rasa_core.agent import Agent
from rasa_core.interpreter import RasaNLUInterpreter
from rasa_core.channels.direct import CollectingOutputChannel
from flask import json
from klein import Klein
from pymongo import MongoClient
from pymongo import DESCENDING
import datetime
import urllib3
http=urllib3.PoolManager()
import json
import requests
import time
import calendar
from ast import literal_eval
import os
import can_i_afford_final
import amount_convert

openweather_api_key = 'ada46595eac2c9447738e2ba95f0bd2d'
logger = logging.getLogger(__name__)
client = MongoClient('10.50.72.77', 27018) # OFFICE CONNECT
#client = MongoClient('localhost', 27017) # HOME CONNECT
db = client.convai

def request_parameters(request):
	if request.method.decode('utf-8', 'strict') == 'GET':
		return {
			key.decode('utf-8', 'strict'): value[0].decode('utf-8','strict')
			for key, value in request.args.items()}
	else:
		content = request.content.read()
		try:
			return json.loads(content.decode('utf-8', 'strict'))
		except ValueError as e:
			logger.error("Failed to decode json during respond request. Error: {}. Request content: '{}' ".format(e, content))
			raise


class Server:
	app = Klein()

	def __init__(self, model_directory, interpreter):
		self.model_directory = model_directory
		self.interpreter = interpreter
		self.agent = self._create_agent(model_directory, interpreter)

	@staticmethod
	def _create_agent(model_directory, interpreter):
		"""Creates a Rasa Agent which runs when the server is started"""
		try:
			return Agent.load(model_directory, interpreter)
		except Exception as e:
			logger.warn("Failed to load any agent model. Running Rasa Core server with out loaded model now. {}".format(e))
			return None
            
            
            
            
            
            

	@app.route("/api/v1/status", methods=['GET'])
	def status(self, request):
		"""Check if the server is running and responds with the status."""
		request.setHeader('Access-Control-Allow-Origin', '*')
		return json.dumps({'status': 'OK'})
        
        

	@app.route('/api/v1/<sender_id>/parse', methods=['GET', 'POST'])
	def parse(self, request, sender_id):
		request.setHeader('Content-Type', 'application/json')
		request_params = request_parameters(request)

		if 'query' in request_params:
			message = request_params.pop('query')
		elif 'q' in request_params:
			message = request_params.pop('q')
		else:
			request.setResponseCode(400)
			return json.dumps({"error": "Invalid parse parameter specified"})
		try:
			response = self.agent.start_message_handling(message, sender_id)
			request.setResponseCode(200)
			return json.dumps(response)
		except Exception as e:
			request.setResponseCode(500)
			logger.error("Caught an exception during parse: {}".format(e), exc_info=1)
			return json.dumps({"error": "{}".format(e)})

	@app.route('/api/v1/<sender_id>/respond', methods=['GET', 'POST'])
	def respond(self, request, sender_id):
		request.setHeader('Content-Type', 'application/json')
		request.setHeader('Access-Control-Allow-Origin', '*')
        
        
		request_params = request_parameters(request)
		print("=========Request PARam================: ",request_params)
		if 'query' in request_params:
			message = request_params.pop('query')
		elif 'q' in request_params:
			message = request_params.pop('q')
		else:
			request.setResponseCode(400)
			return json.dumps({"error": "Invalid parse parameter specified"})
		try:
			out = CollectingOutputChannel()
			print("***********", message, "====", out, "====", sender_id)
			response = self.agent.handle_message(message, output_channel=out, sender_id=sender_id)
			request.setResponseCode(200)
			print("TRY: " , response)
			return json.dumps(response)
		except Exception as e:
			request.setResponseCode(500)
			logger.error("Caught an exception during parse: {}".format(e), exc_info=1)
			return json.dumps({"error": "{}".format(e)})


	@app.route('/api/v1/<sender_id>/validate', methods=['GET', 'POST'])
	def validate(self, request, sender_id):
		request.setHeader('Content-Type', 'application/json')
		request.setHeader('Access-Control-Allow-Origin', '*')
		request_params = request_parameters(request)
		data=""
		i=""
		try:
			user_sent = str(sender_id).upper()
			info  = db.rasa_cust_info.find({"LINKED_USERID":user_sent})
			for i in info:
				data = "Hey there, "+ str(i['PREFIX']).title() +". "+ str(i['FULL_NAME']).title() +"! I'm Tyche, the Banking Virtual Assistant!<br/>I can help you make a purchase decision, and can also provide you with information about your account and expenses!<br><br/> You can explore more in the menu! Just type \' MENU \' to begin!"
			#return json.dumps({"wlcm_msg":str(data)})
			return json.dumps(str(data))
		except Exception as e:
			request.setResponseCode(500)
			logger.error("Caught an exception during parse: {}".format(e), exc_info=1)
			return json.dumps({"error": "{}".format(e)})


	@app.route('/api/v1/<sender_id>/writehistory', methods=['POST'])
	def writehistory(self, request, sender_id):
		request.setHeader('Content-Type', 'application/json')
		request.setHeader('Access-Control-Allow-Origin', '*')
		request_params = request_parameters(request)
		#user_session_id = str(sender_id).upper()
		print(request_params)
		if 'user_session_id' in request_params:
			user_session_id = request_params.pop('user_session_id')
		if 'message' in request_params:
			message = request_params.pop('message')
		if 'whosent' in request_params:
			whosent  = request_params.pop('whosent')
		if 'whattime' in request_params:
			whattime = request_params.pop('whattime')
		if 'intent' in request_params:
			intent = request_params.pop('intent')
		try:
			db.rasa_chat_log.insert({"user_session_id":user_session_id,"message":message,"whosent":whosent,"whattime":whattime,"intent":intent})
			return json.dumps({"InsertStatus":"inserted successfully"})
		except Exception as e:
			request.setResponseCode(500)
			logger.error("Caught an exception during parse: {}".format(e), exc_info=1)
			return json.dumps({"InsertStatus_error": "{}".format(e)})

	@app.route('/api/v1/<sender_id>/fetchhistory', methods=['GET', 'POST'])
	def fetchhistory(self, request, sender_id):
		request.setHeader('Content-Type', 'application/json')
		request.setHeader('Access-Control-Allow-Origin', '*')
		request_params = request_parameters(request)
		data =[]
		i=""
		try:
			user_sent = str(sender_id).lower()
			info = db.rasa_chat_log.find({"user_session_id":user_sent}).sort("whattime",DESCENDING)
			k = db.rasa_chat_log.find({"user_session_id":user_sent}).count()
			l=1
			for i in info:
				if l <= k:
					data.append(json.dumps({"USER_ID":i['user_session_id'], "MSG":i['message'] , "WHO": i['whosent'],"INTENT":i['intent'] ,"TIMESTAMP":i['whattime']}))

			da = {}
			for i in data:
			    j = json.dumps(i)
			    try:
			        j = json.loads(i)
			    except:
			        j = dict(i)
			    print("================",j)
			    t = time.strftime('%Y-%m-%d', time.localtime(int(j['TIMESTAMP'])))
			    t1 = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(int(j['TIMESTAMP'])))
			    j.update({'TIMESTAMP' : t1})
			    if not da:
			        da.update({t : [j]})
			    else:
			        if t in da:
			            ll = da[t]
			            ll.insert(0,j)
			        else:
			            da.update({t : [j]})


			return json.dumps(da)
		except Exception as e:
			request.setResponseCode(500)
			logger.error("Exception while fetching the data".format(e), exc_info=1)
			return json.dumps({"Exception while fetching the data": "{}".format(e)})

	@app.route('/api/v1/<sender_id>/lgusrloc', methods=['POST'])
	def lgusrloc(self, request, sender_id):
		request.setHeader('Content-Type', 'application/json')
		request.setHeader('Access-Control-Allow-Origin', '*')
		request_params = request_parameters(request)
		try:
			epochdatetime = int(datetime.datetime.now().strftime("%s")) * 1000
			if 'lat' in request_params:
				lat=request_params.pop('lat')
			if 'lon' in request_params:
				lon=request_params.pop('lon')
			if 'userid' in request_params:
				userid=request_params.pop('userid')
			db.cva_user_loc.insert({"userid":userid,"lat":lat,"lon":lon,"epochdatetime":epochdatetime})
			#print ("Response: "+ request_params)
      
      
      
			return json.dumps({"InsertStatus":"inserted successfully"})
		except Exception as e:
			request.setResponseCode(500)
			logger.error("Exception while fetching the data".format(e), exc_info=1)
			return json.dumps({"Exception while fetching the data": "{}".format(e)})

	@app.route("/api/v1/<sender_id>/<stepoch>/<enepoch>/finanaly/<forchart>", methods=['GET'])
	def finanaly(self, request, sender_id,stepoch,enepoch,forchart):
		request.setHeader('Content-Type', 'application/json')
		request.setHeader('Access-Control-Allow-Origin', '*')
		request_params = request_parameters(request)
		from_date 	= int(stepoch)
		to_date 	= int(enepoch)
		forchart = str(forchart)
		iMob_API_1 = "https://10.158.2.90/amaze/rest/api/"
		iMob_API_3 = "&RRN=123&CHANNEL=ABC&MOBILE=97867476"
		try:
			userid= str(sender_id).upper()
			URL = iMob_API_1 + forchart +"?USERID="+userid+ iMob_API_3
			data = http.request('GET',URL)
			JSON_data = json.loads(data.data.decode('UTF-8'))
			print(".....................", JSON_data, ".............")
			if (int(JSON_data['STATUS']) == 200):
				if(forchart == 'getTransactions'):
					resp_data = JSON_data["TRANSACTIONS"]
					resp_data = [k for k in JSON_data["TRANSACTIONS"] if k["debit_CREDIT"] == "DR"]
					i = len(resp_data)
					print("records : ",i)
					start_index = 0
					end_index	= i

					for i, d in enumerate(resp_data):
						if int(to_date*1000) >= int(d['tran_DATE_TIME']):
							print("==to_date==",i, "==",int(to_date*1000),d['tran_DATE_TIME'])
							print(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(to_date)))
							print(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(int(d['tran_DATE_TIME']/1000))))
							start_index = i
							break;

					for j, d in enumerate(resp_data):
						if int(from_date*1000) >= int(d['tran_DATE_TIME']):
							print("==from_date==",j, "==",int(from_date*1000),d['tran_DATE_TIME'])
							print(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(from_date)))
							print(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(int(d['tran_DATE_TIME']/1000))))
							end_index = j
							break;

					print("indexes :",start_index, end_index)
					req_data = resp_data[start_index:end_index]
					dd = {}
					res_list = []
					print(req_data)
					for d in req_data:
						#print(d['bucket'], d['amount'])
						if d['bucket'] in dd:
							amt = float(dd[d['bucket']]) + float(d['amount'])
							dd.update({ d['bucket'] : amt })
						else:
							dd.update({d['bucket'] : float(d['amount'])})

					#print(start_index, end_index)

					for i in dd:
						res_list.append([i, dd[i]])

					print(res_list)
					print(json.dumps({"chart":res_list, "table":resp_data}))
					return json.dumps({"chart":res_list, "table":resp_data}) #json.dumps([dd])
					#return str(resp_data[start_index:end_index])

				elif (forchart == 'getUpcomingTransactions'):
					resp_data = JSON_data["getUpcomingTransactions"]
					j = len(resp_data)
					dd = {}
					res_list = []
					for d in resp_data:
						if d['CATEGORY'] in dd:
							amt = float(dd[d['CATEGORY']]) + float(d['DUE_AMT'])
							dd.update({ d['CATEGORY'] : amt })
						else:
							dd.update({d['CATEGORY'] : float(d['DUE_AMT'])})
					for i in dd:
						res_list.append([i, dd[i]])
					print(res_list)
					#print(json.dumps({"chart":res_list, "table":resp_data}))
					return json.dumps({"chart":res_list, "table":resp_data})
					#return json.dumps(res_list)#res_list

				return json.dumps({"InsertStatus":"inserted successfully"})
			else:
				 return json.dumps({})
		except Exception as e:
			request.setResponseCode(500)
			logger.error("Exception while fetching the data".format(e), exc_info=1)
			return json.dumps({"Exception while fetching the data": "{}".format(e)})

	@app.route("/api/v1/<location>/getweather", methods=['GET'])
	def getweather(self, request, location):
		request.setHeader('Content-Type', 'application/json')
		request.setHeader('Access-Control-Allow-Origin', '*')
		request_params = request_parameters(request)
   
   
   
		loca = str(location)
		owm_url = 'https://api.openweathermap.org/data/2.5/weather?units=metric'
		owm_param = {'q':loca,'appid':openweather_api_key}
		owm_request = requests.get(owm_url,params=owm_param)
		owm_response = owm_request.json()
   
   
		return json.dumps(owm_response)

	@app.route("/api/v1/<senderid>/<prod_price>/<prod_name>/<prod_catg>/<loan_flag>/<loan_catg>/caniafford", methods=['GET'])
	def caniafford(self, request, senderid, prod_price, prod_name, prod_catg, loan_flag,loan_catg):
		request.setHeader('Content-Type', 'application/json')
		request.setHeader('Access-Control-Allow-Origin', '*')
		request_params = request_parameters(request)
		result = can_i_afford_final.main(senderid,prod_price,prod_name,prod_catg,loan_flag,loan_catg)
		final_result = [item for sublist in result for item in sublist]
		return json.dumps(final_result)

		
	@app.route("/api/v1/<senderid>/<prod_price>/<prod_name>/<prod_catg>/<loan_flag>/<loan_catg>/caniafford_new", methods=['GET'])
	def caniafford_new(self, request, senderid, prod_price, prod_name, prod_catg, loan_flag,loan_catg):
		request.setHeader('Content-Type', 'application/json')
		request.setHeader('Access-Control-Allow-Origin', '*')
		request_params = request_parameters(request)
		result = can_i_afford_final.main(senderid,prod_price,prod_name,prod_catg,loan_flag,loan_catg)
		final_result = [item for sublist in result for item in sublist]
		return json.dumps(final_result)
    
	@app.route("/api/v1/<prod_price>/amt_convert", methods=['GET'])
	def amt_convert(self, request, prod_price):
		request.setHeader('Content-Type', 'application/json')
		request.setHeader('Access-Control-Allow-Origin', '*')
		request_params = request_parameters(request)
		result = amount_convert.amt_start(prod_price)
		#final_result = [item for sublist in result for item in sublist]
		return json.dumps(result)

		
if __name__ == "__main__":
    server = Server("models/dialogue", RasaNLUInterpreter("models/nlu/default/current"))
    server.app.run("0.0.0.0", 8087)
