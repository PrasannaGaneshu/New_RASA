## story 01
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getrestaurant{"location": "italy"}
    - slot{"location": "italy"}
    - action_restaurant
	- slot{"location":"italy"}
	- slot{"user_id": "shreeramuniq139"}
	
## story 02
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getrestaurant{"location": "italy"}
    - slot{"location": "italy"}
    - action_restaurant
	- slot{"location":"italy"}
	- slot{"user_id": "shreeramuniq139"}

	
## story 03
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getrestaurant{"location": "italy"}
    - slot{"location": "italy"}
    - action_restaurant
	- slot{"location":"italy"}
	- slot{"user_id": "shreeramuniq139"}

## story 04
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getrestaurant{"location": "italy"}
    - slot{"location": "italy"}
    - action_restaurant
	- slot{"location":"italy"}
	- slot{"user_id": "shreeramuniq139"}
	
## story 05
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getrestaurant{"location": "italy"}
    - slot{"location": "italy"}
    - action_restaurant
	- slot{"location":"italy"}
	- slot{"user_id": "shreeramuniq139"}
	
## story 06
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getrestaurant{"location": "italy"}
    - slot{"location": "italy"}
    - action_restaurant
	- slot{"location":"italy"}
	- slot{"user_id": "shreeramuniq139"}
	
## story 07
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getrestaurant{"location": "italy"}
    - slot{"location": "italy"}
    - action_restaurant
	- slot{"location":"italy"}
	- slot{"user_id": "shreeramuniq139"}
	
## story 08
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getrestaurant{"location": "italy"}
    - slot{"location": "italy"}
    - action_restaurant
	- slot{"location":"italy"}
	- slot{"user_id": "shreeramuniq139"}
	
## story 09
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getrestaurant{"location": "italy"}
    - slot{"location": "italy"}
    - action_restaurant
	- slot{"location":"italy"}
	- slot{"user_id": "shreeramuniq139"}
	
## story 10
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getrestaurant{"location": "italy"}
    - slot{"location": "italy"}
    - action_restaurant
	- slot{"location":"italy"}
	- slot{"user_id": "shreeramuniq139"}
	
## story 11
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getrestaurant{"location": "italy"}
    - slot{"location": "italy"}
    - action_restaurant
	- slot{"location":"italy"}
	- slot{"user_id": "shreeramuniq139"}
	
## story 12
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getrestaurant{"location": "italy"}
    - slot{"location": "italy"}
    - action_restaurant
	- slot{"location":"italy"}
	- slot{"user_id": "shreeramuniq139"}