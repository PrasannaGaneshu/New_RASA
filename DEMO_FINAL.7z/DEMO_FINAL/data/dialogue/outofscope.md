##Generated Story 001
* out_of_scope
    - utter_out_of_scope

##Generated Story 002
* getrestaurant{"cuisine": "mexican", "location": "delhi"}
	- slot{"cuisine": "mexican"}
    - slot{"location": "delhi"}
    - action_restaurant
    - slot{"location": "delhi"}
    - slot{"cuisine": "mexican"}
* out_of_scope
    - utter_out_of_scope

##Generated Story 003
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>prabha0901"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>prabha0901"}
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope
    
    
##Generated Story 004
* captureuserid{"ORG": "LLLLLLLLLLLL0000000000000", "user_id": "arvindba098"}
- slot{"user_id": "arvindba098"}
- action_storeuseid
- slot{"user_id": "ARVINDBA098"}
- slot{"location": "default"}
* captureuserid{"ORG": "LLLLLLLLLLLL0000000000000", "user_id": "arvindba098"}
- slot{"user_id": "arvindba098"}
- action_storeuseid
- slot{"user_id": "ARVINDBA098"}
- slot{"location": "default"}
* out_of_scope
- utter_out_of_scope
* captureuserid{"ORG": "LLLLLLLLLLLL0000000000000", "user_id": "arvindba098"}
- slot{"user_id": "arvindba098"}
- action_storeuseid
- slot{"user_id": "ARVINDBA098"}
- slot{"location": "default"}
* getweather
- action_weather
* captureuserid{"ORG": "LLLLLLLLLLLL0000000000000", "user_id": "arvindba098"}
- slot{"user_id": "arvindba098"}
- action_storeuseid
- slot{"user_id": "ARVINDBA098"}
- slot{"location": "default"}
* getrestaurant{"location": "mumbai"}
- slot{"location": "mumbai"}
- action_restaurant
* captureuserid{"ORG": "LLLLLLLLLLLL0000000000000", "user_id": "arvindba098"}
- slot{"user_id": "arvindba098"}
- action_storeuseid
- slot{"user_id": "ARVINDBA098"}
- slot{"location": "default"}

##Generated Story 005
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>SHREERAMUNIQ", "user_id": "shreeramuniq"}
	- slot{"user_id": "shreeramuniq"}
	- action_storeuseid
	- slot{"user_id": "SHREERAMUNIQ"}
	- slot{"location": "default"}
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>SHREERAMUNIQ", "user_id": "shreeramuniq"}
	- slot{"user_id": "shreeramuniq"}
	- action_storeuseid
	- slot{"user_id": "SHREERAMUNIQ"}
	- slot{"location": "default"}
* out_of_scope
	- utter_out_of_scope
* out_of_scope
	- utter_out_of_scope
* out_of_scope
	- utter_out_of_scope
* getweather{"location": "bangkok"}
	- slot{"location": "bangkok"}
	- action_weather
	- slot{"location": "bangkok"}
* out_of_scope{"ORG": "vfhjidjf;fkfqhdp"}
	- utter_out_of_scope
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>SHREERAMUNIQ", "user_id": "shreeramuniq"}
	- slot{"user_id": "shreeramuniq"}
	- action_storeuseid
	- slot{"user_id": "SHREERAMUNIQ"}
	- slot{"location": "default"}
* out_of_scope
	- utter_out_of_scope
	

##Generated Story 006
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>SHREERAMUNIQ", "user_id": "shreeramuniq"}
	- slot{"user_id": "shreeramuniq"}
	- action_storeuseid
	- slot{"user_id": "SHREERAMUNIQ"}
	- slot{"location": "default"}
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>SHREERAMUNIQ", "user_id": "shreeramuniq"}
	- slot{"user_id": "shreeramuniq"}
	- action_storeuseid
	- slot{"user_id": "SHREERAMUNIQ"}
	- slot{"location": "default"}

##Generated Story 007
* captureuserid{"GPE": "LLLLLLLLLLLL0000000000000>PRABHA0901"}
    - action_storeuseid
* getweather{"location": "chennai"}
    - slot{"location": "chennai"}
    - action_weather
    - slot{"location": "chennai"}
* out_of_scope
	- utter_out_of_scope

##Generated Story 008
* captureuserid{"user_id": "llllllllllll0000000000000>prabha0901"}
    - slot{"user_id": "llllllllllll0000000000000>prabha0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope
	
	
##Generated Story 009
* captureuserid{"user_id": "llllllllllll0000000000000>prabha0901"}
    - slot{"user_id": "llllllllllll0000000000000>prabha0901"}
* getweather{"location": "chennai"}
    - slot{"location": "chennai"}
    - action_weather
    - slot{"location": "chennai"}

##Generated Story 010
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>PRABHA0901"}
* getrestaurant
    - action_restaurant
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope
	
##Generated Story 011
* captureuserid{"user_id": "llllllllllll0000000000000>prabha0901"}
    - slot{"user_id": "llllllllllll0000000000000>prabha0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* getweather{"location": "chennai"}
    - slot{"location": "chennai"}
    - action_weather
    - slot{"location": "chennai"}
    - slot{"pickup_location": "chennai"}
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope

## Generated Story 012
* captureuserid{"GPE": "LLLLLLLLLLLL0000000000000>PRABHA0901", "user_id": "llllllllllll0000000000000>prabha0901"}
    - slot{"user_id": "llllllllllll0000000000000>prabha0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* out_of_scope
    - utter_out_of_scope
* geteodbal
    - action_accntbal
* getcab{"pickup_location": "chennai", "drop_location": "hyderabad"}
    - slot{"pickup_location": "chennai"}
    - slot{"drop_location": "hyderabad"}
    - action_getcab
    - slot{"pickup_location": "chennai"}
    - slot{"drop_location": "hyderabad"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "chennai"}
    - slot{"bkd_drop_location": "hyderabad"}
* getccoutstanding{"ccoutstanding": "credit card outstanding"}
* geteodbal
* getsrdelivery{"srdmp": "service request"}
    - slot{"srdmp": "service request"}
* getstatements{"DATE": "today", "txntype": "expenditure"}
    - slot{"DATE": "today"}
* getupcomingexpense{"acc_act_type": "upcoming expense"}
* getweather{"location": "chennai"}
    - slot{"location": "chennai"}
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope