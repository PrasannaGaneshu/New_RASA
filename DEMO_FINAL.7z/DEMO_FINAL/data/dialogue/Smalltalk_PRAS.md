
###Generated Story 11
 * greetings.hello
      - utter_greetings.hello

 * greetings.hello
      - utter_greetings.hello

 * greetings.hello
      - utter_greetings.hello

 * greetings.hello
      - utter_greetings.hello
 * greetings.hello
      - utter_greetings.hello

 * greetings.hello
      - utter_greetings.hello


#####Generated Story2#Pras
* appraisal.thank_you
    - utter_appraisal.thank_you
* appraisal.thank_you
    - utter_appraisal.thank_you
* appraisal.thank_you
    - utter_appraisal.thank_you
* appraisal.thank_you
    - utter_appraisal.thank_you
* appraisal.thank_you
    - utter_appraisal.thank_you
* appraisal.thank_you
    - utter_appraisal.thank_you
* appraisal.thank_you
    - utter_appraisal.thank_you
* appraisal.thank_you
    - utter_appraisal.thank_you
