## Story 01
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNIQ139", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
    - slot{"SR_flag": "firstimenothing"}
* getnewcheckbook
    - action_getcheckbook
    - slot{"user_id": "shreeramuniq139"}
    - slot{"SR_flag": "cheque book"}
* confirmation.no
    - utter_no_problem
    - action_reset_sr
    - slot{"SR_flag": "firstimenothing"}

## Story 02
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNIQ139", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
    - slot{"SR_flag": "firstimenothing"}
* getnewcheckbook
    - action_getcheckbook
    - slot{"user_id": "shreeramuniq139"}
    - slot{"SR_flag": "cheque book"}
* confirmation.yes
    - action_getcheckbook
    - slot{"user_id": "shreeramuniq139"}
    - slot{"SR_flag": "firstimenothing"}

## Story 03
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNIQ139", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
    - slot{"SR_flag": "firstimenothing"}
* getnewcheckbook
    - action_getcheckbook
    - slot{"user_id": "shreeramuniq139"}
    - slot{"SR_flag": "cheque book"}
* confirmation.no
    - utter_no_problem
    - action_reset_sr
    - slot{"SR_flag": "firstimenothing"}

## Story 04
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNIQ139", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
    - slot{"SR_flag": "firstimenothing"}
* getnewcheckbook
    - action_getcheckbook
    - slot{"user_id": "shreeramuniq139"}
    - slot{"SR_flag": "cheque book"}
* confirmation.yes
    - action_getcheckbook
    - slot{"user_id": "shreeramuniq139"}
    - slot{"SR_flag": "firstimenothing"}
	
## Story 05
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNIQ139", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
    - slot{"SR_flag": "firstimenothing"}
* getstatements
    - action_upcomingexpense
    - slot{"user_id": "shreeramuniq139"}
* getupcomingexpense
    - action_upcomingexpense
    - slot{"user_id": "shreeramuniq139"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "shreeramuniq139"}

## Story 06
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNIQ139", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
    - slot{"SR_flag": "firstimenothing"}
* getnewcheckbook
    - action_getcheckbook
    - slot{"user_id": "shreeramuniq139"}
    - slot{"SR_flag": "cheque book"}
* confirmation.yes
    - action_getcheckbook
    - slot{"user_id": "shreeramuniq139"}
    - slot{"SR_flag": "firstimenothing"}
* getstatements
    - action_upcomingexpense
    - slot{"user_id": "shreeramuniq139"}
* getupcomingexpense
    - action_upcomingexpense
    - slot{"user_id": "shreeramuniq139"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "shreeramuniq139"}