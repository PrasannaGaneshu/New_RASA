
########Generated Story for SR Deliverables####PRAS
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "shreeramuniq139"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "shreeramuniq139"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "shreeramuniq139"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "shreeramuniq139"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "shreeramuniq139"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "shreeramuniq139"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "shreeramuniq139"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "shreeramuniq139"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "shreeramuniq139"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "shreeramuniq139"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "shreeramuniq139"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "shreeramuniq139"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "shreeramuniq139"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "shreeramuniq139"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "shreeramuniq139"}






## Generated Story 1588078643823248219
* captureuserid{"user_id": "llllllllllll0000000000000>prabha0901"}
    - slot{"user_id": "llllllllllll0000000000000>prabha0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* caniafford
    - action_caniafford
* getcab
    - action_getcab
    - slot{"pickup_location": "default"}
    - slot{"drop_location": "default"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "default"}
    - slot{"bkd_drop_location": "default"}


## Generated Story -5071075282352229301
* captureuserid{"user_id": "llllllllllll0000000000000>prabha0901"}
    - slot{"user_id": "llllllllllll0000000000000>prabha0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* caniafford
    - action_caniafford
* getcab
    - action_getcab
    - slot{"pickup_location": "default"}
    - slot{"drop_location": "default"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "default"}
    - slot{"bkd_drop_location": "default"}
* caniafford
    - action_caniafford
* getcab
    - action_getcab
    - slot{"pickup_location": "default"}
    - slot{"drop_location": "default"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "default"}
    - slot{"bkd_drop_location": "default"}
* getcab
    - action_getcab
    - slot{"pickup_location": "default"}
    - slot{"drop_location": "default"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "default"}
    - slot{"bkd_drop_location": "default"}
* getcab
    - action_getcab
    - slot{"pickup_location": "default"}
    - slot{"drop_location": "default"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "default"}
    - slot{"bkd_drop_location": "default"}
* caniafford
    - action_caniafford
* getcab
    - action_getcab
    - slot{"pickup_location": "default"}
    - slot{"drop_location": "default"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "default"}
    - slot{"bkd_drop_location": "default"}
* out_of_scope
    - utter_out_of_scope
* getcab
    - action_getcab
    - slot{"pickup_location": "default"}
    - slot{"drop_location": "default"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "default"}
    - slot{"bkd_drop_location": "default"}
* out_of_scope
    - utter_out_of_scope
* getcab
    - action_getcab
    - slot{"pickup_location": "default"}
    - slot{"drop_location": "default"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "default"}
    - slot{"bkd_drop_location": "default"}
* getccoutstanding{"ccoutstanding": "credit card outstanding"}
    - action_ccoutstanding
* getccoutstanding{"cuisine": "cc outstanding"}
    - slot{"cuisine": "cc outstanding"}
    - action_ccoutstanding
* getccoutstanding{"cuisine": "cc outstanding"}
    - slot{"cuisine": "cc outstanding"}
    - action_ccoutstanding
* getccoutstanding{"cuisine": "cc outstanding"}
    - slot{"cuisine": "cc outstanding"}
    - action_ccoutstanding
* getccoutstanding{"ccoutstanding": "credit card outstanding"}
    - action_ccoutstanding
* geteodbal
    - action_accntbal
* geteodbal
    - action_accntbal
* geteodbal
    - action_accntbal
* geteodbal{"DATE": "today"}
    - slot{"DATE": "today"}
    - action_accntbal
* getrestaurant
    - action_restaurant
    - slot{"location": "Mumbai"}
* getrestaurant{"cuisine": "restaurant"}
    - slot{"cuisine": "restaurant"}
    - action_restaurant
    - slot{"location": "Mumbai"}
* getrestaurant
    - action_restaurant
    - slot{"location": "Mumbai"}
* getsrdelivery{"srdmp": "service request"}
    - slot{"srdmp": "service request"}
    - action_srdeliverables
    - slot{"user_id": "PRABHA0901"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "PRABHA0901"}
* getsrdelivery
    - action_srdeliverables
    - slot{"user_id": "PRABHA0901"}
* out_of_scope
    - utter_out_of_scope



## Generated Story -4742233734199976057
* captureuserid{"user_id": "llllllllllll0000000000000>prabha0901"}
    - slot{"user_id": "llllllllllll0000000000000>prabha0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* getsrdelivery{"srdmp": "Deliverables"}
    - slot{"srdmp": "Deliverables"}
    - action_srdeliverables
    - slot{"user_id": "PRABHA0901"}
* caniafford
    - action_caniafford
* caniafford
    - action_caniafford
* caniafford
    - action_caniafford
* caniafford
    - action_caniafford
* getcab{"pickup_location": "hyderabad"}
    - slot{"pickup_location": "hyderabad"}
    - action_getcab
    - slot{"pickup_location": "hyderabad"}
    - slot{"drop_location": "default"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "hyderabad"}
    - slot{"bkd_drop_location": "default"}
* getcab{"pickup_location": "madhapur", "drop_location": "gachibowli"}
    - slot{"pickup_location": "madhapur"}
    - slot{"drop_location": "gachibowli"}
    - action_getcab
    - slot{"pickup_location": "madhapur"}
    - slot{"drop_location": "gachibowli"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "madhapur"}
    - slot{"bkd_drop_location": "gachibowli"}
* getccoutstanding{"ccoutstanding": "credit card outstanding"}
    - action_ccoutstanding
* getccoutstanding{"ccoutstanding": "cc outstanding"}
    - action_ccoutstanding
* getccoutstanding
    - action_ccoutstanding
* getccoutstanding
    - action_ccoutstanding
* agent.acquaintance
    - action_ccoutstanding
* getccoutstanding{"ccoutstanding": "credit card outstanding"}
    - action_ccoutstanding

## Generated Story -3650257542173798301
* captureuserid{"user_id": "llllllllllll0000000000000>prabha0901"}
    - slot{"user_id": "llllllllllll0000000000000>prabha0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* caniafford
    - action_caniafford
* getcab{"pickup_location": "gachibowli", "drop_location": "hyderabad"}
    - slot{"pickup_location": "gachibowli"}
    - slot{"drop_location": "hyderabad"}
    - action_getcab
    - slot{"pickup_location": "gachibowli"}
    - slot{"drop_location": "hyderabad"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "gachibowli"}
    - slot{"bkd_drop_location": "hyderabad"}
* out_of_scope
    - utter_out_of_scope
* getccoutstanding{"ccoutstanding": "credit card balance"}
    - action_ccoutstanding
* geteodbal
    - action_accntbal
* getsrdelivery{"srdmp": "service request"}
    - slot{"srdmp": "service request"}
    - action_srdeliverables
    - slot{"user_id": "PRABHA0901"}
* getsrdelivery{"srdmp": "service request"}
    - slot{"srdmp": "service request"}
    - action_srdeliverables
    - slot{"user_id": "PRABHA0901"}
* getsrdelivery{"srdmp": "service request"}
    - slot{"srdmp": "service request"}
    - action_srdeliverables
    - slot{"user_id": "PRABHA0901"}
* getsrdelivery{"srdmp": "Deliverables"}
    - slot{"srdmp": "Deliverables"}
    - action_srdeliverables
    - slot{"user_id": "PRABHA0901"}
* getstatements{"DATE": "today", "txntype": "expenditure", "date": "today"}
    - slot{"DATE": "today"}
    - slot{"date": "today"}
    - action_getstatement
* getstatements{"DATE": "last week", "txntype": "expenditure", "timef": "till", "date": "last week"}
    - slot{"DATE": "last week"}
    - slot{"date": "last week"}
    - action_getstatement
* getstatements{"DATE": "today", "txntype": "expenditure", "date": "today"}
    - slot{"DATE": "today"}
    - slot{"date": "today"}
    - action_getstatement
* getupcomingexpense{"acc_act_type": "upcoming expense"}
    - action_upcomingexpense
    - slot{"user_id": "PRABHA0901"}
* getupcomingexpense{"acc_act_type": "upcoming expense"}
    - action_upcomingexpense
    - slot{"user_id": "PRABHA0901"}
* getupcomingexpense{"acc_act_type": "upcoming expense"}
    - action_upcomingexpense
    - slot{"user_id": "PRABHA0901"}
* getweather{"location": "chennai"}
    - slot{"location": "chennai"}
    - action_weather
    - slot{"location": "chennai"}
    - slot{"pickup_location": "chennai"}
* getweather{"location": "chennai"}
    - slot{"location": "chennai"}
    - action_weather
    - slot{"location": "chennai"}
    - slot{"pickup_location": "chennai"}








## Generated Story -6433837225905699625
* captureuserid{"user_id": "llllllllllll0000000000000>prabha0901"}
    - slot{"user_id": "llllllllllll0000000000000>prabha0901"}
    - action_storeuseid
    - slot{"user_id": "PRABHA0901"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* caniafford
    - action_caniafford
* getcab
    - action_getcab
    - slot{"pickup_location": "default"}
    - slot{"drop_location": "default"}
    - slot{"ifcabbooked": true}
    - slot{"user_id": "PRABHA0901"}
    - slot{"bkd_pickup_location": "default"}
    - slot{"bkd_drop_location": "default"}
* getccoutstanding{"ccoutstanding": "credit card outstanding"}
    - action_ccoutstanding
* getsrdelivery{"srdmp": "service request"}
    - slot{"srdmp": "service request"}
    - action_srdeliverables
    - slot{"user_id": "PRABHA0901"}
* getsrdelivery{"srdmp": "Deliverables"}
    - slot{"srdmp": "Deliverables"}
    - action_srdeliverables
    - slot{"user_id": "PRABHA0901"}
* getweather{"location": "chennai"}
    - slot{"location": "chennai"}
    - action_weather
    - slot{"location": "chennai"}
    - slot{"pickup_location": "chennai"}
* getnewcheckbook
    - action_getcheckbook
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope
* out_of_scope
    - utter_out_of_scope
* getweather
    - action_weather
    - slot{"location": "chennai"}
    - slot{"pickup_location": "chennai"}
* out_of_scope
    - utter_out_of_scope