## story 01
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getweather{"location":"Chennai"}
	- slot{"location":"Chennai"}
	- action_weather
	- slot{"location":"Chennai","user_id": "shreeramuni"}
	
## story 02
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getweather{"location":"Chennai"}
	- slot{"location":"Chennai"}
	- action_weather
	- slot{"location":"Chennai"}
	- slot{"user_id": "shreeramuniq139"}
* getweather{"location":"Chennai"}
	- slot{"location":"Chennai"}
	- action_weather
	- slot{"location":"Chennai"}
	- slot{"user_id": "shreeramuniq139"}
	
## story 03
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getweather{"location":"Chennai"}
	- slot{"location":"Chennai"}
	- action_weather
	- slot{"location":"Chennai"}
	- slot{"user_id": "shreeramuniq139"}
* getweather{"location":"Chennai"}
	- slot{"location":"Chennai"}
	- action_weather
	- slot{"location":"Chennai"}
	- slot{"user_id": "shreeramuniq139"}
* getweather{"location":"Chennai"}
	- slot{"location":"Chennai"}
	- action_weather
	- slot{"location":"Chennai"}
	- slot{"user_id": "shreeramuniq139"}
	
## story 04
* captureuserid{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - slot{"user_id": "LLLLLLLLLLLL0000000000000>shreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
* getweather{"location":"Chennai"}
	- slot{"location":"Chennai"}
	- action_weather
	- slot{"location":"Chennai"}
	- slot{"user_id": "shreeramuniq139"}
* getweather{"location":"Chennai"}
	- slot{"location":"Chennai"}
	- action_weather
	- slot{"location":"Chennai"}
	- slot{"user_id": "shreeramuniq139"}
* getweather{"location":"Chennai"}
	- slot{"location":"Chennai"}
	- action_weather
	- slot{"location":"Chennai"}
	- slot{"user_id": "shreeramuniq139"}
* getweather{"location":"Chennai"}
	- slot{"location":"Chennai"}
	- action_weather
	- slot{"location":"Chennai"}
	- slot{"user_id": "shreeramuniq139"}
