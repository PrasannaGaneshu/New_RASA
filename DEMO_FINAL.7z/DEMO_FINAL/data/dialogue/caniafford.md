## Story 01
* caniafford
    - action_caniafford
    
## Story 011
* caniafford
    - action_caniafford
    
## Story 012
* caniafford
    - action_caniafford
    
## Story 013
* caniafford
    - action_caniafford
    
## Story 014
* caniafford
    - action_caniafford
    
## Story 015
* caniafford
    - action_caniafford
    
## Story 016
* caniafford
    - action_caniafford
    
## Story 017
* caniafford
    - action_caniafford
    
 
## Story 02
* captureuserid{"ORG": "XOXOXOXOXOXOXOXXOXOXSHREERAMUNIQ139", "user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - slot{"user_id": "xoxoxoxoxoxoxoxxoxoxshreeramuniq139"}
    - action_storeuseid
    - slot{"user_id": "shreeramuniq139"}
    - slot{"SR_flag": "firstimenothing"}
* caniafford
    - action_caniafford
    
## Generated Story -6578476306119549202
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>LEONPAUL23793", "user_id": "llllllllllll0000000000000>leonpaul23793"}
    - slot{"user_id": "llllllllllll0000000000000>leonpaul23793"}
    - action_storeuseid
    - slot{"user_id": "LEONPAUL23793"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* caniafford
    - action_caniafford
* caniafford
    - action_caniafford


## Generated Story -74310635113069443825
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>LEONPAUL23793", "user_id": "llllllllllll0000000000000>leonpaul23793"}
    - slot{"user_id": "llllllllllll0000000000000>leonpaul23793"}
    - action_storeuseid
    - slot{"user_id": "LEONPAUL23793"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* caniafford
    - action_caniafford
* greetings.hello
    - utter_greetings.hello
* caniafford
    - action_caniafford
* caniafford
    - action_caniafford

## Generated Story -74310635113069443825
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>LEONPAUL23793", "user_id": "llllllllllll0000000000000>leonpaul23793"}
    - slot{"user_id": "llllllllllll0000000000000>leonpaul23793"}
    - action_storeuseid
    - slot{"user_id": "LEONPAUL23793"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* caniafford
    - action_caniafford
* greetings.hello
    - utter_greetings.hello
* caniafford
    - action_caniafford
* caniafford
    - action_caniafford

## Generated Story -7431063511306944366
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>LEONPAUL23793", "user_id": "llllllllllll0000000000000>leonpaul23793"}
    - slot{"user_id": "llllllllllll0000000000000>leonpaul23793"}
    - action_storeuseid
    - slot{"user_id": "LEONPAUL23793"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* caniafford
    - action_caniafford
* greetings.hello
    - utter_greetings.hello
* caniafford
    - action_caniafford
* caniafford
    - action_caniafford
    
## Generated Story 3488171613725548543
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>LEONPAUL23793", "user_id": "llllllllllll0000000000000>leonpaul23793"}
    - slot{"user_id": "llllllllllll0000000000000>leonpaul23793"}
    - action_storeuseid
    - slot{"user_id": "LEONPAUL23793"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* getupcomingexpense{"acc_act_type": "upcoming expense"}
    - action_upcomingexpense
    - slot{"user_id": "LEONPAUL23793"}
* geteodbal
    - action_accntbal
* getweather
    - action_weather
    - slot{"location": "Mumbai"}
    - slot{"pickup_location": "Mumbai"}
* caniafford
    - action_caniafford
* caniafford
    - action_caniafford
* caniafford
    - action_caniafford
* caniafford
    - action_caniafford



## Generated Story -8056760112878177152
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>LEONPAUL23793", "user_id": "llllllllllll0000000000000>leonpaul23793"}
    - slot{"user_id": "llllllllllll0000000000000>leonpaul23793"}
    - action_storeuseid
    - slot{"user_id": "LEONPAUL23793"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.bye
    - utter_greetings.bye
    
    
## Generated Story showmenu1
* agent.show_menu
    - action_showmenu

    
## Generated Story showmenu2
* agent.show_menu
    - action_showmenu
    
    
## Generated Story showmenu3
* agent.show_menu
    - action_showmenu
    
## Generated Story 8017770316972490860
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>LEONPAUL23793", "user_id": "llllllllllll0000000000000>leonpaul23793"}
    - slot{"user_id": "llllllllllll0000000000000>leonpaul23793"}
    - action_storeuseid
    - slot{"user_id": "LEONPAUL23793"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* greetings.hello
    - utter_greetings.hello
* agent.show_menu
    - action_showmenu
* agent.show_menu
    - action_showmenu
* agent.show_menu
    - action_showmenu
* agent.show_menu
    - action_showmenu
* agent.bad
    - utter_agent.bad
* agent.bad
    - utter_agent.bad
* agent.bad
    - utter_agent.bad

## Generated Story -6754291722310834484
* captureuserid{"PERSON": "LLLLLLLLLLLL0000000000000>LEONPAUL23793", "user_id": "llllllllllll0000000000000>leonpaul23793"}
    - slot{"user_id": "llllllllllll0000000000000>leonpaul23793"}
    - action_storeuseid

    - slot{"user_id": "LEONPAUL23793"}
    - slot{"SR_flag": "firstimenothing"}
    - slot{"location": "default"}
    - slot{"drop_location": "default"}
    - slot{"pickup_location": "default"}
* agent.show_menu
    - action_showmenu
* agent.show_menu
    - action_showmenu
* agent.bad
    - utter_agent.bad
* agent.show_menu
    - action_showmenu
* geteodbal
    - action_accntbal
* appraisal.thank_you
    - utter_appraisal.thank_you
* getstatements{"txntype": "expenses"}
    - action_getstatement
* greetings.bye
    - utter_greetings.bye

