## intent:agent.bad
- you're not helping me
- you are bad
- you're very bad
- you're really bad
- you are useless
- you are horrible
- you are disgusting
