## intent:agent.show_menu
- menu
- show menu
- show options
- open the menu
- show menu options
- help options
- help